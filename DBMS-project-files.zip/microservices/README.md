# Explore India – Microservices Architecture (CO5)

This directory demonstrates **CO5: Microservices Architecture Engineering** for the **Explore India** travel portal.

## Microservices Topology

| Service | Port | Technology Stack | Responsibilities | Database |
|---|---|---|---|---|
| **API Gateway** | `8000` | Python / FastAPI / Pydantic | Routing, Rate Limiting, OpenAPI Spec | Reverse Proxy |
| **Main Core Backend** | `5000` | Node.js / Express | Core Packages, Bookings, Admin Aggregations | MongoDB (`travel_booking`) |
| **User Service** | `3001` | Node.js / Express | Traveler Registration, JWT Auth, Profiles | MongoDB (`users` collection) |
| **Activity Service** | `3002` | Node.js / Express | User Activity Tracking, Event Sourcing | MongoDB (`activities` collection) |
| **Flask Catalog** | `5001` | Python / Flask | Fast lightweight catalog search | In-Memory / Relational |
| **Django Service** | `8001` | Python / Django / DRF | Relational Packages, Bookings, ORM models | SQLite (`db.sqlite3`) |
| **Spring Product Service**| `8082` | Java / Spring Boot 3 / JPA | Enterprise package catalog & Actuator metrics | In-memory H2 / PostgreSQL |

## Distributed System Concepts Demonstrated
1. **API Gateway Pattern**: Client communicates with FastAPI gateway at `8000`, which forwards upstream requests.
2. **Database per Service**: Independent storage schemas isolate failures.
3. **Saga Pattern & Compensating Transactions**: Demonstrated in `microservices/saga-demo/saga_orchestrator.js` with simulated rollback on payment failure.
4. **Service Health Monitoring**: Standardized `/health` probes on all services.
