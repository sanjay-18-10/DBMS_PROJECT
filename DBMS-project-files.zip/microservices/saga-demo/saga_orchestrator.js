/**
 * Explore India - Saga Pattern & Compensating Transactions Demo (CO5)
 * ===================================================================
 * Demonstrates the Saga Orchestrator pattern for distributed transactions across
 * microservices (e.g. Package Service -> Booking Service -> Payment Gateway).
 *
 * If any step fails (e.g., Payment fails or Inventory runs out), the orchestrator
 * invokes compensating transactions in reverse order to restore consistent state.
 *
 * Run with: node saga_orchestrator.js
 */

class SagaStep {
  constructor(name, executeAction, compensateAction) {
    this.name = name;
    this.executeAction = executeAction;
    this.compensateAction = compensateAction;
  }
}

class SagaOrchestrator {
  constructor() {
    this.steps = [];
    this.executedSteps = [];
  }

  addStep(step) {
    this.steps.push(step);
    return this;
  }

  async execute(context) {
    console.log(`\n======================================================`);
    console.log(`🚀 Starting Saga Execution for Reference: ${context.bookingRef}`);
    console.log(`======================================================`);

    for (const step of this.steps) {
      console.log(`⏳ [Executing] ${step.name}...`);
      try {
        const result = await step.executeAction(context);
        this.executedSteps.push(step);
        console.log(`✅ [Success] ${step.name}`);
      } catch (err) {
        console.error(`❌ [Failure] ${step.name}: ${err.message}`);
        console.log(`\n⚠️  Initiating Saga Compensation (Rollback in reverse)...`);
        await this.rollback(context);
        throw new Error(`Saga failed at '${step.name}'. All completed steps compensated.`);
      }
    }

    console.log(`\n🎉 [Saga Completed Successfully] All transactions committed.`);
    return { success: true, bookingRef: context.bookingRef };
  }

  async rollback(context) {
    while (this.executedSteps.length > 0) {
      const step = this.executedSteps.pop();
      console.log(`🔄 [Compensating] Undoing: ${step.name}...`);
      try {
        await step.compensateAction(context);
        console.log(`   └─ Successfully compensated: ${step.name}`);
      } catch (compensateError) {
        console.error(`   └─ CRITICAL: Compensation error at ${step.name}: ${compensateError.message}`);
      }
    }
  }
}

// Simulated Microservice State Stores
const inventoryDb = { 'PKG-KERALA': 5 };
const bookingDb = {};
const paymentDb = {};

// Step 1: Reserve Seats in Inventory Service
const reserveInventoryStep = new SagaStep(
  'InventoryService: Reserve Seats',
  async (ctx) => {
    if (inventoryDb[ctx.packageCode] < ctx.seats) {
      throw new Error(`Insufficient inventory. Available: ${inventoryDb[ctx.packageCode]}, Requested: ${ctx.seats}`);
    }
    inventoryDb[ctx.packageCode] -= ctx.seats;
    ctx.inventoryReserved = true;
    console.log(`   └─ Seats decremented. Remaining: ${inventoryDb[ctx.packageCode]}`);
  },
  async (ctx) => {
    if (ctx.inventoryReserved) {
      inventoryDb[ctx.packageCode] += ctx.seats;
      console.log(`   └─ Compensation: Restored ${ctx.seats} seats. Available now: ${inventoryDb[ctx.packageCode]}`);
    }
  }
);

// Step 2: Create Pending Booking in Booking Service
const createBookingStep = new SagaStep(
  'BookingService: Create Pending Booking',
  async (ctx) => {
    bookingDb[ctx.bookingRef] = {
      packageCode: ctx.packageCode,
      seats: ctx.seats,
      amount: ctx.amount,
      status: 'PENDING'
    };
    ctx.bookingCreated = true;
    console.log(`   └─ Booking recorded with status PENDING`);
  },
  async (ctx) => {
    if (ctx.bookingCreated) {
      bookingDb[ctx.bookingRef].status = 'CANCELLED';
      console.log(`   └─ Compensation: Marked booking ${ctx.bookingRef} as CANCELLED`);
    }
  }
);

// Step 3: Process Charge in Payment Service
const processPaymentStep = new SagaStep(
  'PaymentService: Charge Traveler',
  async (ctx) => {
    if (ctx.forcePaymentFailure) {
      throw new Error('Payment gateway declined: Card expired or insufficient funds.');
    }
    paymentDb[ctx.bookingRef] = {
      amount: ctx.amount,
      status: 'CAPTURED',
      transactionId: 'TXN-' + Math.floor(Math.random() * 1000000)
    };
    bookingDb[ctx.bookingRef].status = 'CONFIRMED';
    console.log(`   └─ Payment captured. Booking marked CONFIRMED.`);
  },
  async (ctx) => {
    if (paymentDb[ctx.bookingRef]) {
      paymentDb[ctx.bookingRef].status = 'REFUNDED';
      console.log(`   └─ Compensation: Processed refund for booking ${ctx.bookingRef}`);
    }
  }
);

// Simulation Runner
async function runDemo() {
  console.log('--- TEST CASE 1: Successful Distributed Booking Saga ---');
  const saga1 = new SagaOrchestrator()
    .addStep(reserveInventoryStep)
    .addStep(createBookingStep)
    .addStep(processPaymentStep);

  try {
    await saga1.execute({
      bookingRef: 'BKG-SUCCESS-101',
      packageCode: 'PKG-KERALA',
      seats: 2,
      amount: 30000,
      forcePaymentFailure: false,
    });
  } catch (e) {
    console.error(e.message);
  }

  console.log('\n--- TEST CASE 2: Distributed Booking Saga with Payment Failure (Rollback) ---');
  const saga2 = new SagaOrchestrator()
    .addStep(reserveInventoryStep)
    .addStep(createBookingStep)
    .addStep(processPaymentStep);

  try {
    await saga2.execute({
      bookingRef: 'BKG-FAILED-202',
      packageCode: 'PKG-KERALA',
      seats: 2,
      amount: 30000,
      forcePaymentFailure: true, // triggers failure & compensating rollback!
    });
  } catch (e) {
    console.log(`\nResult: Clean rollback verified. No orphan booking or seat loss.`);
  }
}

if (require.main === module) {
  runDemo();
}

module.exports = { SagaOrchestrator, SagaStep };
