# Distributed Saga Pattern & Compensating Transactions (CO5)

This demonstration illustrates how distributed transactions are safely coordinated across microservices without relying on heavy two-phase commit (2PC) locks.

## Concepts Demonstrated
1. **Orchestrator-Based Saga**: A centralized workflow engine executes local transactions across service boundaries.
2. **Forward Recovery**: If all steps succeed, changes are permanently committed.
3. **Backward Recovery (Compensating Transactions)**: If any step fails (e.g. Payment Gateway decline), the orchestrator triggers compensating actions in reverse order:
   - Cancels the provisional booking
   - Restores the reserved seat inventory
   - Refunds any partial charges

## Running the Demo
```powershell
cd microservices\saga-demo
node saga_orchestrator.js
```
