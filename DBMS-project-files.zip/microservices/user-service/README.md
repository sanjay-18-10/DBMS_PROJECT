# Explore India – User Microservice (CO5)

Standalone Node.js microservice focused exclusively on **User Identity and Authentication**.

## Microservices Design Patterns
- **Database-per-service**: Operates on its dedicated logical partition / collection.
- **Internal API**: Exposes `/internal/users/:id` for fast service-to-service communication.
- **Decoupled Auth Tokens**: Issues self-contained JWT tokens validated across services.

## Running the Service
```powershell
cd microservices\user-service
node server.js
```
Runs on: `http://localhost:3001`
Health check: `http://localhost:3001/health`
