package com.exploreindia.productservice.model;

import jakarta.persistence.*;
import java.math.BigDecimal;

@Entity
@Table(name = "travel_packages")
public class PackageEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String name;

    @Column(nullable = false)
    private String destination;

    @Column(columnDefinition = "TEXT")
    private String description;

    @Column(nullable = false, precision = 10, scale = 2)
    private BigDecimal price;

    private Integer durationDays;
    private String category;
    private Integer availableSeats;
    private Boolean active = true;

    public PackageEntity() {}

    public PackageEntity(String name, String destination, BigDecimal price, Integer durationDays, String category, Integer availableSeats) {
        this.name = name;
        this.destination = destination;
        this.price = price;
        this.durationDays = durationDays;
        this.category = category;
        this.availableSeats = availableSeats;
        this.active = true;
    }

    // Getters and Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getDestination() { return destination; }
    public void setDestination(String destination) { this.destination = destination; }
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
    public BigDecimal getPrice() { return price; }
    public void setPrice(BigDecimal price) { this.price = price; }
    public Integer getDurationDays() { return durationDays; }
    public void setDurationDays(Integer durationDays) { this.durationDays = durationDays; }
    public String getCategory() { return category; }
    public void setCategory(String category) { this.category = category; }
    public Integer getAvailableSeats() { return availableSeats; }
    public void setAvailableSeats(Integer availableSeats) { this.availableSeats = availableSeats; }
    public Boolean getActive() { return active; }
    public void setActive(Boolean active) { this.active = active; }
}
