package com.exploreindia.productservice.controller;

import com.exploreindia.productservice.model.PackageEntity;
import com.exploreindia.productservice.repository.PackageRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/packages")
@CrossOrigin(origins = "*")
public class PackageController {

    @Autowired
    private PackageRepository packageRepository;

    @GetMapping
    public List<PackageEntity> getAllPackages() {
        return packageRepository.findByActiveTrue();
    }

    @GetMapping("/{id}")
    public ResponseEntity<PackageEntity> getPackageById(@PathVariable Long id) {
        return packageRepository.findById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public PackageEntity createPackage(@RequestBody PackageEntity packageEntity) {
        return packageRepository.save(packageEntity);
    }

    @GetMapping("/health")
    public Map<String, Object> health() {
        return Map.of(
            "service", "spring-product-service",
            "framework", "Spring Boot 3.2 (Java)",
            "status", "healthy"
        );
    }
}
