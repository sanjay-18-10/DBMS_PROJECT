package com.exploreindia.productservice.repository;

import com.exploreindia.productservice.model.PackageEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface PackageRepository extends JpaRepository<PackageEntity, Long> {
    List<PackageEntity> findByDestinationContainingIgnoreCase(String destination);
    List<PackageEntity> findByCategoryIgnoreCase(String category);
    List<PackageEntity> findByActiveTrue();
}
