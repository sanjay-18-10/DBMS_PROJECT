# Explore India – Spring Boot Product Service (CO5)

Reference microservice demonstrating enterprise Java microservices engineering using **Spring Boot 3.x, Spring Data JPA, Hibernate, and Spring Actuator**.

## Core Concepts
- **Inversion of Control (IoC) & Dependency Injection (DI)**: `@Autowired` injection of repositories.
- **Spring Data JPA**: Automatic query generation through method names (`findByDestinationContainingIgnoreCase`).
- **Spring Boot Actuator**: Production-grade health checks (`/actuator/health`) and metrics.
- **Embedded Persistence**: Configured with embedded H2 database for instant demo, with PostgreSQL production driver.

## Build and Run (When Maven / Wrapper is installed)
```bash
mvn clean spring-boot:run
```
Service runs on: `http://localhost:8082`
Actuator health: `http://localhost:8082/actuator/health`
