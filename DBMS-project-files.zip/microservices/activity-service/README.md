# Explore India – Activity Tracking Microservice (CO5)

Event-sourcing and audit logging microservice for traveler activities, booking events, and searches.

## Microservices Features
- **Event Logging**: Ingests non-blocking analytical events without polluting the transactional database models.
- **Aggregation Insights**: Provides aggregated activity matrices using MongoDB pipeline stages.
- **Independent Scalability**: Can be scaled horizontally under heavy read/write analytical traffic.

## Running the Service
```powershell
cd microservices\activity-service
node server.js
```
Runs on: `http://localhost:3002`
Health check: `http://localhost:3002/health`
