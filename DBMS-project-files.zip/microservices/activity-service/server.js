/**
 * Explore India - Activity Tracking Microservice (CO5)
 * Standalone Node.js service for event sourcing & user analytics.
 * Port: 3002
 * Database: MongoDB (travel_booking database, activities collection)
 */
const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');

const app = express();
app.use(express.json());
app.use(cors());

const PORT = process.env.PORT || 3002;
const MONGO_URI = process.env.MONGO_URI || 'mongodb://localhost:27017/travel_booking';

// Connect to MongoDB
mongoose.connect(MONGO_URI)
  .then(() => console.log('✅ Activity Service: Connected to MongoDB'))
  .catch(err => console.error('❌ Activity Service MongoDB error:', err.message));

// Activity Event Schema
const activitySchema = new mongoose.Schema({
  eventType: {
    type: String,
    required: true,
    enum: [
      'package_viewed',
      'package_searched',
      'booking_created',
      'booking_cancelled',
      'payment_processed',
      'user_login',
      'user_registered'
    ],
  },
  userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  entityId: { type: String },
  entityType: { type: String },
  metadata: { type: mongoose.Schema.Types.Mixed, default: {} },
  ipAddress: { type: String },
  timestamp: { type: Date, default: Date.now },
});

activitySchema.index({ eventType: 1, timestamp: -1 });
activitySchema.index({ userId: 1, timestamp: -1 });

const Activity = mongoose.model('Activity', activitySchema);

// Endpoints
app.get('/health', (req, res) => {
  res.json({
    service: 'activity-service',
    status: 'healthy',
    port: PORT,
    database: mongoose.connection.readyState === 1 ? 'connected' : 'disconnected',
    timestamp: new Date().toISOString(),
  });
});

app.post('/events', async (req, res) => {
  try {
    const { eventType, userId, entityId, entityType, metadata } = req.body;
    if (!eventType) return res.status(400).json({ error: 'eventType is required' });

    const activity = await Activity.create({
      eventType,
      userId: userId || null,
      entityId,
      entityType,
      metadata: metadata || {},
      ipAddress: req.ip,
    });
    res.status(201).json({ success: true, activityId: activity._id, eventType });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.get('/events', async (req, res) => {
  try {
    const filter = {};
    if (req.query.type) filter.eventType = req.query.type;
    if (req.query.userId) filter.userId = req.query.userId;
    const limit = parseInt(req.query.limit, 10) || 50;

    const events = await Activity.find(filter).sort('-timestamp').limit(limit);
    res.json({ count: events.length, events });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.get('/stats', async (req, res) => {
  try {
    const totalEvents = await Activity.countDocuments();
    const byType = await Activity.aggregate([
      { $group: { _id: '$eventType', count: { $sum: 1 } } },
      { $sort: { count: -1 } }
    ]);

    res.json({
      total_events: totalEvents,
      by_event_type: byType,
      service: 'activity-service'
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

if (require.main === module) {
  app.listen(PORT, () => {
    console.log(`📈 Activity Microservice running on http://localhost:${PORT}`);
  });
}

module.exports = app;
