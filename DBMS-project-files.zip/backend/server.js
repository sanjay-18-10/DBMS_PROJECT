const express = require("express");
const path = require("path");
const cors = require("cors");
const dotenv = require("dotenv");
const connectDB = require("./config/db");

// Load environment variables
dotenv.config();

// Connect to MongoDB
connectDB();

const userRoutes = require("./routes/userRoutes");
const packageRoutes = require("./routes/packageRoutes");
const bookingRoutes = require("./routes/bookingRoutes");
const paymentRoutes = require("./routes/paymentRoutes");
const adminRoutes = require("./routes/adminRoutes");
const { notFound, errorHandler } = require("./middleware/errorMiddleware");

const app = express();

// Enable Cross-Origin Resource Sharing (CORS)
app.use(cors());

// Parse incoming JSON requests
app.use(express.json());

// Serve static frontend files
app.use(express.static(path.join(__dirname, "../frontend")));

// API Routes
app.use("/api/users", userRoutes);
app.use("/api/packages", packageRoutes);
app.use("/api/bookings", bookingRoutes);
app.use("/api/payments", paymentRoutes);
app.use("/api/admin", adminRoutes);

// Health check endpoint
app.get("/api/health", (req, res) => {
    res.status(200).json({
        status: "OK",
        message: "Travel Package Booking Portal API is healthy",
        timestamp: new Date().toISOString()
    });
});

// Prometheus & Observability metrics endpoint (CO6)
app.get("/api/metrics", (req, res) => {
    const memory = process.memoryUsage();
    res.set("Content-Type", "text/plain");
    res.send([
        "# HELP process_uptime_seconds Process uptime in seconds",
        "# TYPE process_uptime_seconds counter",
        `process_uptime_seconds ${process.uptime().toFixed(2)}`,
        "# HELP node_memory_rss_bytes Resident Set Size memory in bytes",
        "# TYPE node_memory_rss_bytes gauge",
        `node_memory_rss_bytes ${memory.rss}`,
        "# HELP node_memory_heap_used_bytes Heap memory used in bytes",
        "# TYPE node_memory_heap_used_bytes gauge",
        `node_memory_heap_used_bytes ${memory.heapUsed}`,
        "# HELP node_memory_heap_total_bytes Total heap allocated in bytes",
        "# TYPE node_memory_heap_total_bytes gauge",
        `node_memory_heap_total_bytes ${memory.heapTotal}`
    ].join("\n"));
});

// Fallback to frontend index.html for client-side navigation
app.get("/", (req, res) => {
    res.sendFile(path.join(__dirname, "../frontend/index.html"));
});

// Centralized error handling
app.use(notFound);
app.use(errorHandler);

const PORT = process.env.PORT || 5000;

app.listen(PORT, () => {
    console.log(`===============================================`);
    console.log(`🚀 Travel Booking Portal Server Running`);
    console.log(`📍 Local URL: http://localhost:${PORT}`);
    console.log(`📡 API Base:  http://localhost:${PORT}/api`);
    console.log(`===============================================`);
});