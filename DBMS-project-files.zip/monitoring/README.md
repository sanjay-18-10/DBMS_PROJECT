# Explore India – Monitoring & Observability Stack (CO6)

Demonstrates metrics collection, system telemetry, and health dashboards.

## Stack Overview
- **Prometheus**: Periodically scrapes `/api/metrics` from Node.js backend and FastAPI gateway.
- **Grafana**: Visualizes throughput, HTTP status code distributions (2xx, 4xx, 5xx), and database connection latencies.
- **Node.js Metrics**: Exposes memory usage (RSS, heap), process uptime, and request counters.

## Running Prometheus via Docker
```powershell
docker run -d -p 9090:9090 -v ${PWD}/monitoring/prometheus/prometheus.yml:/etc/prometheus/prometheus.yml prom/prometheus
```
Access Prometheus UI at: `http://localhost:9090`
