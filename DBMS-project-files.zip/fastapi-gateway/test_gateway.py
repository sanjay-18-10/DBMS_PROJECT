"""
FastAPI Gateway Tests (CO3: Testing Demonstration)
Run with: pytest test_gateway.py -v
"""
import pytest
from fastapi.testclient import TestClient
from unittest.mock import AsyncMock, patch
import httpx

from main import app

client = TestClient(app)

class TestGatewayRoot:
    def test_root_returns_gateway_info(self):
        resp = client.get("/")
        assert resp.status_code == 200
        data = resp.json()
        assert "Explore India" in data["name"]
        assert "routes" in data
        assert len(data["routes"]) > 0

    def test_root_has_version(self):
        resp = client.get("/")
        assert "version" in resp.json()

class TestValidation:
    def test_register_rejects_short_name(self):
        resp = client.post("/api/auth/register", json={
            "name": "A",  # too short
            "email": "test@test.com",
            "password": "password123",
            "phone": "9876543210"
        })
        assert resp.status_code == 422  # Pydantic validation error

    def test_register_rejects_short_password(self):
        resp = client.post("/api/auth/register", json={
            "name": "Rahul Verma",
            "email": "test@test.com",
            "password": "12",  # too short
            "phone": "9876543210"
        })
        assert resp.status_code == 422

    def test_login_requires_fields(self):
        resp = client.post("/api/auth/login", json={})
        assert resp.status_code == 422

class TestHeaders:
    def test_timing_header_present(self):
        resp = client.get("/")
        assert "x-process-time-ms" in resp.headers
        assert "x-gateway" in resp.headers

    def test_gateway_header_value(self):
        resp = client.get("/")
        assert "Explore-India-FastAPI" in resp.headers.get("x-gateway", "")

if __name__ == "__main__":
    pytest.main(["-v", __file__])
