"""
Explore India - FastAPI API Gateway (CO3 Demonstration)
=======================================================
This gateway demonstrates:
- FastAPI REST API framework
- Async HTTP forwarding to Node.js backend
- JWT token forwarding / validation
- Pydantic request/response validation
- OpenAPI / Swagger UI auto-generation
- Middleware: CORS, timing, request logging
- Dependency injection
- Rate limiting concept
- Error handling
- Health checks

Access Swagger UI at: http://localhost:8000/docs
Access ReDoc at:       http://localhost:8000/redoc
"""

import time
import httpx
from contextlib import asynccontextmanager
from typing import Optional, Any
from fastapi import FastAPI, HTTPException, Depends, Request, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from pydantic import BaseModel, Field, EmailStr
from functools import lru_cache
import json

# ─── Configuration ───────────────────────────────────────────────────────────
NODE_BACKEND = "http://localhost:5000/api"
GATEWAY_VERSION = "1.0.0"

# Simple in-memory rate limiter (demonstration only)
_request_counts: dict[str, list] = {}

def rate_limit(request: Request, limit: int = 60, window: int = 60):
    """Dependency injection demo: simple in-memory rate limiter."""
    client_ip = request.client.host if request.client else "unknown"
    now = time.time()
    timestamps = _request_counts.get(client_ip, [])
    # Keep only timestamps within the window
    timestamps = [t for t in timestamps if now - t < window]
    if len(timestamps) >= limit:
        raise HTTPException(
            status_code=status.HTTP_429_TOO_MANY_REQUESTS,
            detail=f"Rate limit exceeded: max {limit} requests per {window}s"
        )
    timestamps.append(now)
    _request_counts[client_ip] = timestamps

# ─── Pydantic Schemas (CO3: Data Validation) ─────────────────────────────────
class UserRegisterSchema(BaseModel):
    name: str = Field(..., min_length=2, max_length=100, example="Rahul Verma")
    email: str = Field(..., example="rahul@example.com")
    password: str = Field(..., min_length=6, example="password123")
    phone: str = Field(..., min_length=10, max_length=15, example="9876543210")

class UserLoginSchema(BaseModel):
    email: str = Field(..., example="ganesh@test.com")
    password: str = Field(..., example="123456")

class PackageFilterSchema(BaseModel):
    destination: Optional[str] = None
    category: Optional[str] = None
    minPrice: Optional[float] = None
    maxPrice: Optional[float] = None
    sortBy: Optional[str] = "newest"

class HealthResponse(BaseModel):
    status: str
    gateway: str
    version: str
    backend_reachable: bool
    timestamp: float

class GatewayInfoResponse(BaseModel):
    name: str
    description: str
    version: str
    routes: list[dict]

# ─── HTTP Client (shared) ─────────────────────────────────────────────────────
_http_client: Optional[httpx.AsyncClient] = None

@asynccontextmanager
async def lifespan(app: FastAPI):
    """Manage shared async HTTP client lifecycle."""
    global _http_client
    _http_client = httpx.AsyncClient(timeout=30.0)
    print(f"✅ FastAPI Gateway v{GATEWAY_VERSION} started")
    print(f"📡 Forwarding to Node.js backend: {NODE_BACKEND}")
    yield
    await _http_client.aclose()
    print("🛑 FastAPI Gateway stopped")

async def get_client() -> httpx.AsyncClient:
    global _http_client
    if _http_client is None:
        _http_client = httpx.AsyncClient(timeout=30.0)
    return _http_client

# ─── FastAPI App ──────────────────────────────────────────────────────────────
app = FastAPI(
    title="Explore India – API Gateway",
    description="""FastAPI Gateway demonstrating CO3 concepts:
- **REST API design** with OpenAPI specification
- **Pydantic** request/response validation
- **Dependency Injection** (rate limiter, auth forwarding)
- **Async** HTTP client forwarding to Node.js
- **Middleware**: CORS, timing headers
- **Error handling** with structured responses

> Node.js backend must be running at http://localhost:5000
""",
    version=GATEWAY_VERSION,
    lifespan=lifespan,
    docs_url="/docs",
    redoc_url="/redoc",
)

# ─── Middleware ───────────────────────────────────────────────────────────────
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.middleware("http")
async def add_timing_header(request: Request, call_next):
    """Middleware: measure and attach processing time to every response."""
    start = time.perf_counter()
    response = await call_next(request)
    duration = (time.perf_counter() - start) * 1000
    response.headers["X-Process-Time-Ms"] = f"{duration:.2f}"
    response.headers["X-Gateway"] = f"Explore-India-FastAPI/{GATEWAY_VERSION}"
    return response

# ─── Helper: forward request to Node backend ─────────────────────────────────
async def forward(
    method: str,
    path: str,
    client: httpx.AsyncClient,
    request: Request,
    body: Any = None,
) -> dict:
    """Forward an HTTP request to the Node.js backend, relaying the JWT token."""
    headers = {}
    auth_header = request.headers.get("Authorization")
    if auth_header:
        headers["Authorization"] = auth_header
    headers["Content-Type"] = "application/json"

    url = f"{NODE_BACKEND}{path}"
    # Forward query params
    if request.query_params:
        url += "?" + str(request.query_params)

    try:
        resp = await client.request(
            method=method,
            url=url,
            headers=headers,
            json=body,
        )
        data = resp.json()
        if resp.status_code >= 400:
            raise HTTPException(status_code=resp.status_code, detail=data)
        return data
    except httpx.ConnectError:
        raise HTTPException(
            status_code=503,
            detail="Backend service (Node.js) is not reachable. Please start the backend with: cd backend && npm start"
        )
    except httpx.TimeoutException:
        raise HTTPException(status_code=504, detail="Backend request timed out")

# ─── Routes ───────────────────────────────────────────────────────────────────

@app.get("/", tags=["Gateway"], response_model=GatewayInfoResponse)
async def gateway_root():
    """API Gateway information and route map."""
    return {
        "name": "Explore India – FastAPI API Gateway",
        "description": "CO3 demonstration: FastAPI gateway forwarding to Node.js backend",
        "version": GATEWAY_VERSION,
        "routes": [
            {"path": "/health", "description": "Health check"},
            {"path": "/api/auth/register", "description": "Register traveler"},
            {"path": "/api/auth/login", "description": "Login & get JWT"},
            {"path": "/api/packages", "description": "Browse travel packages"},
            {"path": "/api/bookings", "description": "Manage bookings"},
            {"path": "/api/admin/analytics", "description": "Admin analytics"},
        ]
    }

@app.get("/health", tags=["Gateway"], response_model=HealthResponse)
async def health_check(client: httpx.AsyncClient = Depends(get_client)):
    """Health check: verifies gateway is alive and probes the Node.js backend."""
    backend_ok = False
    try:
        resp = await client.get(f"{NODE_BACKEND}/health", timeout=3.0)
        backend_ok = resp.status_code == 200
    except Exception:
        backend_ok = False

    return {
        "status": "healthy",
        "gateway": "Explore India FastAPI Gateway",
        "version": GATEWAY_VERSION,
        "backend_reachable": backend_ok,
        "timestamp": time.time(),
    }

# ── Authentication forwarding ─────────────────────────────────────────────────
@app.post("/api/auth/register", tags=["Authentication"], status_code=201)
async def register(
    body: UserRegisterSchema,
    request: Request,
    client: httpx.AsyncClient = Depends(get_client),
    _rl=Depends(rate_limit),
):
    """
    Register a new traveler account.
    
    Demonstrates:
    - **Pydantic** schema validation (name min 2 chars, password min 6 chars)
    - **Dependency injection** (rate limiter, HTTP client)
    - Forwarding to Node.js backend
    """
    return await forward("POST", "/users/register", client, request, body.model_dump())

@app.post("/api/auth/login", tags=["Authentication"])
async def login(
    body: UserLoginSchema,
    request: Request,
    client: httpx.AsyncClient = Depends(get_client),
    _rl=Depends(rate_limit),
):
    """
    Login and receive a JWT token.
    
    Use the returned `token` in the **Authorization: Bearer <token>** header
    for all protected endpoints.
    
    Demo credentials:
    - Traveler: ganesh@test.com / 123456
    - Admin: admin@travelportal.com / admin123
    """
    return await forward("POST", "/users/login", client, request, body.model_dump())

@app.get("/api/auth/profile", tags=["Authentication"])
async def profile(
    request: Request,
    client: httpx.AsyncClient = Depends(get_client),
):
    """Get current user profile (requires Bearer JWT token)."""
    return await forward("GET", "/users/profile", client, request)

# ── Packages ──────────────────────────────────────────────────────────────────
@app.get("/api/packages", tags=["Packages"])
async def get_packages(
    request: Request,
    client: httpx.AsyncClient = Depends(get_client),
    destination: Optional[str] = None,
    category: Optional[str] = None,
    minPrice: Optional[float] = None,
    maxPrice: Optional[float] = None,
    sortBy: Optional[str] = None,
    search: Optional[str] = None,
):
    """
    Browse and filter travel packages.
    Query params: destination, category, minPrice, maxPrice, sortBy, search
    """
    return await forward("GET", "/packages", client, request)

@app.get("/api/packages/{package_id}", tags=["Packages"])
async def get_package(
    package_id: str,
    request: Request,
    client: httpx.AsyncClient = Depends(get_client),
):
    """Get a single travel package by ID."""
    return await forward("GET", f"/packages/{package_id}", client, request)

# ── Bookings ──────────────────────────────────────────────────────────────────
@app.post("/api/bookings", tags=["Bookings"], status_code=201)
async def create_booking(
    request: Request,
    client: httpx.AsyncClient = Depends(get_client),
):
    """Create a booking (requires JWT). Auto-calculates price & reduces seats."""
    body = await request.json()
    return await forward("POST", "/bookings", client, request, body)

@app.get("/api/bookings/mine", tags=["Bookings"])
async def my_bookings(
    request: Request,
    client: httpx.AsyncClient = Depends(get_client),
):
    """Get current user's booking history (requires JWT)."""
    return await forward("GET", "/bookings/mine", client, request)

@app.put("/api/bookings/{booking_id}/cancel", tags=["Bookings"])
async def cancel_booking(
    booking_id: str,
    request: Request,
    client: httpx.AsyncClient = Depends(get_client),
):
    """Cancel booking and restore seats (requires JWT)."""
    return await forward("PUT", f"/bookings/{booking_id}/cancel", client, request)

# ── Payments ──────────────────────────────────────────────────────────────────
@app.post("/api/payments/process", tags=["Payments"], status_code=201)
async def process_payment(
    request: Request,
    client: httpx.AsyncClient = Depends(get_client),
):
    """Simulate payment processing (academic demo, no real money)."""
    body = await request.json()
    return await forward("POST", "/payments/process", client, request, body)

# ── Admin ─────────────────────────────────────────────────────────────────────
@app.get("/api/admin/analytics", tags=["Admin"])
async def admin_analytics(
    request: Request,
    client: httpx.AsyncClient = Depends(get_client),
):
    """Admin analytics dashboard using MongoDB aggregation pipelines (requires admin JWT)."""
    return await forward("GET", "/admin/analytics", client, request)

@app.get("/api/admin/logs", tags=["Admin"])
async def admin_logs(
    request: Request,
    client: httpx.AsyncClient = Depends(get_client),
):
    """Admin audit logs (requires admin JWT)."""
    return await forward("GET", "/admin/logs", client, request)
