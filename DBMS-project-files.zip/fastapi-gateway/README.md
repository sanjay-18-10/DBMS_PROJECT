# Explore India – FastAPI API Gateway (CO3)

This gateway demonstrates **CO3 Backend API Engineering** concepts using **FastAPI**.

## What It Demonstrates
| Concept | Where |
|---------|-------|
| REST API with OpenAPI spec | All routes + `/docs` |
| Pydantic schema validation | `UserRegisterSchema`, `UserLoginSchema` |
| Dependency injection | `Depends(get_client)`, `Depends(rate_limit)` |
| Async HTTP forwarding | `forward()` function with `httpx.AsyncClient` |
| Middleware (timing, CORS) | `add_timing_header` middleware |
| JWT forwarding | `Authorization` header relay |
| Error handling | `HTTPException` with structured responses |
| Rate limiting | In-memory `rate_limit` dependency |
| Health check | `GET /health` |

## How to Run
```bash
cd fastapi-gateway
pip install -r requirements.txt
uvicorn main:app --reload --port 8000
```

Then open: **http://localhost:8000/docs** (Swagger UI)

## Demo Credentials
- Traveler: `ganesh@test.com` / `123456`
- Admin: `admin@travelportal.com` / `admin123`

> Make sure the Node.js backend is running at http://localhost:5000 before using forwarding routes.

## Run Tests
```bash
pytest test_gateway.py -v
```

## Architecture
```
Browser/Client
  ↓ HTTP
FastAPI Gateway (port 8000)
  ↓ Async HTTP (httpx)
Node.js Backend (port 5000)
  ↓ Mongoose
MongoDB (port 27017)
```
