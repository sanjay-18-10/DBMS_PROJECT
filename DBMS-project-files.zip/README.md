# Travel Package Booking Portal

> **Academic DBMS Project Demonstration**  
> **Course Syllabus Alignment**: CO1 (Relational Database Engineering), CO2 (NoSQL & MongoDB), CO3 (Backend, Security & REST APIs)

A complete, production-grade full-stack travel booking portal featuring atomic seat inventory allocation, role-based access control (RBAC), MongoDB aggregation pipelines, simulated payment gateway transactions, and compensating cancellation workflows.

---

## 🚀 Quick Start (Execution in 3 Minutes)

### 1. Prerequisites
- **Node.js** (v18+)
- **MongoDB Server** (Running locally on `mongodb://localhost:27017`)
- **MongoDB Compass** (Optional, for graphical collection inspection)

### 2. Install & Start Backend
Open a terminal in the project root:
```bash
cd backend
npm install
npm run seed       # Safely initializes admin & Indian travel packages
npm run dev        # Starts server on http://localhost:5000 with nodemon
# or: npm start
```

### 3. Open Website in Browser
Navigate directly to:
👉 **[http://localhost:5000](http://localhost:5000)**

---

## 🔑 Demo Credentials

| Role | Email | Password | Permissions |
| :--- | :--- | :--- | :--- |
| **Administrator** | `admin@travelportal.com` | `admin123` | Full Admin Console, Package CRUD, Retiring Tours, Analytics, Audit Trail |
| **Demo Traveler 1** | `ganesh@test.com` | `123456` | Browse packages, book trips, view history, cancel bookings |
| **Demo Traveler 2** | `priya@travel.com` | `password123` | Browse packages, book trips, make payments |

---

## 📂 Project Architecture & Directory Structure

```
Travel-Package-Booking-Portal/
│
├── backend/                             # Express & MongoDB Backend
│   ├── config/                          # MongoDB connection setup
│   │   └── db.js
│   ├── controllers/                     # Application logic & controllers
│   │   ├── adminController.js           # Aggregation pipelines & analytics
│   │   ├── bookingController.js         # Booking creation, cancellation & seat logic
│   │   ├── packageController.js         # Package search, filters, CRUD, retire toggle
│   │   ├── paymentController.js         # Simulated gateway & transaction receipts
│   │   └── userController.js            # Registration, login, profile, user listing
│   ├── middleware/                      # Auth, RBAC & Error Middlewares
│   │   ├── authMiddleware.js            # JWT verification & adminOnly RBAC
│   │   └── errorMiddleware.js           # Mongoose error handler & 404 handler
│   ├── models/                          # Mongoose Database Schemas
│   │   ├── AdminLog.js                  # Administrative audit trail schema
│   │   ├── Booking.js                   # Bookings with references, dates & add-ons
│   │   ├── Package.js                   # Travel packages with indexes & seats
│   │   ├── Payment.js                   # Payment transaction schema
│   │   └── User.js                      # User schema with bcrypt & roles
│   ├── routes/                          # REST API route declarations
│   │   ├── adminRoutes.js
│   │   ├── bookingRoutes.js
│   │   ├── packageRoutes.js
│   │   ├── paymentRoutes.js
│   │   └── userRoutes.js
│   ├── utils/                           # Token generation & safe seeder
│   │   ├── generateToken.js
│   │   └── seedData.js                  # Safe, non-destructive seeder
│   ├── .env                             # Environment configuration
│   ├── .env.example
│   ├── package.json
│   ├── server.js                        # Main Express server entry point
│   └── test.http                        # VS Code REST Client test requests
│
├── frontend/                            # Responsive Single-Page Web Frontend
│   ├── css/
│   │   └── style.css                    # Professional travel-themed stylesheet
│   ├── js/
│   │   ├── api.js                       # Centralized API service & JWT state
│   │   ├── admin.js                     # Admin dashboard & aggregation renderers
│   │   └── app.js                       # Booking flow, search, filters & payments
│   └── index.html                       # Master HTML5 web application
│
├── database/                            # Academic Relational & NoSQL Resources
│   ├── sql/                             # CO1 Relational SQL Demonstration
│   │   ├── schema.sql                   # 3NF normalized tables with foreign keys
│   │   ├── queries.sql                  # DML, filtering, INNER & LEFT JOINs
│   │   ├── advanced_queries.sql         # CTEs, subqueries, and Window Functions
│   │   └── transactions.sql             # ACID procedures and trigger demonstration
│   ├── mongodb/                         # CO2 MongoDB Demonstration
│   │   └── demo_commands.md             # Copy-pasteable mongosh & Compass commands
│   └── README.md                        # SQL vs NoSQL comparative analysis
│
├── fastapi-gateway/                     # CO3 FastAPI API Gateway & OpenAPI
│   ├── main.py                          # Forwarding proxy, Pydantic, rate limiter
│   ├── requirements.txt
│   ├── test_gateway.py                  # Pytest test suite (7/7 passed)
│   └── README.md
│
├── framework-demos/                     # CO4 Multi-Framework Backend Engineering
│   ├── flask-demo/                      # Python Flask 3.x REST API + tests (7/7 passed)
│   ├── django-demo/                     # Django 5.x + DRF with SQLite models & tests (5/5 passed)
│   └── FRAMEWORK_COMPARISON.md          # Architectural comparison matrix
│
├── microservices/                       # CO5 Microservices Architecture
│   ├── user-service/                    # Node.js + MongoDB Auth service (:3001)
│   ├── activity-service/                # Node.js + MongoDB Event tracker (:3002)
│   ├── saga-demo/                       # Distributed Saga Orchestrator & Rollback
│   └── spring-product-service/          # Spring Boot 3 + JPA reference service
│
├── database/                            # CO1 & CO2 Database Engineering
│   ├── postgresql/                      # 3NF Schema, Views, Triggers, Window Functions
│   ├── polyglot/                        # Mongo-to-SQL sync demonstration
│   ├── vector/                          # Vector semantic similarity search (AI DB)
│   ├── mongodb/                         # Compass & mongosh command reference
│   └── sql/                             # Standard SQL demonstration
│
├── docker-compose.yml                   # CO6 Multi-container orchestration
├── docker/                              # Production Dockerfiles for all stacks
├── k8s/                                 # Declarative Kubernetes manifests & Ingress
├── monitoring/                          # Prometheus scrape configs & Grafana specs
├── .github/workflows/ci.yml             # GitHub Actions CI pipeline
│
├── docs/                                # Complete Academic Review Documentation
│   ├── CO1_CO6_MAPPING.md               # Detailed syllabus coverage matrix
│   ├── GUIDE_DEMONSTRATION.md           # Step-by-step presentation checklist
│   ├── C4_ARCHITECTURE.md               # C4 Context, Container & Component models
│   ├── DBMS_CONCEPTS.md                 # All DBMS concepts mapped to the project
│   ├── API_DOCUMENTATION.md             # Complete REST API reference table
│   ├── DATABASE_DESIGN.md               # Data dictionary & Mermaid ER diagram
│   ├── PROJECT_FLOW.md                  # Mermaid architecture & sequence diagrams
│   ├── DEMO_STEPS.md                    # 20-phase step-by-step viva presentation guide
│   └── VIVA_QUESTIONS.md                # 30+ viva questions with direct answers
│
└── README.md                            # Main project documentation
```

---

## 🎓 DBMS & Software Engineering Syllabus Coverage Mapping (CO1–CO6)

| Course Outcome | Key Syllabus Concepts | Where Demonstrated in this Project | Status |
| :--- | :--- | :--- | :--- |
| **CO1: Relational Database Engineering** | 3NF/BCNF Normalization, Constraints, Joins, Triggers, Stored Procedures, Views | `database/postgresql/schema.sql`<br>`database/postgresql/queries.sql`<br>`database/postgresql/transactions.sql` | **IMPLEMENTED** |
| **CO2: Database Engineering & Analytics** | Document Modeling, Aggregations, Polyglot Persistence, Vector Semantic Search | `backend/controllers/adminController.js`<br>`database/polyglot/mongo_to_sql_sync.js`<br>`database/vector/vector_search_demo.py` | **IMPLEMENTED** |
| **CO3: Backend API Engineering** | RESTful Gateway, Pydantic v2, JWT Auth, Dependency Injection, OpenAPI | `fastapi-gateway/main.py`<br>`backend/middleware/authMiddleware.js`<br>`fastapi-gateway/test_gateway.py` | **IMPLEMENTED** |
| **CO4: Multi-Framework Backend Engineering** | Node.js vs FastAPI vs Flask vs Django DRF comparative matrix | `framework-demos/flask-demo/`<br>`framework-demos/django-demo/`<br>`framework-demos/FRAMEWORK_COMPARISON.md` | **IMPLEMENTED** |
| **CO5: Microservices Architecture** | Service Isolation, Event Sourcing, Distributed Saga Pattern with Compensation | `microservices/user-service/`<br>`microservices/activity-service/`<br>`microservices/saga-demo/saga_orchestrator.js` | **IMPLEMENTED** |
| **CO6: Deployment & Observability** | Containerization, Kubernetes manifests, Prometheus telemetry, CI pipeline | `docker-compose.yml`<br>`k8s/`<br>`monitoring/prometheus/`<br>`.github/workflows/ci.yml` | **IMPLEMENTED** |

---

## 📖 Comprehensive Documentation Links

- **[CO1–CO6 Full Syllabus Implementation Matrix](docs/CO1_CO6_MAPPING.md)**
- **[Guide Demonstration Checklist & Walkthrough](docs/GUIDE_DEMONSTRATION.md)**
- **[C4 Architecture Models (Context, Container, Component, Deployment)](docs/C4_ARCHITECTURE.md)**
- **[Framework Comparison Technical Document](framework-demos/FRAMEWORK_COMPARISON.md)**
- **[DBMS Concepts Explained (Format: What / Where / Example / Why / Demo)](docs/DBMS_CONCEPTS.md)**
- **[Step-by-Step 20-Phase Project Guide Demo Script](docs/DEMO_STEPS.md)**
- **[Viva Questions & Answers](docs/VIVA_QUESTIONS.md)**
- **[REST API Documentation](docs/API_DOCUMENTATION.md)**
- **[Database Design & ER Diagram](docs/DATABASE_DESIGN.md)**
- **[Project Sequence & Architecture Flow](docs/PROJECT_FLOW.md)**

