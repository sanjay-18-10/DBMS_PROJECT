# Explore India – Kubernetes Deployment Manifests (CO6)

Demonstrates **CO6: Deployment, Observability & Delivery** via declarative Kubernetes infrastructure-as-code manifests.

## Kubernetes Architecture
- **Namespace (`00-namespace.yaml`)**: Isolates the `explore-india` microservices topology.
- **ConfigMap & Secret (`01-configmap-secrets.yaml`)**: Decouples non-sensitive and sensitive configuration (JWT secrets, Mongo credentials).
- **Stateful Persistence (`02-mongodb-deployment.yaml`)**: Headless MongoDB deployment with cluster-internal DNS.
- **Microservice Deployments (`03-backend-deployment.yaml`, `04-fastapi-gateway-deployment.yaml`)**: Replicated pods with Liveness and Readiness probes.
- **Ingress (`05-ingress.yaml`)**: L7 path routing connecting external HTTP traffic to internal ClusterIP services.

## Application Commands
```bash
kubectl apply -f k8s/00-namespace.yaml
kubectl apply -f k8s/01-configmap-secrets.yaml
kubectl apply -f k8s/02-mongodb-deployment.yaml
kubectl apply -f k8s/03-backend-deployment.yaml
kubectl apply -f k8s/04-fastapi-gateway-deployment.yaml
kubectl apply -f k8s/05-ingress.yaml
```
Check running pods:
```bash
kubectl get pods -n explore-india
```
