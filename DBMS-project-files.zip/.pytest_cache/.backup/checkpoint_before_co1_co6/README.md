# Travel Package Booking Portal

> **Academic DBMS Project Demonstration**  
> **Course Syllabus Alignment**: CO1 (Relational Database Engineering), CO2 (NoSQL & MongoDB), CO3 (Backend, Security & REST APIs)

A complete, production-grade full-stack travel booking portal featuring atomic seat inventory allocation, role-based access control (RBAC), MongoDB aggregation pipelines, simulated payment gateway transactions, and compensating cancellation workflows.

---

## 🚀 Quick Start (Execution in 3 Minutes)

### 1. Prerequisites
- **Node.js** (v18+)
- **MongoDB Server** (Running locally on `mongodb://localhost:27017`)
- **MongoDB Compass** (Optional, for graphical collection inspection)

### 2. Install & Start Backend
Open a terminal in the project root:
```bash
cd backend
npm install
npm run seed       # Safely initializes admin & Indian travel packages
npm run dev        # Starts server on http://localhost:5000 with nodemon
# or: npm start
```

### 3. Open Website in Browser
Navigate directly to:
👉 **[http://localhost:5000](http://localhost:5000)**

---

## 🔑 Demo Credentials

| Role | Email | Password | Permissions |
| :--- | :--- | :--- | :--- |
| **Administrator** | `admin@travelportal.com` | `admin123` | Full Admin Console, Package CRUD, Retiring Tours, Analytics, Audit Trail |
| **Demo Traveler 1** | `ganesh@test.com` | `123456` | Browse packages, book trips, view history, cancel bookings |
| **Demo Traveler 2** | `priya@travel.com` | `password123` | Browse packages, book trips, make payments |

---

## 📂 Project Architecture & Directory Structure

```
Travel-Package-Booking-Portal/
│
├── backend/                             # Express & MongoDB Backend
│   ├── config/                          # MongoDB connection setup
│   │   └── db.js
│   ├── controllers/                     # Application logic & controllers
│   │   ├── adminController.js           # Aggregation pipelines & analytics
│   │   ├── bookingController.js         # Booking creation, cancellation & seat logic
│   │   ├── packageController.js         # Package search, filters, CRUD, retire toggle
│   │   ├── paymentController.js         # Simulated gateway & transaction receipts
│   │   └── userController.js            # Registration, login, profile, user listing
│   ├── middleware/                      # Auth, RBAC & Error Middlewares
│   │   ├── authMiddleware.js            # JWT verification & adminOnly RBAC
│   │   └── errorMiddleware.js           # Mongoose error handler & 404 handler
│   ├── models/                          # Mongoose Database Schemas
│   │   ├── AdminLog.js                  # Administrative audit trail schema
│   │   ├── Booking.js                   # Bookings with references, dates & add-ons
│   │   ├── Package.js                   # Travel packages with indexes & seats
│   │   ├── Payment.js                   # Payment transaction schema
│   │   └── User.js                      # User schema with bcrypt & roles
│   ├── routes/                          # REST API route declarations
│   │   ├── adminRoutes.js
│   │   ├── bookingRoutes.js
│   │   ├── packageRoutes.js
│   │   ├── paymentRoutes.js
│   │   └── userRoutes.js
│   ├── utils/                           # Token generation & safe seeder
│   │   ├── generateToken.js
│   │   └── seedData.js                  # Safe, non-destructive seeder
│   ├── .env                             # Environment configuration
│   ├── .env.example
│   ├── package.json
│   ├── server.js                        # Main Express server entry point
│   └── test.http                        # VS Code REST Client test requests
│
├── frontend/                            # Responsive Single-Page Web Frontend
│   ├── css/
│   │   └── style.css                    # Professional travel-themed stylesheet
│   ├── js/
│   │   ├── api.js                       # Centralized API service & JWT state
│   │   ├── admin.js                     # Admin dashboard & aggregation renderers
│   │   └── app.js                       # Booking flow, search, filters & payments
│   └── index.html                       # Master HTML5 web application
│
├── database/                            # Academic Relational & NoSQL Resources
│   ├── sql/                             # CO1 Relational SQL Demonstration
│   │   ├── schema.sql                   # 3NF normalized tables with foreign keys
│   │   ├── queries.sql                  # DML, filtering, INNER & LEFT JOINs
│   │   ├── advanced_queries.sql         # CTEs, subqueries, and Window Functions
│   │   └── transactions.sql             # ACID procedures and trigger demonstration
│   ├── mongodb/                         # CO2 MongoDB Demonstration
│   │   └── demo_commands.md             # Copy-pasteable mongosh & Compass commands
│   └── README.md                        # SQL vs NoSQL comparative analysis
│
├── fastapi-demo/                        # CO3 Python / FastAPI Demonstration Module
│   ├── main.py                          # FastAPI with Pydantic & Dependency Injection
│   ├── requirements.txt
│   └── README.md
│
├── docs/                                # Complete Academic Review Documentation
│   ├── DBMS_CONCEPTS.md                 # All DBMS concepts mapped to the project
│   ├── API_DOCUMENTATION.md             # Complete REST API reference table
│   ├── DATABASE_DESIGN.md               # Data dictionary & Mermaid ER diagram
│   ├── PROJECT_FLOW.md                  # Mermaid architecture & sequence diagrams
│   ├── DEMO_STEPS.md                    # 20-phase step-by-step viva presentation guide
│   └── VIVA_QUESTIONS.md                # 30+ viva questions with direct answers
│
└── README.md                            # Main project documentation
```

---

## 🎓 DBMS Syllabus Coverage Mapping

| Syllabus Unit | Key Concepts | Where Demonstrated in this Project |
| :--- | :--- | :--- |
| **CO1: Relational Database Engineering** | 3NF Normalization, DDL, Constraints, Joins, CTEs, Window Functions, ACID Transactions, Stored Procedures, Triggers | `database/sql/schema.sql`<br>`database/sql/queries.sql`<br>`database/sql/advanced_queries.sql`<br>`database/sql/transactions.sql` |
| **CO2: SQL and NoSQL** | MongoDB, BSON, Document Modeling, Compound B-Tree Indexing, Text Search, Aggregation Pipelines (`$group`, `$lookup`, `$sum`) | `backend/models/*.js`<br>`backend/controllers/adminController.js`<br>`database/mongodb/demo_commands.md` |
| **CO3: Backend, API & Security** | REST APIs, JWT Authentication, RBAC, Password Hashing (bcrypt), FastAPI, Pydantic, Dependency Injection | `backend/middleware/authMiddleware.js`<br>`backend/controllers/userController.js`<br>`fastapi-demo/main.py` |

---

## 📖 Comprehensive Documentation Links

- **[DBMS Concepts Explained (Format: What / Where / Example / Why / Demo)](docs/DBMS_CONCEPTS.md)**
- **[Step-by-Step 20-Phase Project Guide Demo Script](docs/DEMO_STEPS.md)**
- **[Viva Questions & Answers](docs/VIVA_QUESTIONS.md)**
- **[REST API Documentation](docs/API_DOCUMENTATION.md)**
- **[Database Design & ER Diagram](docs/DATABASE_DESIGN.md)**
- **[Project Sequence & Architecture Flow](docs/PROJECT_FLOW.md)**
- **[MongoDB Compass & Shell Commands](database/mongodb/demo_commands.md)**
- **[FastAPI Demo Module](fastapi-demo/README.md)**
