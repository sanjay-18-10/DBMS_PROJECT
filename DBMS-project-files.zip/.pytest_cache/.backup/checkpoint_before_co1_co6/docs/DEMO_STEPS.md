# Step-by-Step Project Guide Demonstration Script

Follow this script during your academic project review or final viva to demonstrate the **Travel Package Booking Portal** seamlessly.

---

## Pre-Demo Checklist
- [x] MongoDB Server running locally on port `27017`
- [x] MongoDB Compass opened and connected to `mongodb://localhost:27017`
- [x] Terminal ready in `backend/` directory
- [x] Browser open at `http://localhost:5000`

---

## Phase 1: Start MongoDB
**Action**:
Show the running MongoDB server:
- Open Windows PowerShell or Services:
  ```powershell
  Get-Service -Name "*mongo*"
  ```
- Or show the connection in MongoDB Compass: `mongodb://localhost:27017`.
**Viva Talking Point**: *"Our project uses MongoDB Server 8.3 as our primary high-performance document database."*

---

## Phase 2: Open VS Code
**Action**:
- Open the root folder `Travel-Package-Booking-Portal` in VS Code.
- Point out the clean modular structure:
  - `backend/`: Server, REST controllers, Mongoose schemas, JWT middleware
  - `frontend/`: Single-page responsive travel UI
  - `database/`: Academic SQL scripts (3NF) and MongoDB command scripts
  - `fastapi-demo/`: CO3 FastAPI demonstration module
  - `docs/`: Comprehensive DBMS documentation

---

## Phase 3: Start the Backend Server
**Action**:
In the VS Code integrated terminal:
```bash
cd backend
npm run dev
# or: node server.js
```
**Observation**: Terminal prints:
```
MongoDB connected successfully
🚀 Travel Booking Portal Server Running
📍 Local URL: http://localhost:5000
📡 API Base:  http://localhost:5000/api
```

---

## Phase 4: Show Project Folder Structure
**Action**:
Expand the folders in the VS Code sidebar and explain the MVC / Layered architecture:
- `backend/models/`: Encapsulates schema definitions, constraints, and indexes.
- `backend/controllers/`: Contains core business logic (booking price calculations, seat reduction, aggregations).
- `backend/routes/`: Declares RESTful endpoints and binds auth middlewares.
- `backend/middleware/`: Handles token decoding, error formatting, and RBAC protection.

---

## Phase 5: Show MongoDB Database in Compass
**Action**:
- Switch to **MongoDB Compass**.
- Click database `travel_booking`.
- Show the 5 collections:
  1. `users`
  2. `packages`
  3. `bookings`
  4. `payments`
  5. `adminlogs`
- Click `packages` and show the documents (Kerala, Goa, Himachal, Rajasthan, etc.).
- Note the current `availableSeats` on a package (e.g. `availableSeats: 25` for Goa).

---

## Phase 6: Register a New Traveler
**Action**:
- Open browser to `http://localhost:5000`.
- Click the **Register** button in the top navigation bar.
- Enter details:
  - Name: `Amit Kumar`
  - Email: `amit@example.com`
  - Phone: `9876543210`
  - Password: `password123`
- Click **Register Account**.
- **Observation**: Toast appears: *"Account created successfully! You are now logged in."*
- User badge updates to: `👤 Amit Kumar [USER]`.

---

## Phase 7 & 8: Show Login & JWT Token
**Action**:
- Open browser DevTools (**F12**) → **Application** tab → **Local Storage** → `http://localhost:5000`.
- Point out the stored keys:
  - `travel_token`: Signed JSON Web Token (JWT)
  - `travel_user`: User metadata (`_id`, `name`, `email`, `role: "user"`)
**Viva Talking Point**: *"We use stateless JWT authentication. The token contains the user's ID and role encoded cryptographically using HMAC-SHA256, protecting against tampering."*

---

## Phase 9: Browse & Filter Travel Packages
**Action**:
- Click **Explore Packages** in the navbar.
- Click category pills: **Beach**, **Mountain**, **Heritage**, **Spiritual**.
- Notice the package cards filter instantly.
- In the search box, type `"Goa"` or `"Kerala"`.
- Use the sort dropdown to sort by **Price: Low to High**.

---

## Phase 10: Create a Booking
**Action**:
- Click **Book Now** on the **Goa Sun, Sands & Heritage Getaway** package.
- The interactive booking modal opens.
- Set Departure Date: e.g. next month.
- Change Number of Travelers: set to `3`.
- Check an Add-on: *"Airport Pickup & Drop (₹1,200)"*.

---

## Phase 11: Show Automatic Price Calculation
**Action**:
- Point out the live **Price Summary Box** inside the booking modal:
  - Base Package Fare: `₹12,500 × 3 = ₹37,500`
  - Add-ons: `₹1,200`
  - Total Payable: `₹38,700`
- Change travelers from `3` to `4` → show the total instantly recompute to `₹51,200`.
- Click **Confirm & Pay 💳**.

---

## Phase 12: Show Automatic Seat Reduction
**Action**:
- Look at the Goa package card in the background:
  - Previous available seats: `25`
  - New available seats: `21` (automatically reduced by 4!)
**Viva Talking Point**: *"This demonstrates atomic inventory management and concurrency protection. The system decrements availableSeats in MongoDB so no other traveler can overbook."*

---

## Phase 13: Simulated Payment Demonstration
**Action**:
- The simulated payment modal appears automatically.
- Point out: *"Demo payment — no real money is charged."*
- Click **Autofill Test Card**.
- Click **Authorize & Pay (Demo) 🔒**.
- **Observation**: The receipt confirmation modal appears with:
  - Booking Reference: `PKG-XXXX-XXXX`
  - Transaction ID: `TXN-XXXXXX-XXXX`
  - Payment Method: `Card`
  - Status: Confirmed & Paid
- Click **Print Receipt 🖨️** or **Go to Dashboard**.

---

## Phase 14: Show Booking in MongoDB Compass
**Action**:
- Switch to MongoDB Compass.
- Refresh the `bookings` collection.
- Show the newly inserted booking:
  - `status: "Confirmed"`
  - `paymentStatus: "Paid"`
  - `totalPrice: 51200`
  - `numberOfPeople: 4`
  - `user`: References Amit Kumar's ObjectId
  - `package`: References Goa's ObjectId
- Open the `payments` collection to show the corresponding payment record with transaction ID.

---

## Phase 15: Booking Cancellation & Seat Restoration
**Action**:
- In the browser, navigate to **My Bookings** (Traveler Dashboard).
- Find the booking just made.
- Click **Cancel**. Confirm the prompt.
- **Observation**: Status updates to `Cancelled`.
- Check the Goa package seats: seats have been **automatically restored** back from `21` to `25`!
**Viva Talking Point**: *"This is a compensating transaction ensuring database consistency when an order is cancelled."*

---

## Phase 16: Admin Login & RBAC Enforcement
**Action**:
- Click **Logout**.
- Click **Login** → click **Admin (admin)** demo button:
  - Email: `admin@travelportal.com`
  - Password: `admin123`
- Click **Sign In**.
- Notice the new golden link in the navbar: **Admin Dashboard ⚙️**.
- Click **Admin Dashboard ⚙️**.

---

## Phase 17: Admin Management (CRUD, Retiring Packages)
**Action**:
- In Admin Console, show **Package Inventory** tab:
- Click **Retire** on a package → status becomes `Retired`.
  - Switch to user catalog: retired package is no longer visible to normal travelers!
- Click **Activate** to reactivate it.
- Click **+ Create New Package** to demonstrate adding a new tour.

---

## Phase 18: Admin Analytics (MongoDB Aggregation Pipelines)
**Action**:
- Click the **Aggregation Analytics** tab.
- Show the guide:
  - Destination Sales Breakdown: computed using `$group` on `destination` and `$sum` on `totalPrice`.
  - Top Booked Packages: computed using `$sort` and `$limit` on booking counts.
- Show the KPI cards: Total Travelers, Active Packages, Total Bookings, Verified Revenue.

---

## Phase 19: API Testing via `backend/test.http`
**Action**:
- Switch to VS Code.
- Open `backend/test.http`.
- Show how the REST Client runs requests directly inside VS Code:
  - Run request `#1 Health Check` (`GET http://localhost:5000/api/health`)
  - Run request `#8 Get Packages`
  - Run request `#17 Test Insufficient Seats Validation` (demonstrating `HTTP 400 Bad Request`)

---

## Phase 20: Explain DBMS Concepts & RDBMS Demonstration
**Action**:
- Open `docs/DBMS_CONCEPTS.md` and `database/README.md`.
- Open `database/sql/schema.sql` and `database/sql/advanced_queries.sql`.
- Explain how our project covers:
  - **CO1**: 3NF Normalized relational schema, CTEs, Window Functions, Triggers, and ACID Procedures.
  - **CO2**: MongoDB document model, B-Tree compound indexing, `$lookup` joins, and aggregation pipelines.
  - **CO3**: REST APIs, JWT authentication, RBAC authorization, and FastAPI micro-demo in `fastapi-demo/`.
