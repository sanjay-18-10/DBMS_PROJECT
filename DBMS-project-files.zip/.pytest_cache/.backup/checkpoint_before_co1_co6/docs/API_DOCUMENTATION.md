# API Documentation: Travel Package Booking Portal

Base URL: `http://localhost:5000/api`

All protected endpoints require an HTTP `Authorization` header containing the JWT token issued upon registration or login:
```http
Authorization: Bearer <your_jwt_token_here>
```

---

## 1. Authentication & User Management

### `POST /users/register`
- **Access**: Public
- **Description**: Registers a new customer or administrator account.
- **Request Body**:
```json
{
  "name": "Rahul Verma",
  "email": "rahul@example.com",
  "password": "password123",
  "phone": "9876543210",
  "role": "user"
}
```
- **Response (201 Created)**:
```json
{
  "message": "User registered successfully",
  "user": {
    "_id": "6ab67...",
    "name": "Rahul Verma",
    "email": "rahul@example.com",
    "phone": "9876543210",
    "role": "user"
  },
  "token": "eyJhbGciOi..."
}
```

### `POST /users/login`
- **Access**: Public
- **Description**: Authenticates user via email and hashed password comparison; returns signed JWT.
- **Request Body**:
```json
{
  "email": "ganesh@test.com",
  "password": "123456"
}
```
- **Response (200 OK)**:
```json
{
  "message": "Login successful",
  "user": {
    "_id": "6ab3c16...",
    "name": "ganesh",
    "email": "ganesh@test.com",
    "phone": "9876543210",
    "role": "user"
  },
  "token": "eyJhbGciOi..."
}
```

### `GET /users/profile`
- **Access**: Private (Traveler / Admin)
- **Description**: Returns profile data of currently authenticated user.

### `PUT /users/profile`
- **Access**: Private (Traveler / Admin)
- **Description**: Updates profile details (name, phone, password).

### `GET /users`
- **Access**: Private (Admin Only)
- **Description**: Returns list of all registered users without passwords.

---

## 2. Travel Packages Management

### `GET /packages`
- **Access**: Public
- **Description**: Retrieves packages catalog with optional search, category, destination, price range, and sorting.
- **Query Parameters**:
  - `search`: Keyword string matching package name, destination, or description.
  - `destination`: Destination string filter (e.g. `Goa`, `Kerala`).
  - `category`: Category string (`Beach`, `Mountain`, `Heritage`, `Spiritual`, `Holiday`).
  - `minPrice`, `maxPrice`: Numeric price range filters.
  - `duration`: Trip duration in days.
  - `sortBy`: `price_asc`, `price_desc`, `duration_desc`, `seats_desc`, `newest`.
  - `includeInactive`: `true` for administrators to view retired packages.
- **Response (200 OK)**: Array of package documents.

### `GET /packages/:id`
- **Access**: Public
- **Description**: Retrieves a single package document by its unique MongoDB `_id`.

### `POST /packages`
- **Access**: Private (Admin Only)
- **Description**: Inserts a new travel package into inventory and logs audit record.
- **Request Body**:
```json
{
  "name": "Royal Rajasthan Heritage & Forts Trail",
  "destination": "Rajasthan",
  "description": "Marvel at Jaipur's Amer Fort, Udaipur's Lake Palace...",
  "price": 28000,
  "duration": 7,
  "availableSeats": 18,
  "category": "Heritage",
  "featured": true,
  "highlights": ["Amer Fort Tour", "Lake Pichola Boat Ride"]
}
```

### `PUT /packages/:id`
- **Access**: Private (Admin Only)
- **Description**: Modifies price, duration, available seats, or description of an existing package.

### `PATCH /packages/:id/status`
- **Access**: Private (Admin Only)
- **Description**: Toggles active/retired status of a package (`isActive: true/false`).

### `DELETE /packages/:id`
- **Access**: Private (Admin Only)
- **Description**: Deletes package; enforces referential integrity constraint (rejects if active bookings reference this package).

---

## 3. Bookings & Seat Allocation

### `POST /bookings`
- **Access**: Public / Private (Authenticated user identity preferred)
- **Description**: Atomically reserves package seats, validates inventory constraints, calculates total price including optional add-ons, generates unique booking reference code.
- **Request Body**:
```json
{
  "package": "6ab3c48...",
  "numberOfPeople": 2,
  "travelDate": "2026-11-20",
  "specialPreferences": "Vegetarian meal on flight",
  "addOns": [
    { "name": "Airport Pickup & Drop", "price": 1200 },
    { "name": "Travel Insurance", "price": 500 }
  ]
}
```
- **Response (201 Created)**:
```json
{
  "message": "Booking created successfully",
  "booking": {
    "_id": "6ab67...",
    "bookingReference": "PKG-2946-8980",
    "totalPrice": 31700,
    "numberOfPeople": 2,
    "status": "Pending",
    "paymentStatus": "Unpaid"
  }
}
```

### `GET /bookings/mine`
- **Access**: Private (Traveler)
- **Description**: Returns all bookings associated with the currently authenticated traveler.

### `GET /bookings`
- **Access**: Private (Admin Only)
- **Description**: Returns all bookings in the system; supports `?status=Confirmed` query filter.

### `GET /bookings/:id`
- **Access**: Private (Owner or Admin)
- **Description**: Returns detailed single booking with populated user and package information.

### `PUT /bookings/:id/cancel`
- **Access**: Private (Owner or Admin)
- **Description**: Cancels booking and executes a compensating transaction that restores the reserved seats back to the package available inventory.

---

## 4. Simulated Payments

### `POST /payments/process`
- **Access**: Public / Private
- **Description**: Processes simulated payment, generates a transaction ID (`TXN-XXXXXX`), sets `paymentStatus = "Paid"`, and updates booking status to `"Confirmed"`.
- **Request Body**:
```json
{
  "bookingId": "6ab67...",
  "paymentMethod": "Card"
}
```

### `GET /payments/booking/:bookingId`
- **Access**: Private
- **Description**: Retrieves invoice / payment receipt for a specific booking.

### `GET /payments`
- **Access**: Private (Admin Only)
- **Description**: Returns complete log of payment transactions.

---

## 5. Admin Analytics & Audit Logs

### `GET /admin/analytics`
- **Access**: Private (Admin Only)
- **Description**: Executes MongoDB Aggregation Pipelines to return total users, packages, bookings, paid revenue, revenue by destination, and popular packages.

### `GET /admin/logs`
- **Access**: Private (Admin Only)
- **Description**: Returns chronological audit logs of all administrative actions.
