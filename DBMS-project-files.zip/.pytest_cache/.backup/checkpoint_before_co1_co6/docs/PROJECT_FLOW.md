# Project Flow & Architecture: Travel Package Booking Portal

## 1. System Architecture Overview

```mermaid
flowchart TD
    subgraph Client["Frontend Layer (Client Browser)"]
        UI["Modern Web Interface (HTML5 / CSS3 / ES6)"]
        API_CLIENT["Central API Service (api.js)"]
        AUTH_STORAGE["Token Storage (localStorage)"]
    end

    subgraph Server["Backend Layer (Node.js & Express)"]
        EXPRESS["Express.js Server (server.js)"]
        ROUTER["API Router (/api/*)"]
        AUTH_MW["Auth & RBAC Middleware"]
        CONTROLLERS["Controllers (user, package, booking, payment, admin)"]
        MONGOOSE["Mongoose ODM (Schema & Validation)"]
    end

    subgraph Database["Database Layer (MongoDB Server)"]
        COLL_USERS[("users Collection")]
        COLL_PACKAGES[("packages Collection")]
        COLL_BOOKINGS[("bookings Collection")]
        COLL_PAYMENTS[("payments Collection")]
        COLL_LOGS[("adminlogs Collection")]
    end

    UI --> API_CLIENT
    API_CLIENT --> AUTH_STORAGE
    API_CLIENT -- "HTTP / JSON (REST APIs)" --> EXPRESS
    EXPRESS --> ROUTER
    ROUTER --> AUTH_MW
    AUTH_MW --> CONTROLLERS
    CONTROLLERS --> MONGOOSE
    MONGOOSE --> Database
```

---

## 2. User Registration & JWT Authentication Sequence

```mermaid
sequenceDiagram
    autonumber
    actor Traveler as Traveler (Client)
    participant API as Express API
    participant UserCtrl as User Controller
    participant DB as MongoDB (users)

    Traveler->>API: POST /api/users/login (email, password)
    API->>UserCtrl: loginUser(email, password)
    UserCtrl->>DB: findOne({ email })
    DB-->>UserCtrl: user document (with bcrypt password hash)
    UserCtrl->>UserCtrl: bcrypt.compare(password, user.password)
    alt Password Invalid
        UserCtrl-->>Traveler: 401 Unauthorized ("Invalid credentials")
    else Password Valid
        UserCtrl->>UserCtrl: generateToken(user._id, user.role)
        UserCtrl-->>Traveler: 200 OK + JWT Token + User Object
        Traveler->>Traveler: Store token in localStorage
    end
```

---

## 3. Booking Creation & Automatic Seat Reduction Workflow

```mermaid
sequenceDiagram
    autonumber
    actor Traveler as Traveler
    participant API as Express API
    participant BookingCtrl as Booking Controller
    participant DB as MongoDB Collections

    Traveler->>API: POST /api/bookings (packageId, numberOfPeople, addOns)
    API->>BookingCtrl: createBooking()
    BookingCtrl->>DB: Package.findById(packageId)
    DB-->>BookingCtrl: package (price, availableSeats, isActive)

    alt Seats Insufficient or Package Retired
        BookingCtrl-->>Traveler: 400 Bad Request ("Not enough seats available")
    else Seats Available
        BookingCtrl->>BookingCtrl: Compute: (BasePrice * Travelers) + AddOns
        BookingCtrl->>BookingCtrl: Generate unique bookingReference ("PKG-YYYY-XXXX")
        BookingCtrl->>DB: Booking.create({ status: "Pending", paymentStatus: "Unpaid" })
        BookingCtrl->>DB: Package.updateOne({ $inc: { availableSeats: -numberOfPeople } })
        DB-->>BookingCtrl: Seat inventory reduced
        BookingCtrl-->>Traveler: 201 Created (Booking details + updated seats)
    end
```

---

## 4. Simulated Payment Gateway Flow

```mermaid
sequenceDiagram
    autonumber
    actor Traveler as Traveler
    participant API as Express API
    participant PaymentCtrl as Payment Controller
    participant DB as MongoDB Collections

    Traveler->>API: POST /api/payments/process (bookingId, paymentMethod)
    API->>PaymentCtrl: processPayment()
    PaymentCtrl->>DB: Booking.findById(bookingId)
    DB-->>PaymentCtrl: booking document

    PaymentCtrl->>PaymentCtrl: Generate transactionId ("TXN-...")
    PaymentCtrl->>DB: Payment.create({ bookingId, transactionId, status: "Success" })
    PaymentCtrl->>DB: Booking.updateOne({ status: "Confirmed", paymentStatus: "Paid" })
    DB-->>PaymentCtrl: Updated documents
    PaymentCtrl-->>Traveler: 201 Created (Payment receipt + confirmed booking)
```

---

## 5. Cancellation & Seat Restoration Workflow

```mermaid
sequenceDiagram
    autonumber
    actor Traveler as Traveler
    participant API as Express API
    participant BookingCtrl as Booking Controller
    participant DB as MongoDB Collections

    Traveler->>API: PUT /api/bookings/:id/cancel
    API->>BookingCtrl: cancelBooking(bookingId)
    BookingCtrl->>DB: Booking.findById(bookingId)
    DB-->>BookingCtrl: booking (status, numberOfPeople, package)

    BookingCtrl->>DB: Booking.updateOne({ status: "Cancelled", paymentStatus: "Refunded" })
    BookingCtrl->>DB: Package.updateOne({ $inc: { availableSeats: +booking.numberOfPeople } })
    BookingCtrl->>DB: AdminLog.create({ action: "CANCEL_BOOKING" })
    DB-->>BookingCtrl: Seats restored to package inventory
    BookingCtrl-->>Traveler: 200 OK ("Booking cancelled and seats restored")
```
