# Database Design & Data Dictionary: Travel Package Booking Portal

## 1. Entity-Relationship (ER) Diagram

```mermaid
erDiagram
    USER ||--o{ BOOKING : places
    PACKAGE ||--o{ BOOKING : contains
    BOOKING ||--|| PAYMENT : generates
    USER ||--o{ ADMIN_LOG : performs

    USER {
        ObjectId _id PK
        string name
        string email UK
        string password
        string phone
        string role
        date createdAt
        date updatedAt
    }

    PACKAGE {
        ObjectId _id PK
        string name
        string destination
        string description
        number price
        number duration
        number availableSeats
        string category
        string image
        boolean featured
        boolean isActive
        array highlights
        date createdAt
    }

    BOOKING {
        ObjectId _id PK
        string bookingReference UK
        ObjectId user FK
        ObjectId package FK
        date travelDate
        number numberOfPeople
        number totalPrice
        string specialPreferences
        array addOns
        string paymentStatus
        string status
        date createdAt
    }

    PAYMENT {
        ObjectId _id PK
        ObjectId booking FK
        ObjectId user FK
        number amount
        string transactionId UK
        string paymentMethod
        string paymentStatus
        string paymentNote
        date createdAt
    }

    ADMIN_LOG {
        ObjectId _id PK
        ObjectId admin FK
        string action
        string targetEntity
        string targetId
        string details
        date createdAt
    }
```

---

## 2. Data Dictionary

### Collection 1: `users`
| Field | BSON Type | Constraints | Description |
| :--- | :--- | :--- | :--- |
| `_id` | ObjectId | Primary Key, Auto | Unique user identifier |
| `name` | String | Required, Trimmed | Full name of the user |
| `email` | String | Required, Unique, Lowercase, Regex | Email address used for login |
| `password` | String | Required, Min 6 chars | Salted bcrypt hash of password |
| `phone` | String | Required, Trimmed | Contact telephone number |
| `role` | String | Enum: `['user', 'admin']`, Default: `'user'` | Role-based access permission level |
| `createdAt` | Date | Timestamp | Account creation timestamp |
| `updatedAt` | Date | Timestamp | Last account update timestamp |

### Collection 2: `packages`
| Field | BSON Type | Constraints | Description |
| :--- | :--- | :--- | :--- |
| `_id` | ObjectId | Primary Key, Auto | Unique travel package identifier |
| `name` | String | Required, Trimmed | Package commercial name |
| `destination` | String | Required, Trimmed | Primary destination location |
| `description` | String | Required | Comprehensive trip description |
| `price` | Number | Required, `min: 0` | Price per traveler in INR |
| `duration` | Number | Required, `min: 1` | Total tour duration in days |
| `availableSeats`| Number | Required, `min: 0` | Current available seat inventory |
| `category` | String | Enum: `['Beach', 'Mountain', 'Heritage', 'Holiday', ...]` | Vacation category/theme |
| `image` | String | Valid URL | Visual cover image URL |
| `featured` | Boolean | Default: `false` | Highlighted on homepage showcase |
| `isActive` | Boolean | Default: `true` | Active or retired/deactivated status |
| `highlights` | Array[String]| List | Key itinerary milestones |

### Collection 3: `bookings`
| Field | BSON Type | Constraints | Description |
| :--- | :--- | :--- | :--- |
| `_id` | ObjectId | Primary Key, Auto | Unique booking document identifier |
| `bookingReference`| String | Unique, Auto-generated | Formatted customer booking code (e.g. `PKG-2946-8980`) |
| `user` | ObjectId | Foreign Reference (`User`) | ID of the traveler who booked |
| `package` | ObjectId | Foreign Reference (`Package`) | ID of the travel package reserved |
| `travelDate` | Date | Required | Departure date |
| `numberOfPeople`| Number | Required, `min: 1` | Number of travelers |
| `totalPrice` | Number | Required, `min: 0` | Computed base price + add-ons |
| `specialPreferences`| String | Optional | Traveler preferences/requests |
| `addOns` | Array[Object]| Embedded documents | Selected add-ons (`{ name, price }`) |
| `paymentStatus` | String | Enum: `['Unpaid', 'Paid', 'Refunded']` | Transaction settlement status |
| `status` | String | Enum: `['Pending', 'Confirmed', 'Cancelled']` | Operational reservation status |

### Collection 4: `payments`
| Field | BSON Type | Constraints | Description |
| :--- | :--- | :--- | :--- |
| `_id` | ObjectId | Primary Key, Auto | Unique payment document identifier |
| `booking` | ObjectId | Foreign Reference (`Booking`) | Associated booking identifier |
| `user` | ObjectId | Foreign Reference (`User`) | User who authorized payment |
| `amount` | Number | Required, `min: 0` | Transaction currency amount (INR) |
| `transactionId` | String | Required, Unique | Gateway transaction reference |
| `paymentMethod` | String | Enum: `['Card', 'UPI', 'NetBanking', 'DemoWallet']` | Settlement instrument |
| `paymentStatus` | String | Enum: `['Success', 'Failed', 'Refunded']` | Status of simulated gateway |
| `paymentNote` | String | Default note | Academic demo safety warning |

### Collection 5: `adminlogs`
| Field | BSON Type | Constraints | Description |
| :--- | :--- | :--- | :--- |
| `_id` | ObjectId | Primary Key, Auto | Unique audit log identifier |
| `admin` | ObjectId | Foreign Reference (`User`) | Admin account that executed action |
| `action` | String | Required | Action code (`CREATE_PACKAGE`, `RETIRE_PACKAGE`, etc.) |
| `targetEntity` | String | Enum: `['Package', 'Booking', 'User', 'System']` | Entity altered |
| `targetId` | String | Optional | Primary key of target document |
| `details` | String | Required | Human-readable audit description |

---

## 3. Database Indexes Specification

| Collection | Indexed Fields | Index Type | Purpose |
| :--- | :--- | :--- | :--- |
| `users` | `{ email: 1 }` | Unique B-Tree | Fast lookup for login & prevent duplicate emails |
| `packages` | `{ destination: 1, price: 1 }` | Compound B-Tree | Optimizes destination search with price filtering |
| `packages` | `{ isActive: 1 }` | Single Field | Rapid filtering of active catalog from retired packages |
| `packages` | `{ name: "text", destination: "text", description: "text" }` | Text Index | Full-text keyword search across travel titles and descriptions |
| `bookings` | `{ user: 1 }` | Single Field | Instant retrieval of customer booking history |
| `bookings` | `{ package: 1 }` | Single Field | Rapid calculation of package-level booking counts & referential checks |
| `bookings` | `{ bookingReference: 1 }` | Unique B-Tree | Exact-match lookup by booking reference code |
| `payments` | `{ booking: 1 }` | Single Field | Fast invoice and receipt lookup for a booking |
| `payments` | `{ transactionId: 1 }` | Unique B-Tree | Verification of unique payment transactions |
| `adminlogs` | `{ createdAt: -1 }` | Descending B-Tree | Reverse chronological audit trail queries |
