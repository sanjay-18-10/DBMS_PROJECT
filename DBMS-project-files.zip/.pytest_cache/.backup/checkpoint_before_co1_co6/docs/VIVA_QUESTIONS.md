# DBMS Viva Preparation Guide & Frequently Asked Questions

This guide contains the most critical conceptual and project-specific questions asked during B.Tech DBMS project reviews and viva examinations, with simple, direct answers.

---

## Part 1: Core DBMS & NoSQL Concepts

### 1. What is a DBMS?
**Answer**: A Database Management System (DBMS) is software that manages, stores, organizes, and retrieves data while ensuring security, data integrity, and concurrent access (e.g., MongoDB, MySQL, Oracle).

### 2. Why did you choose MongoDB for this project?
**Answer**:
1. **Dynamic Schema**: Travel packages have flexible, varying structures (itinerary highlights, optional add-ons, photos) that fit JSON/BSON documents naturally.
2. **High Read Performance**: Allows fast searching and catalog filtering with compound and text B-Tree indexes.
3. **Horizontal Scalability**: Sharding and replica sets allow seamless handling of high holiday booking traffic.

### 3. What is the difference between SQL and NoSQL?
**Answer**:
- **SQL (Relational)**: Structured, tabular (rows and columns), predefined strict schema, vertically scalable, uses SQL for querying, excels at strict ACID multi-table transactions.
- **NoSQL (Document/MongoDB)**: Semi-structured, JSON/BSON document collections, dynamic schema, horizontally scalable, optimized for developer velocity and rapid read/write throughput.

### 4. What is a Document in MongoDB?
**Answer**: A document is the basic unit of data in MongoDB, composed of field-and-value pairs (similar to a JSON object). It is stored on disk in BSON format.

### 5. What is BSON?
**Answer**: BSON stands for **Binary JSON**. It is a binary-encoded serialization format used by MongoDB to store documents. Unlike plain JSON, BSON supports additional data types such as `ObjectId`, `Date`, and raw binary bytes, and allows faster traversal.

### 6. What is a Collection in MongoDB?
**Answer**: A collection is a grouping of MongoDB documents, equivalent to a Table in an RDBMS. Unlike relational tables, collections do not enforce a rigid uniform schema on every document by default.

### 7. What is a Schema in Mongoose?
**Answer**: A Mongoose schema defines the document structure, default values, validators, types, and constraints (like `required`, `unique`, `min`) at the application layer before documents are written to MongoDB.

### 8. What is Normalization?
**Answer**: Normalization is the systematic technique of organizing relational database tables to reduce data redundancy and eliminate insertion, update, and deletion anomalies (typically achieving 1NF, 2NF, and 3NF).

### 9. What is Indexing and why is it important?
**Answer**: An index is an auxiliary data structure (typically a B-Tree) that stores a sorted reference to indexed fields. It dramatically accelerates search and query speeds from an \(O(N)\) full collection scan (`COLLSCAN`) to an \(O(\log N)\) index scan (`IXSCAN`).

### 10. What is the MongoDB Aggregation Framework?
**Answer**: A multi-stage processing pipeline where documents pass through stages like `$match` (filtering), `$group` (summarizing), `$lookup` (joining), `$sort`, and `$project` to calculate real-time analytics such as total revenue, top destinations, and booking counts.

### 11. What is CRUD?
**Answer**: The four fundamental persistent operations: **Create** (`insertOne`/`create`), **Read** (`find`), **Update** (`updateOne`/`findByIdAndUpdate`), and **Delete** (`deleteOne`/`findByIdAndDelete`).

---

## Part 2: Backend Architecture & Security Concepts

### 12. What is REST and a REST API?
**Answer**: REST (Representational State Transfer) is an architectural style for designing networked applications. It uses standard HTTP methods (`GET` for reading, `POST` for creating, `PUT`/`PATCH` for updating, `DELETE` for removing) and stateless communication with standard JSON payloads.

### 13. What is JWT (JSON Web Token)?
**Answer**: JWT is a compact, URL-safe means of transferring claims between two parties. It consists of three base64url-encoded parts:
1. **Header** (algorithm: HMAC-SHA256)
2. **Payload** (user ID, role, expiration)
3. **Signature** (verifies that the sender is genuine and data hasn't been tampered with).

### 14. What is RBAC (Role-Based Access Control)?
**Answer**: An authorization security approach where system access is restricted based on user roles. In our project:
- Normal travelers (`role: "user"`) can browse packages, book trips, and view their own history.
- Administrators (`role: "admin"`) can create packages, retire tours, inspect all bookings, and view analytics.

### 15. What is Password Hashing and why use bcrypt?
**Answer**: Hashing is a one-way mathematical function that converts plain-text passwords into an irreversible hash digest. We use **bcryptjs** with cryptographic salting (random bits added before hashing) to defend against dictionary attacks and rainbow table lookups. Passwords are never stored in plain text.

### 16. What is the difference between Authentication and Authorization?
**Answer**:
- **Authentication**: *"Who are you?"* (Verifying email and password credentials).
- **Authorization**: *"What permissions do you have?"* (Determining whether an authenticated user can access admin APIs).

### 17. What are the ACID Properties?
**Answer**:
- **Atomicity**: All changes succeed, or the entire transaction is rolled back (all-or-nothing).
- **Consistency**: Database invariants and schema constraints are strictly preserved.
- **Isolation**: Concurrent operations do not interfere with each other.
- **Durability**: Committed data remains stored permanently even in system failure.

### 18. Why are Controllers, Routes, Models, and Middleware separated (MVC)?
**Answer**: Separation of Concerns:
- **Models**: Data schemas, validation, database interactions.
- **Controllers**: Business rules and logic.
- **Routes**: Endpoint declarations and URL routing.
- **Middleware**: Cross-cutting concerns (authentication, rate-limiting, error handling).
This makes the application testable, maintainable, and scalable.

### 19. Why use Mongoose instead of the native MongoDB driver?
**Answer**: Mongoose provides an Object Data Modeling (ODM) layer providing strict schema validation, type casting, middleware hooks (like pre-save password hashing), relationships via `.populate()`, and validation errors.

### 20. What is `.populate()` in Mongoose?
**Answer**: Mongoose `.populate()` replaces a referenced `ObjectId` in a document with the actual document data from another collection (e.g., replacing `booking.user` with `{ name: "Ganesh", email: "..." }`), acting as a relational join.

### 21. What is Middleware in Express?
**Answer**: Functions that have access to the request object (`req`), response object (`res`), and the `next` function in the application’s request-response lifecycle. Examples in our portal include token verification (`protect`), CORS, JSON parsing, and central error handling.

---

## Part 3: Project-Specific Implementation Questions

### 22. How does the Booking process work end-to-end?
**Answer**:
1. Traveler selects a package, chooses a departure date and number of travelers, and selects optional add-ons.
2. The frontend sends `POST /api/bookings` with the package ID and details.
3. The backend checks if the package exists, is active, and has sufficient available seats.
4. Total price is computed: `(Base Price × Travelers) + Add-ons`.
5. A unique booking reference (e.g. `PKG-2946-8980`) is generated.
6. A booking document is created with status `"Pending"` and paymentStatus `"Unpaid"`.
7. Available seats on the package are decremented in MongoDB.
8. The traveler proceeds to simulated payment.

### 23. How is the total price calculated?
**Answer**:
In `bookingController.js`:
$$\text{Total Price} = (\text{Package Price} \times \text{Number of People}) + \sum (\text{Selected Add-on Prices})$$
The calculation is performed on the backend to prevent client-side price tampering.

### 24. How are available seats reduced? What happens if seats are insufficient?
**Answer**:
In `bookingController.js`, when a booking is created:
`travelPackage.availableSeats -= numberOfPeople; await travelPackage.save();`
If `travelPackage.availableSeats < numberOfPeople`, the controller rejects the request with `HTTP 400 Bad Request` and message: *"Not enough seats available"*. No booking is inserted.

### 25. What happens when a traveler cancels a booking?
**Answer**:
A compensating transaction is executed in `bookingController.js`:
1. The booking status is updated to `"Cancelled"`.
2. The reserved seats are added back to the package:
   `travelPackage.availableSeats += booking.numberOfPeople; await travelPackage.save();`
3. If previously paid, paymentStatus is updated to `"Refunded"`.
4. An audit record is logged in `AdminLog`.

### 26. How does the frontend communicate with the backend?
**Answer**:
The frontend uses standard asynchronous `fetch()` API calls to send HTTP requests to Express endpoints (`/api/...`). When authenticated, requests include the JWT token in the `Authorization: Bearer <token>` header. The backend responds with JSON.

### 27. How does the simulated payment gateway work?
**Answer**:
In `paymentController.js`:
1. Traveler submits payment details via the UI dialog.
2. The endpoint `POST /api/payments/process` verifies the booking exists and is unpaid.
3. A unique transaction ID (`TXN-XXXXXX-XXXX`) is generated.
4. A document is created in the `payments` collection.
5. The associated booking is updated to `status: "Confirmed"` and `paymentStatus: "Paid"`.
6. A receipt confirmation is displayed with the transaction ID.

### 28. What is the difference between deleting and retiring a package?
**Answer**:
- **Retiring (Soft Toggle)**: Sets `isActive: false`. The package remains in the database so past booking history remains intact, but it is hidden from travelers.
- **Hard Deleting**: Permanently removes the document from MongoDB. This is only allowed if **no active bookings** reference the package, enforcing referential integrity.

### 29. How did you implement Role-Based Access Control?
**Answer**:
In `backend/middleware/authMiddleware.js`:
The `adminOnly` middleware checks `if (req.user && req.user.role === 'admin') next(); else res.status(403).json(...)`.
Normal travelers receive `403 Forbidden` if they try to access administrative routes.

### 30. How do you demonstrate SQL concepts if the project runs on MongoDB?
**Answer**:
We created complete relational SQL demonstration scripts in `database/sql/`:
- `schema.sql`: 3NF normalized tables with foreign keys and check constraints.
- `queries.sql`: Multi-table joins (`INNER JOIN`, `LEFT JOIN`).
- `advanced_queries.sql`: CTEs, subqueries, and window functions (`RANK() OVER`, `ROW_NUMBER()`).
- `transactions.sql`: ACID procedures and triggers.
This shows mastery of both Relational (SQL) and NoSQL (MongoDB) paradigms.
