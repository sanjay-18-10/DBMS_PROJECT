# DBMS Concepts Explained: Travel Package Booking Portal

This document explains every fundamental and advanced Database Management System (DBMS) concept implemented in the **Travel Package Booking Portal** in beginner-friendly, viva-ready language.

---

## Concept 1: CRUD Operations (Create, Read, Update, Delete)

### What it means:
CRUD represents the four fundamental operations performed on any persistent storage or database system.

### WHERE USED IN OUR PROJECT:
- **Create**: Registering travelers, inserting travel packages (`POST /api/packages`), placing bookings (`POST /api/bookings`), creating payment receipts.
- **Read**: Fetching packages catalog with filters (`GET /api/packages`), retrieving individual booking details (`GET /api/bookings/:id`), querying admin analytics.
- **Update**: Modifying package pricing/seats (`PUT /api/packages/:id`), retiring/reactivating a package (`PATCH /api/packages/:id/status`), changing booking status to Confirmed upon payment.
- **Delete / Deactivate**: Soft-deleting (retiring) packages or deleting packages without active bookings (`DELETE /api/packages/:id`).

### EXAMPLE:
```javascript
// CREATE:
await Booking.create({ user: userId, package: packageId, numberOfPeople, totalPrice });

// READ:
const packages = await Package.find({ destination: "Kerala", isActive: true });

// UPDATE:
travelPackage.availableSeats -= peopleCount;
await travelPackage.save();

// DELETE:
await Package.findByIdAndDelete(packageId);
```

### WHY WE USE IT:
Every real-world booking portal requires state persistence so travel packages, customer reservations, and invoices persist across server restarts.

### HOW TO SHOW IT TO THE GUIDE:
1. Open the website, click **Explore Packages** (Read).
2. Book a package (Create).
3. Open MongoDB Compass → `travel_booking` → `bookings` collection to show the newly inserted document.
4. Show the updated seat count in the `packages` collection (Update).

---

## Concept 2: Schema Design & Data Validation

### What it means:
Schema design defines the structure, data types, constraints, and validation rules that documents or records must satisfy before being persisted.

### WHERE USED IN OUR PROJECT:
Defined across all Mongoose schemas in `backend/models/`:
- `User.js` (name, unique email with regex pattern, minimum password length)
- `Package.js` (name, destination, price with `min: 0`, duration with `min: 1`, availableSeats with `min: 0`)
- `Booking.js` (foreign references, numberOfPeople `min: 1`, status enum)
- `Payment.js` (positive amount, unique transactionId, paymentMethod enum)

### EXAMPLE:
```javascript
// backend/models/Package.js
price: {
    type: Number,
    required: [true, "Price is required"],
    min: [0, "Price must be a positive number"]
},
availableSeats: {
    type: Number,
    required: [true, "Available seats are required"],
    min: [0, "Available seats cannot be negative"]
}
```

### WHY WE USE IT:
Prevents database corruption and "garbage data" (e.g. negative prices, negative seat counts, or invalid emails).

### HOW TO SHOW IT TO THE GUIDE:
1. Open `backend/test.http` and send a request with `"numberOfPeople": -5` or a negative price.
2. Show the API returning `HTTP 400 Bad Request` with Mongoose validation errors.

---

## Concept 3: Database Indexing & Query Optimization (B-Tree Indexes)

### What it means:
An index is a specialized auxiliary data structure (typically a balanced B-Tree) that allows the database engine to locate target records in logarithmic time \(O(\log N)\) rather than scanning every document in the collection \(O(N)\).

### WHERE USED IN OUR PROJECT:
- `backend/models/Package.js`:
  - Compound Index: `{ destination: 1, price: 1 }`
  - Single Field Index: `{ isActive: 1 }`
  - Text Search Index: `{ name: "text", destination: "text", description: "text" }`
- `backend/models/User.js`:
  - Unique Index on `email`
- `backend/models/Booking.js`:
  - Foreign Key Indexes on `user` and `package`

### EXAMPLE:
```javascript
// backend/models/Package.js
packageSchema.index({ destination: 1, price: 1 });
packageSchema.index({ isActive: 1 });
packageSchema.index({ name: "text", destination: "text", description: "text" });
```

### WHY WE USE IT:
When thousands of travelers search for packages by destination and budget simultaneously, indexes ensure queries complete in milliseconds.

### HOW TO SHOW IT TO THE GUIDE:
1. Open MongoDB Compass or `mongosh`.
2. Run:
```javascript
db.packages.find({ destination: "Kerala", price: { $lte: 20000 } }).explain("executionStats")
```
3. Show the professor that `winningPlan.inputStage.stage` is **`IXSCAN`** (Index Scan) rather than **`COLLSCAN`** (Collection Scan).

---

## Concept 4: Relationships & Referential Integrity (Foreign Keys vs. MongoDB References)

### What it means:
Relationships establish logical connections between entities in different tables or collections:
- **One-to-Many (1:N)**: One User has Many Bookings; One Package has Many Bookings.
- **Referential Integrity**: Ensuring that a foreign key reference cannot point to a non-existent primary key.

### WHERE USED IN OUR PROJECT:
- In `Booking.js`, `user` holds an `ObjectId` referencing the `User` collection, and `package` holds an `ObjectId` referencing the `Package` collection.
- In `Payment.js`, `booking` references the `Booking` collection.
- In `packageController.js` (`deletePackage`), before deleting a package, the system checks whether active bookings exist. If active bookings exist, deletion is rejected!

### EXAMPLE:
```javascript
// backend/models/Booking.js
user: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "User",
    required: true
},
package: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "Package",
    required: true
}
```

```javascript
// Referential Integrity check in packageController.js:
const activeBookings = await Booking.find({ package: packageId, status: { $ne: "Cancelled" } });
if (activeBookings.length > 0) {
    return res.status(400).json({ message: "Cannot delete package: Active bookings exist!" });
}
```

### WHY WE USE IT:
Separates entities to eliminate redundancy. We don't copy the user's name, email, and phone into every booking document; instead, we link them via reference.

### HOW TO SHOW IT TO THE GUIDE:
1. Show the `Booking` document in Compass containing only `user: ObjectId("...")` and `package: ObjectId("...")`.
2. Try deleting a package that has an active booking via `test.http` or Admin Dashboard and show the rejection message.

---

## Concept 5: Population & Relational Joins (`$lookup` & `.populate()`)

### What it means:
Population (in Mongoose) or `$lookup` (in MongoDB) is the document-database equivalent of an SQL `INNER JOIN` or `LEFT OUTER JOIN`. It replaces the referenced `ObjectId` with the actual document data from the referenced collection.

### WHERE USED IN OUR PROJECT:
- `bookingController.js`: When fetching bookings (`getBookings`, `getMyBookings`), `.populate("user", "name email phone")` and `.populate("package", "name destination price")` are invoked.
- `adminController.js`: Uses the `$lookup` stage in the aggregation pipeline to join bookings with packages to compute revenue by destination.

### EXAMPLE:
```javascript
// Mongoose Population:
const bookings = await Booking.find()
    .populate("user", "name email phone")
    .populate("package", "name destination price");

// MongoDB Aggregation $lookup:
{
    $lookup: {
        from: "packages",
        localField: "package",
        foreignField: "_id",
        as: "packageDetails"
    }
}
```

### WHY WE USE IT:
Enables the frontend to display the traveler's name and package title without requiring multiple separate client-side API requests.

### HOW TO SHOW IT TO THE GUIDE:
1. Open `GET /api/bookings` in `backend/test.http` or browser DevTools Network tab.
2. Show that the response JSON contains full `user` object (`name`, `email`) and full `package` object (`destination`, `price`) instead of raw ObjectIds.

---

## Concept 6: Aggregation Framework (Data Analytics & Grouping)

### What it means:
The MongoDB Aggregation Framework is an advanced data processing pipeline where documents enter a multi-stage pipeline and are transformed, filtered, grouped, and summarized (equivalent to SQL `GROUP BY`, `SUM`, `AVG`, `COUNT`, `HAVING`).

### WHERE USED IN OUR PROJECT:
In `backend/controllers/adminController.js` for the **Admin Analytics Console**:
1. Revenue grouped by payment status (`$group`, `$sum`).
2. Top 5 popular packages sorted by number of bookings (`$group`, `$sort`, `$limit`, `$lookup`, `$unwind`).
3. Total bookings and sales grouped by travel destination.

### EXAMPLE:
```javascript
// Calculate total revenue and bookings per destination:
const destinationStats = await Booking.aggregate([
    {
        $lookup: {
            from: "packages",
            localField: "package",
            foreignField: "_id",
            as: "pkg"
        }
    },
    { $unwind: "$pkg" },
    {
        $group: {
            _id: "$pkg.destination",
            bookingsCount: { $sum: 1 },
            revenue: { $sum: "$totalPrice" }
        }
    },
    { $sort: { bookingsCount: -1 } }
]);
```

### WHY WE USE IT:
Calculations run inside the optimized database engine rather than pulling millions of records into Node.js memory.

### HOW TO SHOW IT TO THE GUIDE:
1. Log in as Admin (`admin@travelportal.com` / `admin123`).
2. Navigate to **Admin Dashboard → Aggregation Analytics**.
3. Point out the live destination breakdown and explain the `$group` and `$sum` pipeline stages.

---

## Concept 7: ACID Properties & Atomic Inventory Management

### What it means:
ACID stands for:
- **A — Atomicity**: All operations succeed, or none do (all-or-nothing).
- **C — Consistency**: The database moves from one valid state to another, preserving all schema constraints.
- **I — Isolation**: Concurrent transactions execute without interfering with one another.
- **D — Durability**: Once committed, changes survive power outages or system crashes.

### WHERE USED IN OUR PROJECT:
1. **Seat Decrement during Booking**:
   - Before reserving, the system validates `travelPackage.availableSeats >= requestedSeats`.
   - The booking document is created and the package available seats are atomically decremented.
   - If seat count is insufficient, the operation is blocked (`HTTP 400`), preserving Consistency.
2. **Compensating Transaction on Cancellation**:
   - If a traveler cancels a booking, `booking.status` changes to `"Cancelled"`, and the package seats are restored:
   `travelPackage.availableSeats += booking.numberOfPeople; await travelPackage.save();`

### EXAMPLE:
```javascript
// Atomic reduction & constraint check in bookingController.js:
if (travelPackage.availableSeats < numberOfPeople) {
    return res.status(400).json({ message: "Not enough seats available" });
}
const booking = await Booking.create({ user, package: packageId, numberOfPeople, totalPrice });
travelPackage.availableSeats -= numberOfPeople;
await travelPackage.save();
```

### WHY WE USE IT:
Prevents **overbooking** (selling more seats than physically available on flights/tours).

### HOW TO SHOW IT TO THE GUIDE:
1. Check package seats: note that Goa has 25 seats.
2. Book 2 seats.
3. Show that seats immediately drop to 23.
4. Try booking 999 seats → show error `400: Not enough seats available`.
5. Cancel the booking from **My Bookings** → show that seats immediately restore back to 25!

---

## Concept 8: Database Normalization (1NF, 2NF, 3NF) vs. Denormalization

### What it means:
- **Normalization**: Organizing data in relational tables to eliminate redundancy and insertion/update/deletion anomalies.
  - **1NF**: Atomic values, unique column names, primary key.
  - **2NF**: In 1NF and no partial functional dependency on a composite key.
  - **3NF**: In 2NF and no transitive functional dependency (non-key attribute depending on another non-key attribute).
- **Denormalization / Hybrid Document Model (NoSQL)**: Storing related data together (like `addOns` embedded inside `Booking`) for high read throughput while referencing core entities (`User`, `Package`) to prevent inconsistency.

### WHERE USED IN OUR PROJECT:
- **Relational SQL design** (`database/sql/schema.sql`): Fully normalized to 3NF. `categories` is separated into its own table so package categories don't create transitive dependencies.
- **MongoDB document model**:
  - `addOns` is embedded because an add-on (e.g., "Airport Pickup") is unique to that specific booking.
  - `User` and `Package` are referenced via `ObjectId` to avoid duplicating customer and package profiles across millions of bookings.

### WHY WE USE IT:
Demonstrates when to normalize (relational integrity) versus when to selectively embed (document speed and locality).

### HOW TO SHOW IT TO THE GUIDE:
Open `database/sql/schema.sql` and `database/README.md` to demonstrate the 3NF table design and explain the rationale for embedding add-ons in MongoDB.

---

## Concept 9: Authentication, Authorization & Role-Based Access Control (RBAC)

### What it means:
- **Authentication**: Verifying *who* the user is (Email + Password verified via bcrypt hash).
- **Authorization**: Verifying *what* permissions the authenticated user possesses.
- **RBAC**: Restricting access to sensitive operations based on assigned roles (`user` vs `admin`).

### WHERE USED IN OUR PROJECT:
- `authMiddleware.js`:
  - `protect`: Decodes and validates JWT token from HTTP `Authorization: Bearer <token>` header.
  - `adminOnly`: Restricts admin endpoints (`POST /api/packages`, `GET /api/admin/analytics`) strictly to users with `role: "admin"`.
- `userModel.js`: Passwords are never stored in plain text; they are hashed using `bcryptjs` with salt rounds.

### EXAMPLE:
```javascript
// backend/middleware/authMiddleware.js
const adminOnly = (req, res, next) => {
    if (req.user && req.user.role === "admin") {
        next();
    } else {
        res.status(403).json({ message: "Access denied. Administrator privileges required." });
    }
};
```

### WHY WE USE IT:
Prevents ordinary travelers from modifying travel prices, accessing other travelers' records, or tampering with database analytics.

### HOW TO SHOW IT TO THE GUIDE:
1. Log in as traveler `ganesh@test.com`.
2. Attempt to access `GET /api/admin/analytics` in `test.http` or via DevTools.
3. Show the response: `HTTP 403 Forbidden: Access denied. Administrator privileges required.`
4. Log in as admin `admin@travelportal.com` → access granted with `HTTP 200 OK`.
