# FastAPI Academic Demonstration Module (CO3)

This module demonstrates the **CO3 — Backend / API / Security** concepts from the DBMS syllabus using Python and **FastAPI**.

> **Important Note for Project Review**:
> The primary, full-stack application for this project runs on **Node.js, Express, and MongoDB** (located in `backend/` and `frontend/`).
> This `fastapi-demo/` directory is an independent academic micro-module specifically demonstrating Python-based REST APIs, Pydantic data modeling, and automatic OpenAPI generation.

---

## Demonstrated Syllabus Topics (CO3)

1. **FastAPI Framework**: High-performance, modern Python web framework built on Starlette and Pydantic.
2. **REST APIs & OpenAPI**: Automatic generation of interactive OpenAPI (Swagger) documentation at `/docs` and ReDoc at `/redoc`.
3. **Pydantic Models**: Strict schema validation for request bodies and typed response serialization (`PackageCreate`, `BookingRequest`).
4. **Dependency Injection**: Demonstrating FastAPI's `Depends()` pattern for security, token parsing, and role verification (`require_admin`).
5. **Async Programming**: Python `async def` coroutines for non-blocking I/O execution.
6. **Middleware**: Custom HTTP middleware measuring request processing time (`X-Process-Time-Sec`).

---

## How to Run the FastAPI Demo

### 1. Open Terminal in `fastapi-demo/`
```bash
cd fastapi-demo
```

### 2. Install Dependencies
```bash
pip install -r requirements.txt
```

### 3. Start the Uvicorn Server
```bash
uvicorn main:app --reload --port 8000
```

### 4. Open Interactive Swagger UI
Open your browser to:
👉 **[http://127.0.0.1:8000/docs](http://127.0.0.1:8000/docs)**

---

## Viva Highlights to Show the Guide

1. Show how **Pydantic** automatically rejects invalid inputs (e.g. negative prices or missing fields) with standard `422 Unprocessable Entity` JSON responses.
2. Show how `Depends(require_admin)` blocks unauthorized requests when creating a package.
3. Show the interactive "Try it out" feature in Swagger UI to demonstrate live API testing without needing Postman.
