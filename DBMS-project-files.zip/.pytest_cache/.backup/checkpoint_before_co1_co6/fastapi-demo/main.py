"""
=============================================================================
TRAVEL PACKAGE BOOKING PORTAL - FASTAPI DEMO MODULE
Syllabus Alignment: CO3 - Backend / API / Security (FastAPI, REST, Pydantic, DI, Async)
=============================================================================
NOTE: The main full-stack application runs on Node.js / Express / MongoDB.
This standalone micro-module demonstrates the academic CO3 syllabus requirements:
1. FastAPI Framework & Async routing
2. Pydantic request / response schemas & strict data validation
3. Automatic OpenAPI / Swagger UI generation
4. Dependency Injection via `Depends()`
5. Custom async logging / execution timing middleware
=============================================================================
"""

import time
from typing import List, Optional
from fastapi import FastAPI, HTTPException, Depends, Header, Request, status
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

# 1. Initialize FastAPI App with OpenAPI metadata
app = FastAPI(
    title="Travel Package Booking Portal - FastAPI Demo API",
    description="Academic Demonstration for CO3 syllabus: FastAPI, Pydantic, Dependency Injection & OpenAPI",
    version="1.0.0",
    docs_url="/docs",
    redoc_url="/redoc"
)

# 2. CORS Middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# 3. Custom Timing & Performance Middleware (CO3 Middleware requirement)
@app.middleware("http")
async def add_process_time_header(request: Request, call_next):
    start_time = time.time()
    response = await call_next(request)
    process_time = time.time() - start_time
    response.headers["X-Process-Time-Sec"] = f"{process_time:.6f}"
    return response

# 4. Pydantic Data Models (CO3 Strict Data Validation requirement)
class PackageBase(BaseModel):
    name: str = Field(..., example="Kerala Backwaters & Hills", min_length=3)
    destination: str = Field(..., example="Kerala")
    description: str = Field(..., example="5-day luxury houseboat and hill station package")
    price: float = Field(..., gt=0, example=15000.0)
    duration: int = Field(..., gt=0, example=5)
    available_seats: int = Field(..., ge=0, example=20)
    category: str = Field(default="Holiday", example="Holiday")

class PackageCreate(PackageBase):
    pass

class PackageResponse(PackageBase):
    id: int
    is_active: bool = True

    class Config:
        from_attributes = True

class BookingRequest(BaseModel):
    package_id: int = Field(..., example=1)
    number_of_people: int = Field(..., ge=1, le=10, example=2)
    travel_date: str = Field(..., example="2026-11-20")
    special_preferences: Optional[str] = Field(None, example="Vegetarian meals")

class BookingResponse(BaseModel):
    booking_reference: str
    package_id: int
    number_of_people: int
    total_price: float
    status: str
    message: str

# In-memory demo data store
DEMO_PACKAGES = [
    {
        "id": 1,
        "name": "Kerala Backwaters & Hills",
        "destination": "Kerala",
        "description": "5-day luxury houseboat and hill station package",
        "price": 15000.0,
        "duration": 5,
        "available_seats": 18,
        "category": "Holiday",
        "is_active": True
    },
    {
        "id": 2,
        "name": "Goa Sun & Sands Getaway",
        "destination": "Goa",
        "description": "4-day beach vacation with water sports and cruise",
        "price": 12500.0,
        "duration": 4,
        "available_seats": 25,
        "category": "Beach",
        "is_active": True
    }
]

# 5. Dependency Injection (CO3 DI & Security demonstration)
# Simulates JWT token verification and user extraction
async def get_current_user(authorization: Optional[str] = Header(None)):
    if not authorization:
        # For academic demo convenience, accept demo token or default to traveler
        return {"user_id": "usr_demo", "name": "Demo Traveler", "role": "user"}
    
    if not authorization.startswith("Bearer "):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid authorization header format. Expected 'Bearer <token>'"
        )
    
    token = authorization.split(" ")[1]
    if token == "admin_secret_token_123":
        return {"user_id": "usr_admin", "name": "Admin User", "role": "admin"}
    elif token == "user_secret_token_456":
        return {"user_id": "usr_traveler", "name": "Ganesh Sharma", "role": "user"}
    else:
        return {"user_id": "usr_guest", "name": "Guest Traveler", "role": "user"}

async def require_admin(current_user: dict = Depends(get_current_user)):
    if current_user.get("role") != "admin":
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Forbidden: Admin credentials required for this operation"
        )
    return current_user

# 6. REST API Endpoints

@app.get("/", tags=["General"])
async def root():
    return {
        "message": "Welcome to the FastAPI Demo Module for Travel Portal",
        "syllabus_coverage": "CO3 - FastAPI, REST, Pydantic, Dependency Injection, Async",
        "interactive_docs": "Visit /docs for Swagger UI or /redoc for ReDoc",
        "main_application": "The full-stack application runs on Node.js / Express at http://localhost:5000"
    }

@app.get("/api/packages", response_model=List[PackageResponse], tags=["Packages"])
async def get_packages(destination: Optional[str] = None, max_price: Optional[float] = None):
    """
    Asynchronously retrieve available travel packages with optional filtering.
    """
    results = DEMO_PACKAGES
    if destination:
        results = [p for p in results if destination.lower() in p["destination"].lower()]
    if max_price:
        results = [p for p in results if p["price"] <= max_price]
    return results

@app.post("/api/packages", response_model=PackageResponse, status_code=status.HTTP_201_CREATED, tags=["Packages"])
async def create_package(
    package_data: PackageCreate,
    admin: dict = Depends(require_admin)  # Dependency Injection enforcing admin role
):
    """
    Admin-only endpoint to create a new package with strict Pydantic validation.
    """
    new_id = len(DEMO_PACKAGES) + 1
    new_pkg = {
        "id": new_id,
        **package_data.model_dump(),
        "is_active": True
    }
    DEMO_PACKAGES.append(new_pkg)
    return new_pkg

@app.post("/api/bookings", response_model=BookingResponse, status_code=status.HTTP_201_CREATED, tags=["Bookings"])
async def create_booking(
    booking: BookingRequest,
    user: dict = Depends(get_current_user)  # Injected user context
):
    """
    Asynchronously create a booking with automatic total-price calculation and seat reduction.
    """
    pkg = next((p for p in DEMO_PACKAGES if p["id"] == booking.package_id), None)
    if not pkg:
        raise HTTPException(status_code=404, detail="Travel package not found")

    if pkg["available_seats"] < booking.number_of_people:
        raise HTTPException(
            status_code=400,
            detail=f"Insufficient seats. Available: {pkg['available_seats']}, Requested: {booking.number_of_people}"
        )

    # Calculate total and reduce inventory
    total_price = pkg["price"] * booking.number_of_people
    pkg["available_seats"] -= booking.number_of_people
    ref = f"FASTAPI-PKG-{int(time.time())}"

    return {
        "booking_reference": ref,
        "package_id": booking.package_id,
        "number_of_people": booking.number_of_people,
        "total_price": total_price,
        "status": "Confirmed",
        "message": f"Successfully booked {booking.number_of_people} seats for {user['name']}"
    }
