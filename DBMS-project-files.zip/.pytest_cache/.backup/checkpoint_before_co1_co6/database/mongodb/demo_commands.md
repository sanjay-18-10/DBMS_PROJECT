# MongoDB Compass & mongosh Demonstration Commands

These commands can be run directly inside **MongoDB Compass** (using the embedded **_MONGOSH_** shell at the bottom) or via terminal `mongosh`.

Connect to MongoDB:
```bash
mongosh "mongodb://localhost:27017/travel_booking"
```

---

## 1. Database & Collection Inspection

```javascript
// Display all databases
show dbs

// Switch to the project database
use travel_booking

// List all collections in travel_booking
show collections

// Count total documents in each collection
db.users.countDocuments()
db.packages.countDocuments()
db.bookings.countDocuments()
db.payments.countDocuments()
db.adminlogs.countDocuments()
```

---

## 2. CRUD Operations

### A. CREATE (Insert)
```javascript
// Insert a new travel package
db.packages.insertOne({
  name: "Ladakh Bike & Monastery Expedition",
  destination: "Ladakh",
  description: "Experience Khardung La Pass, Pangong Tso Lake, and Nubra Valley camel rides.",
  price: 34000,
  duration: 8,
  availableSeats: 10,
  category: "Adventure",
  isActive: true,
  highlights: ["Khardung La Pass", "Pangong Tso Camping", "Nubra Valley Sand Dunes"],
  createdAt: new Date(),
  updatedAt: new Date()
})
```

### B. READ (Find & Querying)
```javascript
// Find all active packages
db.packages.find({ isActive: true })

// Find formatted with pretty printing
db.packages.find({ destination: "Goa" }).pretty()

// Projection: Retrieve only package name, destination, and price (suppressing _id)
db.packages.find(
  { isActive: true },
  { name: 1, destination: 1, price: 1, _id: 0 }
)
```

### C. UPDATE
```javascript
// Update seats for a package
db.packages.updateOne(
  { destination: "Goa" },
  { $set: { availableSeats: 24, updatedAt: new Date() } }
)

// Increment / Decrement seats atomically (e.g. reduce by 2)
db.packages.updateOne(
  { destination: "Kerala" },
  { $inc: { availableSeats: -2 } }
)
```

### D. DELETE
```javascript
// Delete a specific test package by name
db.packages.deleteOne({ name: "Ladakh Bike & Monastery Expedition" })
```

---

## 3. Advanced Filtering & Sorting

```javascript
// Filtering using Comparison Operators: Price between 15000 and 30000
db.packages.find({
  price: { $gte: 15000, $lte: 30000 }
})

// Regex text search (Case-insensitive search for "valley" or "explorer")
db.packages.find({
  description: { $regex: "valley", $options: "i" }
})

// Logical Operator ($or): Beach or Mountain packages
db.packages.find({
  $or: [
    { category: "Beach" },
    { category: "Mountain" }
  ]
})

// Sorting: Sort packages by price in descending order (-1)
db.packages.find().sort({ price: -1 })

// Pagination: Skip first 2 packages and limit results to next 2
db.packages.find().skip(2).limit(2)
```

---

## 4. Index Inspection & Query Optimization

```javascript
// View all indexes defined on the packages collection
db.packages.getIndexes()

// View indexes on bookings
db.bookings.getIndexes()

// Explain Query Execution Plan (Demonstrating IXSCAN vs COLLSCAN)
// Without index or with index:
db.packages.find({ destination: "Kerala", price: { $lte: 20000 } }).explain("executionStats")
```

> **Viva Point**: In `executionStats`, point out `stage: "IXSCAN"`. This proves to the guide that MongoDB is utilizing the compound B-Tree index on `{ destination: 1, price: 1 }` rather than doing a slow `COLLSCAN` (full table/collection scan).

---

## 5. MongoDB Aggregation Framework (Demonstrating Joins & Analytics)

### Pipeline 1: Total Revenue and Bookings by Payment Status
```javascript
db.bookings.aggregate([
  {
    $group: {
      _id: "$paymentStatus",
      totalRevenue: { $sum: "$totalPrice" },
      bookingCount: { $sum: 1 },
      avgBookingValue: { $avg: "$totalPrice" }
    }
  },
  {
    $sort: { totalRevenue: -1 }
  }
])
```

### Pipeline 2: MongoDB Join via `$lookup` (Populate equivalent)
*Demonstrates joining the `bookings` collection with the `packages` collection.*
```javascript
db.bookings.aggregate([
  {
    $lookup: {
      from: "packages",
      localField: "package",
      foreignField: "_id",
      as: "packageInfo"
    }
  },
  {
    $unwind: "$packageInfo"
  },
  {
    $project: {
      bookingReference: 1,
      totalPrice: 1,
      status: 1,
      packageName: "$packageInfo.name",
      destination: "$packageInfo.destination"
    }
  }
])
```

### Pipeline 3: Most Popular Destinations by Revenue
```javascript
db.bookings.aggregate([
  {
    $lookup: {
      from: "packages",
      localField: "package",
      foreignField: "_id",
      as: "pkg"
    }
  },
  {
    $unwind: "$pkg"
  },
  {
    $group: {
      _id: "$pkg.destination",
      totalRevenue: { $sum: "$totalPrice" },
      totalBookings: { $sum: 1 }
    }
  },
  {
    $sort: { totalRevenue: -1 }
  }
])
```
