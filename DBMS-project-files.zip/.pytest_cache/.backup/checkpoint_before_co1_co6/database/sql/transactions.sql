-- ============================================================================
-- SQL TRANSACTIONS & STORED LOGIC DEMONSTRATION
-- Syllabus Alignment: CO1 - ACID Properties, Transactions, Stored Procedures, Triggers
-- ============================================================================

USE travel_portal_db;

-- 1. ACID TRANSACTION DEMONSTRATION: Atomically create booking & reduce package inventory seats
-- Demonstrates Atomicity (all or nothing), Consistency, Isolation, and Durability
DELIMITER //

DROP PROCEDURE IF EXISTS sp_create_booking_atomic //

CREATE PROCEDURE sp_create_booking_atomic(
    IN p_user_id INT,
    IN p_package_id INT,
    IN p_people INT,
    IN p_travel_date DATE,
    OUT p_status_message VARCHAR(100)
)
BEGIN
    DECLARE v_available INT;
    DECLARE v_price DECIMAL(10,2);
    DECLARE v_total DECIMAL(10,2);
    DECLARE v_ref VARCHAR(30);

    -- Declare handler to rollback on any SQL exception
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        SET p_status_message = 'TRANSACTION_FAILED: Rolled back successfully.';
    END;

    -- START ACID TRANSACTION
    START TRANSACTION;

    -- Lock row for update to ensure Isolation (avoid race condition)
    SELECT available_seats, price INTO v_available, v_price
    FROM packages
    WHERE package_id = p_package_id
    FOR UPDATE;

    -- Check if sufficient seats exist
    IF v_available >= p_people THEN
        -- Calculate total
        SET v_total = v_price * p_people;
        SET v_ref = CONCAT('PKG-SQL-', UNIX_TIMESTAMP(), '-', FLOOR(RAND() * 9000 + 1000));

        -- Insert booking record
        INSERT INTO bookings (booking_reference, user_id, package_id, travel_date, number_of_people, total_price, status)
        VALUES (v_ref, p_user_id, p_package_id, p_travel_date, p_people, v_total, 'Pending');

        -- Reduce available seats
        UPDATE packages
        SET available_seats = available_seats - p_people
        WHERE package_id = p_package_id;

        -- Commit transaction permanently
        COMMIT;
        SET p_status_message = CONCAT('SUCCESS: Booking ', v_ref, ' created and seats reduced.');
    ELSE
        -- Insufficient seats: rollback
        ROLLBACK;
        SET p_status_message = 'ERROR: Insufficient seats available.';
    END IF;
END //

DELIMITER ;

-- 2. TRIGGER: Automatically restore available seats when a booking status changes to 'Cancelled'
DELIMITER //

DROP TRIGGER IF EXISTS trg_after_booking_cancel //

CREATE TRIGGER trg_after_booking_cancel
AFTER UPDATE ON bookings
FOR EACH ROW
BEGIN
    -- If status transitioned from something else to 'Cancelled', restore seats
    IF OLD.status != 'Cancelled' AND NEW.status = 'Cancelled' THEN
        UPDATE packages
        SET available_seats = available_seats + NEW.number_of_people
        WHERE package_id = NEW.package_id;
    END IF;
END //

DELIMITER ;

-- 3. AUDIT TRIGGER: Log when a package price or seats are modified
DELIMITER //

DROP TRIGGER IF EXISTS trg_audit_package_update //

CREATE TRIGGER trg_audit_package_update
AFTER UPDATE ON packages
FOR EACH ROW
BEGIN
    IF OLD.price != NEW.price OR OLD.available_seats != NEW.available_seats THEN
        INSERT INTO admin_logs (admin_id, action, target_entity, target_id, details)
        VALUES (
            1, 
            'PACKAGE_INVENTORY_CHANGE', 
            'Package', 
            NEW.package_id, 
            CONCAT('Price: ', OLD.price, '->', NEW.price, ', Seats: ', OLD.available_seats, '->', NEW.available_seats)
        );
    END IF;
END //

DELIMITER ;
