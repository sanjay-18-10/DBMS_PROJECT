-- ============================================================================
-- ADVANCED SQL QUERYING DEMONSTRATION
-- Syllabus Alignment: CO1 - Subqueries, CTEs, Window Functions, Group By & Having
-- ============================================================================

USE travel_portal_db;

-- 1. SUBQUERY: Find packages priced above the average package price
SELECT package_id, name, destination, price
FROM packages
WHERE price > (SELECT AVG(price) FROM packages)
ORDER BY price DESC;

-- 2. CORRELATED SUBQUERY: Find users who have spent more than the average booking amount
SELECT u.user_id, u.name, u.email
FROM users u
WHERE (
    SELECT SUM(b.total_price) 
    FROM bookings b 
    WHERE b.user_id = u.user_id AND b.status = 'Confirmed'
) > (
    SELECT AVG(total_price) 
    FROM bookings 
    WHERE status = 'Confirmed'
);

-- 3. COMMON TABLE EXPRESSIONS (CTE): Calculate destination-level booking summary
WITH DestinationRevenue AS (
    SELECT 
        p.destination,
        COUNT(b.booking_id) AS booking_count,
        SUM(b.total_price) AS total_revenue,
        AVG(b.total_price) AS avg_booking_value
    FROM packages p
    INNER JOIN bookings b ON p.package_id = b.package_id
    WHERE b.status = 'Confirmed'
    GROUP BY p.destination
)
SELECT destination, booking_count, total_revenue, avg_booking_value
FROM DestinationRevenue
WHERE total_revenue > 20000
ORDER BY total_revenue DESC;

-- 4. RECURSIVE CTE: Generate sequence of next 7 upcoming departure dates
WITH RECURSIVE TravelCalendar AS (
    SELECT CURDATE() AS departure_date, 1 AS day_offset
    UNION ALL
    SELECT DATE_ADD(departure_date, INTERVAL 1 DAY), day_offset + 1
    FROM TravelCalendar
    WHERE day_offset < 7
)
SELECT departure_date FROM TravelCalendar;

-- 5. WINDOW FUNCTIONS:
-- a) DENSE_RANK() & RANK(): Rank packages by price within each category
SELECT 
    p.name AS package_name,
    c.category_name,
    p.price,
    RANK() OVER (PARTITION BY p.category_id ORDER BY p.price DESC) AS price_rank_in_category,
    DENSE_RANK() OVER (ORDER BY p.price DESC) AS overall_price_dense_rank
FROM packages p
JOIN categories c ON p.category_id = c.category_id;

-- b) ROW_NUMBER(): Number all bookings per user chronologically
SELECT 
    b.booking_reference,
    b.user_id,
    b.total_price,
    b.booking_date,
    ROW_NUMBER() OVER (PARTITION BY b.user_id ORDER BY b.booking_date ASC) AS user_booking_sequence
FROM bookings b;

-- c) RUNNING TOTAL: Cumulative revenue over time using SUM() OVER ()
SELECT 
    pay.payment_id,
    pay.payment_date,
    pay.amount,
    SUM(pay.amount) OVER (ORDER BY pay.payment_date ASC ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW) AS cumulative_revenue
FROM payments pay
WHERE pay.payment_status = 'Success';

-- 6. AGGREGATE WITH HAVING CLAUSE: Find destinations with more than 2 bookings
SELECT 
    p.destination,
    COUNT(b.booking_id) AS total_bookings,
    SUM(b.total_price) AS total_sales
FROM packages p
JOIN bookings b ON p.package_id = b.package_id
GROUP BY p.destination
HAVING COUNT(b.booking_id) >= 2;
