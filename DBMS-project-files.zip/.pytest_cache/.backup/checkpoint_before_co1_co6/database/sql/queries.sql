-- ============================================================================
-- BASIC SQL QUERIES & RELATIONAL JOINS DEMONSTRATION
-- Syllabus Alignment: CO1 - DML, Filtering, Joins, Aggregates
-- ============================================================================

USE travel_portal_db;

-- 1. INSERT DATA (DML)
INSERT INTO categories (category_name, description) VALUES
('Holiday', 'Leisure and scenic holiday vacations'),
('Beach', 'Coastal retreats, watersports, and beachside relaxation'),
('Mountain', 'High altitude treks, valleys, and snow sports'),
('Heritage', 'Historical palaces, monuments, and cultural tours');

INSERT INTO users (name, email, password_hash, phone, role) VALUES
('Ganesh Sharma', 'ganesh@test.com', '$2b$10$hashedpasswordstring123', '9876543210', 'user'),
('Admin User', 'admin@travelportal.com', '$2b$10$hashedpasswordadmin456', '9988776655', 'admin');

-- 2. BASIC SELECT WITH FILTERING AND SORTING
SELECT package_id, name, destination, price, available_seats
FROM packages
WHERE is_active = TRUE AND price BETWEEN 10000 AND 30000
ORDER BY price ASC;

-- 3. INNER JOIN: Retrieve Bookings along with User Name and Package Name
-- Equivalent to Mongoose .populate('user').populate('package')
SELECT 
    b.booking_reference,
    u.name AS traveler_name,
    u.email AS traveler_email,
    p.name AS package_name,
    p.destination,
    b.number_of_people,
    b.total_price,
    b.travel_date,
    b.status
FROM bookings b
INNER JOIN users u ON b.user_id = u.user_id
INNER JOIN packages p ON b.package_id = p.package_id
ORDER BY b.created_at DESC;

-- 4. LEFT OUTER JOIN: List All Packages and their total number of bookings (including unbooked packages)
SELECT 
    p.package_id,
    p.name AS package_name,
    p.destination,
    COUNT(b.booking_id) AS total_bookings_count
FROM packages p
LEFT JOIN bookings b ON p.package_id = b.package_id
GROUP BY p.package_id, p.name, p.destination;

-- 5. MULTI-TABLE JOIN: Booking, Payment, User, and Package Information
SELECT 
    b.booking_reference,
    u.name AS traveler_name,
    p.name AS package_name,
    pay.transaction_id,
    pay.amount AS amount_paid,
    pay.payment_method,
    pay.payment_status
FROM payments pay
INNER JOIN bookings b ON pay.booking_id = b.booking_id
INNER JOIN users u ON pay.user_id = u.user_id
INNER JOIN packages p ON b.package_id = p.package_id;
