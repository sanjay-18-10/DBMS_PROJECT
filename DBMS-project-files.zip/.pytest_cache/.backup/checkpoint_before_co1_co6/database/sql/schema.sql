-- ============================================================================
-- TRAVEL PACKAGE BOOKING PORTAL - RELATIONAL DATABASE SCHEMA (ACADEMIC DEMO)
-- Syllabus Alignment: CO1 - RDBMS Foundations, Schema Design & 3NF Normalization
-- ============================================================================
-- NOTE: This file represents the relational SQL equivalent of our MongoDB schema.
-- It demonstrates DDL, 3NF Normalization, Primary/Foreign Keys, and Constraints.
-- ============================================================================

CREATE DATABASE IF NOT EXISTS travel_portal_db;
USE travel_portal_db;

-- 1. USERS TABLE (1NF & 2NF & 3NF Compliant: No repeating groups, fully functional dependent)
CREATE TABLE users (
    user_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(150) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    phone VARCHAR(20) NOT NULL,
    role ENUM('user', 'admin') DEFAULT 'user',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_user_email (email)
) ENGINE=InnoDB;

-- 2. PACKAGE CATEGORIES TABLE (Normalized to 3NF to eliminate transitive dependencies)
CREATE TABLE categories (
    category_id INT AUTO_INCREMENT PRIMARY KEY,
    category_name VARCHAR(50) NOT NULL UNIQUE,
    description TEXT
) ENGINE=InnoDB;

-- 3. PACKAGES TABLE
CREATE TABLE packages (
    package_id INT AUTO_INCREMENT PRIMARY KEY,
    category_id INT NOT NULL,
    name VARCHAR(150) NOT NULL,
    destination VARCHAR(100) NOT NULL,
    description TEXT NOT NULL,
    price DECIMAL(10, 2) NOT NULL CHECK (price >= 0),
    duration INT NOT NULL CHECK (duration >= 1),
    available_seats INT NOT NULL CHECK (available_seats >= 0),
    is_active BOOLEAN DEFAULT TRUE,
    image_url VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (category_id) REFERENCES categories(category_id) ON DELETE RESTRICT,
    INDEX idx_pkg_dest_price (destination, price),
    INDEX idx_pkg_status (is_active)
) ENGINE=InnoDB;

-- 4. BOOKINGS TABLE
CREATE TABLE bookings (
    booking_id INT AUTO_INCREMENT PRIMARY KEY,
    booking_reference VARCHAR(30) NOT NULL UNIQUE,
    user_id INT NOT NULL,
    package_id INT NOT NULL,
    booking_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    travel_date DATE NOT NULL,
    number_of_people INT NOT NULL CHECK (number_of_people >= 1),
    total_price DECIMAL(10, 2) NOT NULL CHECK (total_price >= 0),
    special_preferences TEXT,
    payment_status ENUM('Unpaid', 'Paid', 'Refunded') DEFAULT 'Unpaid',
    status ENUM('Pending', 'Confirmed', 'Cancelled') DEFAULT 'Pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE,
    FOREIGN KEY (package_id) REFERENCES packages(package_id) ON DELETE RESTRICT,
    INDEX idx_booking_user (user_id),
    INDEX idx_booking_status (status)
) ENGINE=InnoDB;

-- 5. PAYMENTS TABLE
CREATE TABLE payments (
    payment_id INT AUTO_INCREMENT PRIMARY KEY,
    booking_id INT NOT NULL,
    user_id INT NOT NULL,
    amount DECIMAL(10, 2) NOT NULL CHECK (amount > 0),
    transaction_id VARCHAR(50) NOT NULL UNIQUE,
    payment_method ENUM('Card', 'UPI', 'NetBanking', 'DemoWallet') DEFAULT 'Card',
    payment_status ENUM('Success', 'Failed', 'Refunded') DEFAULT 'Success',
    payment_note VARCHAR(255) DEFAULT 'Demo payment — no real money is charged.',
    payment_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (booking_id) REFERENCES bookings(booking_id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE,
    INDEX idx_pay_booking (booking_id),
    INDEX idx_pay_txn (transaction_id)
) ENGINE=InnoDB;

-- 6. ADMIN AUDIT LOGS TABLE
CREATE TABLE admin_logs (
    log_id INT AUTO_INCREMENT PRIMARY KEY,
    admin_id INT NOT NULL,
    action VARCHAR(100) NOT NULL,
    target_entity VARCHAR(50) NOT NULL,
    target_id VARCHAR(50),
    details TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (admin_id) REFERENCES users(user_id) ON DELETE CASCADE,
    INDEX idx_admin_log_date (created_at DESC)
) ENGINE=InnoDB;
