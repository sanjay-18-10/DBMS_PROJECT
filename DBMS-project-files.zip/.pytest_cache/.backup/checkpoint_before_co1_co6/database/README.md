# Database Architecture & Syllabus Mapping

This directory provides the database demonstrations for the **Travel Package Booking Portal**, covering both the primary NoSQL database (**MongoDB**) and the syllabus-mandated relational database engineering (**RDBMS / SQL**).

---

## 1. Primary Application Database: MongoDB (NoSQL)

The live production application runs on **MongoDB** with **Mongoose ODM**.

### Why MongoDB Was Chosen for the Travel Portal:
1. **Dynamic Schema**: Travel packages have rich, varying attributes (itinerary highlights, seasonal tags, optional add-ons) that naturally fit BSON documents.
2. **High Read Performance & Scalability**: Fast catalog browsing and search with compound and text indexes.
3. **Embedded vs. Referenced Data**:
   - `addOns` are embedded directly inside the `Booking` document (composite values that belong strictly to one booking).
   - `User` and `Package` are referenced via `ObjectId` to avoid duplicating customer and catalog records across millions of bookings.

---

## 2. Academic Relational Demonstration: SQL / RDBMS (CO1)

To demonstrate the **CO1** concepts from the academic DBMS syllabus, the `database/sql/` folder contains pure SQL scripts ready for demonstration:

| File | Syllabus Concept Demonstrated |
| :--- | :--- |
| `schema.sql` | DDL, Primary Keys, Foreign Keys, 1NF/2NF/3NF Normalization, Check Constraints, Indexes |
| `queries.sql` | DML (Insert, Update, Delete), Filtering, Multi-table `INNER JOIN`, `LEFT OUTER JOIN` |
| `advanced_queries.sql` | Subqueries, Correlated Subqueries, Common Table Expressions (CTEs), Recursive CTE, Window Functions (`RANK`, `DENSE_RANK`, `ROW_NUMBER`, `SUM() OVER`), `HAVING` clause |
| `transactions.sql` | ACID Transactions (`START TRANSACTION`, `COMMIT`, `ROLLBACK`), Row Locking (`FOR UPDATE`), Stored Procedures, and Triggers |

---

## 3. SQL vs. MongoDB Equivalent Operations

| Operation | SQL (Relational) | MongoDB (Document / NoSQL) |
| :--- | :--- | :--- |
| **Data Container** | Table | Collection |
| **Row / Record** | Row / Tuple | BSON Document |
| **Column** | Column / Attribute | Field / Key-Value |
| **Primary Key** | `PRIMARY KEY` (e.g. `INT AUTO_INCREMENT`) | `_id` (`ObjectId`) |
| **Join Tables** | `INNER JOIN` / `LEFT JOIN` | `$lookup` aggregation pipeline or Mongoose `.populate()` |
| **Data Integrity** | Foreign Key (`REFERENCES ... ON DELETE RESTRICT`) | Application-level validation & Mongoose Schema constraints |
| **Grouping & Aggregates** | `SELECT ... GROUP BY ... HAVING` | `$group`, `$match`, `$project` aggregation pipeline |
| **Window Functions** | `RANK() OVER (PARTITION BY ...)` | Multi-stage Aggregation (`$setWindowFields` / `$group` + `$push`) |
| **Transactions** | `START TRANSACTION ... COMMIT / ROLLBACK` | Session Transactions (`session.startTransaction()`) |
| **Indexing** | B-Tree Index (`CREATE INDEX ...`) | B-Tree Index (`db.collection.createIndex()`) |
