const User = require("../models/User");
const Package = require("../models/Package");
const Booking = require("../models/Booking");
const Payment = require("../models/Payment");
const AdminLog = require("../models/AdminLog");

// @desc    Get comprehensive analytics using MongoDB Aggregation Framework
// @route   GET /api/admin/analytics
// @access  Private / Admin
const getAdminAnalytics = async (req, res) => {
    try {
        // 1. Basic counts
        const totalUsers = await User.countDocuments({ role: "user" });
        const totalAdmins = await User.countDocuments({ role: "admin" });
        const totalPackages = await Package.countDocuments();
        const activePackages = await Package.countDocuments({ isActive: true });
        const retiredPackages = await Package.countDocuments({ isActive: false });
        const totalBookings = await Booking.countDocuments();

        // 2. Aggregation Pipeline: Revenue & Payment Status Summary
        // Demonstrates $group, $sum, $match
        const revenueStats = await Booking.aggregate([
            {
                $group: {
                    _id: "$paymentStatus",
                    totalRevenue: { $sum: "$totalPrice" },
                    count: { $sum: 1 }
                }
            }
        ]);

        let paidRevenue = 0;
        let unpaidRevenue = 0;
        let refundedRevenue = 0;

        revenueStats.forEach(stat => {
            if (stat._id === "Paid") paidRevenue = stat.totalRevenue;
            if (stat._id === "Unpaid") unpaidRevenue = stat.totalRevenue;
            if (stat._id === "Refunded") refundedRevenue = stat.totalRevenue;
        });

        // 3. Aggregation Pipeline: Booking Status Breakdown
        const bookingsByStatus = await Booking.aggregate([
            {
                $group: {
                    _id: "$status",
                    count: { $sum: 1 }
                }
            }
        ]);

        // 4. Aggregation Pipeline: Top Booked Packages with $lookup (Relational Join in MongoDB)
        const popularPackages = await Booking.aggregate([
            {
                $group: {
                    _id: "$package",
                    totalBookings: { $sum: 1 },
                    totalTravelers: { $sum: "$numberOfPeople" },
                    revenueGenerated: { $sum: "$totalPrice" }
                }
            },
            { $sort: { totalBookings: -1 } },
            { $limit: 5 },
            {
                $lookup: {
                    from: "packages",
                    localField: "_id",
                    foreignField: "_id",
                    as: "packageDetails"
                }
            },
            { $unwind: "$packageDetails" },
            {
                $project: {
                    _id: 1,
                    totalBookings: 1,
                    totalTravelers: 1,
                    revenueGenerated: 1,
                    name: "$packageDetails.name",
                    destination: "$packageDetails.destination",
                    price: "$packageDetails.price"
                }
            }
        ]);

        // 5. Aggregation Pipeline: Bookings by Destination
        const destinationStats = await Booking.aggregate([
            {
                $lookup: {
                    from: "packages",
                    localField: "package",
                    foreignField: "_id",
                    as: "pkg"
                }
            },
            { $unwind: "$pkg" },
            {
                $group: {
                    _id: "$pkg.destination",
                    bookingsCount: { $sum: 1 },
                    revenue: { $sum: "$totalPrice" }
                }
            },
            { $sort: { bookingsCount: -1 } }
        ]);

        res.status(200).json({
            overview: {
                totalUsers,
                totalAdmins,
                totalPackages,
                activePackages,
                retiredPackages,
                totalBookings,
                paidRevenue,
                unpaidRevenue,
                refundedRevenue
            },
            bookingsByStatus,
            popularPackages,
            destinationStats
        });

    } catch (error) {
        res.status(500).json({
            message: "Failed to fetch admin analytics",
            error: error.message
        });
    }
};

// @desc    Get administrative activity logs
// @route   GET /api/admin/logs
// @access  Private / Admin
const getAdminLogs = async (req, res) => {
    try {
        const logs = await AdminLog.find()
            .populate("admin", "name email")
            .sort({ createdAt: -1 })
            .limit(100);

        res.status(200).json(logs);
    } catch (error) {
        res.status(500).json({
            message: "Failed to fetch admin logs",
            error: error.message
        });
    }
};

module.exports = {
    getAdminAnalytics,
    getAdminLogs
};
