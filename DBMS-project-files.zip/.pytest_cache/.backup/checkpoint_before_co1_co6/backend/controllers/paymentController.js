const Payment = require("../models/Payment");
const Booking = require("../models/Booking");
const AdminLog = require("../models/AdminLog");

// @desc    Process simulated payment for a booking
// @route   POST /api/payments/process
// @access  Public / Private (supports demo flow)
const processPayment = async (req, res) => {
    try {
        const { bookingId, paymentMethod } = req.body;

        if (!bookingId) {
            return res.status(400).json({ message: "Booking ID is required" });
        }

        const booking = await Booking.findById(bookingId).populate("user").populate("package");

        if (!booking) {
            return res.status(404).json({ message: "Booking not found" });
        }

        if (booking.status === "Cancelled") {
            return res.status(400).json({ message: "Cannot pay for a cancelled booking" });
        }

        if (booking.paymentStatus === "Paid") {
            return res.status(400).json({ message: "This booking has already been paid for" });
        }

        // Generate realistic transaction reference
        const transactionId = `TXN-${Date.now().toString().slice(-6)}-${Math.random().toString(36).substring(2, 7).toUpperCase()}`;

        // Create Payment record
        const payment = await Payment.create({
            booking: booking._id,
            user: booking.user._id,
            amount: booking.totalPrice,
            transactionId,
            paymentMethod: paymentMethod || "Card",
            paymentStatus: "Success",
            paymentNote: "Demo payment — no real money is charged."
        });

        // Update booking state: payment confirmed & status confirmed
        booking.paymentStatus = "Paid";
        booking.status = "Confirmed";
        await booking.save();

        res.status(201).json({
            message: "Payment processed successfully (Demo Mode)",
            payment,
            booking: {
                _id: booking._id,
                bookingReference: booking.bookingReference,
                totalPrice: booking.totalPrice,
                status: booking.status,
                paymentStatus: booking.paymentStatus,
                transactionId
            }
        });

    } catch (error) {
        res.status(500).json({
            message: "Payment processing failed",
            error: error.message
        });
    }
};

// @desc    Get all payment records (for Admin)
// @route   GET /api/payments
// @access  Private / Admin
const getAllPayments = async (req, res) => {
    try {
        const payments = await Payment.find()
            .populate("user", "name email phone")
            .populate({
                path: "booking",
                select: "bookingReference totalPrice status numberOfPeople",
                populate: {
                    path: "package",
                    select: "name destination"
                }
            })
            .sort({ createdAt: -1 });

        res.status(200).json(payments);
    } catch (error) {
        res.status(500).json({
            message: "Failed to fetch payments",
            error: error.message
        });
    }
};

// @desc    Get payment receipt for a specific booking
// @route   GET /api/payments/booking/:bookingId
// @access  Private
const getPaymentByBooking = async (req, res) => {
    try {
        const payment = await Payment.findOne({ booking: req.params.bookingId })
            .populate("user", "name email phone")
            .populate("booking");

        if (!payment) {
            return res.status(404).json({ message: "No payment record found for this booking" });
        }

        res.status(200).json(payment);
    } catch (error) {
        res.status(500).json({
            message: "Failed to fetch payment details",
            error: error.message
        });
    }
};

module.exports = {
    processPayment,
    getAllPayments,
    getPaymentByBooking
};
