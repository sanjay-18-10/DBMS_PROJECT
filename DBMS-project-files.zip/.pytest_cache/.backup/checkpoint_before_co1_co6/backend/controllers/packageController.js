const Package = require("../models/Package");
const Booking = require("../models/Booking");
const AdminLog = require("../models/AdminLog");

// @desc    Create a new travel package
// @route   POST /api/packages
// @access  Private / Admin
const createPackage = async (req, res) => {
    try {
        const {
            name,
            destination,
            description,
            price,
            duration,
            availableSeats,
            category,
            image,
            featured,
            highlights
        } = req.body;

        const newPackage = await Package.create({
            name,
            destination,
            description,
            price,
            duration,
            availableSeats,
            category: category || "Holiday",
            image: image || "https://images.unsplash.com/photo-1469854523086-cc02fe5d8800?w=800&auto=format&fit=crop&q=60",
            featured: featured || false,
            highlights: highlights || []
        });

        // Audit log if action performed by authenticated admin
        if (req.user) {
            await AdminLog.create({
                admin: req.user._id,
                action: "CREATE_PACKAGE",
                targetEntity: "Package",
                targetId: newPackage._id.toString(),
                details: `Created package '${newPackage.name}' in '${newPackage.destination}' for INR ${newPackage.price}`
            }).catch(err => console.error("Logging error:", err));
        }

        res.status(201).json({
            message: "Travel package created successfully",
            package: newPackage
        });

    } catch (error) {
        res.status(500).json({
            message: "Failed to create travel package",
            error: error.message
        });
    }
};

// @desc    Get all travel packages with filtering, search, and sorting
// @route   GET /api/packages
// @access  Public
const getPackages = async (req, res) => {
    try {
        const {
            search,
            destination,
            category,
            minPrice,
            maxPrice,
            duration,
            includeInactive,
            sortBy
        } = req.query;

        // Build dynamic MongoDB query object
        const query = {};

        // Unless requested by admin, only show active packages (matches true and legacy docs)
        if (includeInactive !== "true") {
            query.isActive = { $ne: false };
        }

        // Search in name, destination, or description
        if (search) {
            query.$or = [
                { name: { $regex: search, $options: "i" } },
                { destination: { $regex: search, $options: "i" } },
                { description: { $regex: search, $options: "i" } }
            ];
        }

        if (destination) {
            query.destination = { $regex: destination, $options: "i" };
        }

        if (category && category !== "All") {
            query.category = category;
        }

        if (minPrice || maxPrice) {
            query.price = {};
            if (minPrice) query.price.$gte = Number(minPrice);
            if (maxPrice) query.price.$lte = Number(maxPrice);
        }

        if (duration) {
            query.duration = Number(duration);
        }

        // Sorting options
        let sortOption = { createdAt: -1 };
        if (sortBy === "price_asc") sortOption = { price: 1 };
        if (sortBy === "price_desc") sortOption = { price: -1 };
        if (sortBy === "duration_asc") sortOption = { duration: 1 };
        if (sortBy === "duration_desc") sortOption = { duration: -1 };
        if (sortBy === "seats_desc") sortOption = { availableSeats: -1 };

        const packages = await Package.find(query).sort(sortOption);

        res.status(200).json(packages);

    } catch (error) {
        res.status(500).json({
            message: "Failed to fetch travel packages",
            error: error.message
        });
    }
};

// @desc    Get single travel package by ID
// @route   GET /api/packages/:id
// @access  Public
const getPackageById = async (req, res) => {
    try {
        const travelPackage = await Package.findById(req.params.id);

        if (!travelPackage) {
            return res.status(404).json({
                message: "Travel package not found"
            });
        }

        res.status(200).json(travelPackage);
    } catch (error) {
        res.status(500).json({
            message: "Failed to fetch package",
            error: error.message
        });
    }
};

// @desc    Update a travel package
// @route   PUT /api/packages/:id
// @access  Private / Admin
const updatePackage = async (req, res) => {
    try {
        const packageId = req.params.id;

        const updatedPackage = await Package.findByIdAndUpdate(
            packageId,
            req.body,
            {
                new: true,
                runValidators: true
            }
        );

        if (!updatedPackage) {
            return res.status(404).json({
                message: "Package not found"
            });
        }

        if (req.user) {
            await AdminLog.create({
                admin: req.user._id,
                action: "UPDATE_PACKAGE",
                targetEntity: "Package",
                targetId: updatedPackage._id.toString(),
                details: `Updated package '${updatedPackage.name}'`
            }).catch(err => console.error("Logging error:", err));
        }

        res.status(200).json({
            message: "Package updated successfully",
            package: updatedPackage
        });

    } catch (error) {
        res.status(500).json({
            message: "Failed to update package",
            error: error.message
        });
    }
};

// @desc    Retire / Deactivate / Reactivate a travel package (Soft toggle)
// @route   PATCH /api/packages/:id/status
// @access  Private / Admin
const togglePackageStatus = async (req, res) => {
    try {
        const travelPackage = await Package.findById(req.params.id);

        if (!travelPackage) {
            return res.status(404).json({ message: "Package not found" });
        }

        travelPackage.isActive = !travelPackage.isActive;
        await travelPackage.save();

        if (req.user) {
            await AdminLog.create({
                admin: req.user._id,
                action: travelPackage.isActive ? "ACTIVATE_PACKAGE" : "RETIRE_PACKAGE",
                targetEntity: "Package",
                targetId: travelPackage._id.toString(),
                details: `${travelPackage.isActive ? "Reactivated" : "Retired/Deactivated"} package '${travelPackage.name}'`
            }).catch(err => console.error("Logging error:", err));
        }

        res.status(200).json({
            message: `Package successfully ${travelPackage.isActive ? "activated" : "retired/deactivated"}`,
            package: travelPackage
        });
    } catch (error) {
        res.status(500).json({
            message: "Failed to toggle package status",
            error: error.message
        });
    }
};

// @desc    Delete a travel package (Demonstrating referential integrity check)
// @route   DELETE /api/packages/:id
// @access  Private / Admin
const deletePackage = async (req, res) => {
    try {
        const packageId = req.params.id;

        // Check if there are active bookings for this package (Foreign Key constraint concept)
        const activeBookings = await Booking.find({
            package: packageId,
            status: { $ne: "Cancelled" }
        });

        if (activeBookings.length > 0) {
            return res.status(400).json({
                message: `Cannot delete package: ${activeBookings.length} active booking(s) exist. Please retire the package instead or cancel the bookings.`
            });
        }

        const deleted = await Package.findByIdAndDelete(packageId);

        if (!deleted) {
            return res.status(404).json({ message: "Package not found" });
        }

        if (req.user) {
            await AdminLog.create({
                admin: req.user._id,
                action: "DELETE_PACKAGE",
                targetEntity: "Package",
                targetId: packageId,
                details: `Deleted package '${deleted.name}'`
            }).catch(err => console.error("Logging error:", err));
        }

        res.status(200).json({
            message: "Package deleted successfully",
            packageId
        });
    } catch (error) {
        res.status(500).json({
            message: "Failed to delete package",
            error: error.message
        });
    }
};

module.exports = {
    createPackage,
    getPackages,
    getPackageById,
    updatePackage,
    togglePackageStatus,
    deletePackage
};