const Booking = require("../models/Booking");
const User = require("../models/User");
const Package = require("../models/Package");
const AdminLog = require("../models/AdminLog");

// @desc    Create a new booking
// @route   POST /api/bookings
// @access  Public / Private (supports both manual user ID and JWT authenticated user)
const createBooking = async (req, res) => {
    try {
        const {
            user: userIdFromBody,
            package: packageId,
            numberOfPeople,
            travelDate,
            specialPreferences,
            addOns
        } = req.body;

        // Prefer authenticated user id from JWT token if available, else use body user ID
        const userId = (req.user && req.user._id) ? req.user._id : userIdFromBody;

        if (!userId) {
            return res.status(400).json({
                message: "User ID is required to place a booking"
            });
        }

        if (!packageId) {
            return res.status(400).json({
                message: "Package ID is required"
            });
        }

        const peopleCount = Number(numberOfPeople);
        if (!peopleCount || peopleCount < 1) {
            return res.status(400).json({
                message: "Number of travelers must be at least 1"
            });
        }

        // Check if user exists
        const existingUser = await User.findById(userId);
        if (!existingUser) {
            return res.status(404).json({
                message: "User not found"
            });
        }

        // Check if package exists
        const travelPackage = await Package.findById(packageId);
        if (!travelPackage) {
            return res.status(404).json({
                message: "Travel package not found"
            });
        }

        // Check if package is active
        if (travelPackage.isActive === false) {
            return res.status(400).json({
                message: "This travel package is currently retired / inactive and cannot be booked"
            });
        }

        // Check available seats (Concurrency / Constraint check)
        if (travelPackage.availableSeats < peopleCount) {
            return res.status(400).json({
                message: `Not enough seats available. Requested: ${peopleCount}, Available: ${travelPackage.availableSeats}`
            });
        }

        // Calculate add-ons cost if any
        let addOnsCost = 0;
        let formattedAddOns = [];
        if (Array.isArray(addOns)) {
            formattedAddOns = addOns.filter(a => a && a.name);
            addOnsCost = formattedAddOns.reduce((sum, item) => sum + (Number(item.price) || 0), 0);
        }

        // Calculate total price: (Base package price * travelers) + Add-ons
        const totalPrice = (travelPackage.price * peopleCount) + addOnsCost;

        // Create booking
        const booking = await Booking.create({
            user: userId,
            package: packageId,
            numberOfPeople: peopleCount,
            totalPrice,
            travelDate: travelDate ? new Date(travelDate) : new Date(Date.now() + 7 * 24 * 60 * 60 * 1000),
            specialPreferences: specialPreferences || "",
            addOns: formattedAddOns,
            status: "Pending",
            paymentStatus: "Unpaid"
        });

        // Atomic inventory reduction: Reduce available seats
        travelPackage.availableSeats -= peopleCount;
        await travelPackage.save();

        // Populate package and user for clean immediate response
        const populatedBooking = await Booking.findById(booking._id)
            .populate("user", "name email phone")
            .populate("package", "name destination price duration image");

        res.status(201).json({
            message: "Booking created successfully",
            booking: populatedBooking
        });

    } catch (error) {
        res.status(500).json({
            message: "Failed to create booking",
            error: error.message
        });
    }
};

// @desc    Get all bookings (Admin view with optional status filter)
// @route   GET /api/bookings
// @access  Private / Admin
const getBookings = async (req, res) => {
    try {
        const query = {};
        if (req.query.status) {
            query.status = req.query.status;
        }

        const bookings = await Booking.find(query)
            .populate("user", "name email phone")
            .populate("package", "name destination price duration image availableSeats")
            .sort({ createdAt: -1 });

        res.status(200).json(bookings);

    } catch (error) {
        res.status(500).json({
            message: "Failed to fetch bookings",
            error: error.message
        });
    }
};

// @desc    Get logged in user's bookings (Traveler Dashboard)
// @route   GET /api/bookings/mine
// @access  Private
const getMyBookings = async (req, res) => {
    try {
        const userId = req.user ? req.user._id : req.query.userId;

        if (!userId) {
            return res.status(400).json({ message: "User identity required" });
        }

        const bookings = await Booking.find({ user: userId })
            .populate("package", "name destination price duration image category")
            .sort({ createdAt: -1 });

        res.status(200).json(bookings);
    } catch (error) {
        res.status(500).json({
            message: "Failed to fetch your bookings",
            error: error.message
        });
    }
};

// @desc    Get single booking by ID
// @route   GET /api/bookings/:id
// @access  Private
const getBookingById = async (req, res) => {
    try {
        const booking = await Booking.findById(req.params.id)
            .populate("user", "name email phone")
            .populate("package", "name destination price duration image description");

        if (!booking) {
            return res.status(404).json({ message: "Booking not found" });
        }

        // Authorization check: User can only view their own booking unless admin
        if (
            req.user &&
            req.user.role !== "admin" &&
            booking.user._id.toString() !== req.user._id.toString()
        ) {
            return res.status(403).json({ message: "Not authorized to view this booking" });
        }

        res.status(200).json(booking);
    } catch (error) {
        res.status(500).json({
            message: "Failed to fetch booking details",
            error: error.message
        });
    }
};

// @desc    Cancel booking and restore inventory seats (Demonstrating Transaction / Compensation logic)
// @route   PUT /api/bookings/:id/cancel
// @access  Private
const cancelBooking = async (req, res) => {
    try {
        const booking = await Booking.findById(req.params.id);

        if (!booking) {
            return res.status(404).json({ message: "Booking not found" });
        }

        // Authorization check: User can only cancel their own booking unless admin
        if (
            req.user &&
            req.user.role !== "admin" &&
            booking.user.toString() !== req.user._id.toString()
        ) {
            return res.status(403).json({ message: "Not authorized to cancel this booking" });
        }

        if (booking.status === "Cancelled") {
            return res.status(400).json({ message: "Booking is already cancelled" });
        }

        // Mark as cancelled
        booking.status = "Cancelled";
        if (booking.paymentStatus === "Paid") {
            booking.paymentStatus = "Refunded";
        }
        await booking.save();

        // Restore inventory seats back to the package
        const travelPackage = await Package.findById(booking.package);
        if (travelPackage) {
            travelPackage.availableSeats += booking.numberOfPeople;
            await travelPackage.save();
        }

        // Log cancellation
        if (req.user) {
            await AdminLog.create({
                admin: req.user._id,
                action: "CANCEL_BOOKING",
                targetEntity: "Booking",
                targetId: booking._id.toString(),
                details: `Cancelled booking ${booking.bookingReference || booking._id} and restored ${booking.numberOfPeople} seats to package`
            }).catch(err => console.error("Logging error:", err));
        }

        res.status(200).json({
            message: "Booking cancelled successfully and seats restored",
            booking
        });

    } catch (error) {
        res.status(500).json({
            message: "Failed to cancel booking",
            error: error.message
        });
    }
};

module.exports = {
    createBooking,
    getBookings,
    getMyBookings,
    getBookingById,
    cancelBooking
};