const express = require("express");
const {
    createPackage,
    getPackages,
    getPackageById,
    updatePackage,
    togglePackageStatus,
    deletePackage
} = require("../controllers/packageController");
const { protect, adminOnly } = require("../middleware/authMiddleware");

const router = express.Router();

// Public routes
router.get("/", getPackages);
router.get("/:id", getPackageById);

// Admin-protected routes
router.post("/", protect, adminOnly, createPackage);
router.put("/:id", protect, adminOnly, updatePackage);
router.patch("/:id/status", protect, adminOnly, togglePackageStatus);
router.delete("/:id", protect, adminOnly, deletePackage);

module.exports = router;