const express = require("express");
const {
    createBooking,
    getBookings,
    getMyBookings,
    getBookingById,
    cancelBooking
} = require("../controllers/bookingController");
const { protect, optionalProtect, adminOnly } = require("../middleware/authMiddleware");

const router = express.Router();

// Create booking (supports both logged-in traveler and direct ID request)
router.post("/", optionalProtect, createBooking);

// Traveler's own bookings (MUST precede /:id)
router.get("/mine", protect, getMyBookings);

// Admin view all bookings
router.get("/", protect, adminOnly, getBookings);

// Booking by ID
router.get("/:id", protect, getBookingById);

// Cancel booking and restore inventory seats
router.put("/:id/cancel", protect, cancelBooking);

module.exports = router;