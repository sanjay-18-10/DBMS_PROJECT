const express = require("express");
const {
    getAdminAnalytics,
    getAdminLogs
} = require("../controllers/adminController");
const { protect, adminOnly } = require("../middleware/authMiddleware");

const router = express.Router();

// Admin analytics powered by MongoDB Aggregations
router.get("/analytics", protect, adminOnly, getAdminAnalytics);

// Admin audit logs
router.get("/logs", protect, adminOnly, getAdminLogs);

module.exports = router;
