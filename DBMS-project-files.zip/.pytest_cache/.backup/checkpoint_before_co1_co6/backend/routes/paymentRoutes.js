const express = require("express");
const {
    processPayment,
    getAllPayments,
    getPaymentByBooking
} = require("../controllers/paymentController");
const { protect, adminOnly, optionalProtect } = require("../middleware/authMiddleware");

const router = express.Router();

// Process simulated payment
router.post("/process", optionalProtect, processPayment);

// Admin view all payments
router.get("/", protect, adminOnly, getAllPayments);

// Get payment receipt for a specific booking
router.get("/booking/:bookingId", optionalProtect, getPaymentByBooking);

module.exports = router;
