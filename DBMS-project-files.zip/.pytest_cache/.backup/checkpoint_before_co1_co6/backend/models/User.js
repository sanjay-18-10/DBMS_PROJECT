const mongoose = require("mongoose");
const bcrypt = require("bcryptjs");

const userSchema = new mongoose.Schema(
    {
        name: {
            type: String,
            required: [true, "Name is required"],
            trim: true
        },

        email: {
            type: String,
            required: [true, "Email is required"],
            unique: true,
            lowercase: true,
            trim: true,
            match: [
                /^\w+([.-]?\w+)*@\w+([.-]?\w+)*(\.\w{2,3})+$/,
                "Please enter a valid email address"
            ]
        },

        password: {
            type: String,
            required: [true, "Password is required"],
            minlength: [6, "Password must be at least 6 characters"]
        },

        phone: {
            type: String,
            required: [true, "Phone number is required"],
            trim: true
        },

        role: {
            type: String,
            enum: ["user", "admin"],
            default: "user"
        }
    },
    {
        timestamps: true
    }
);

// Method to verify password (supports bcrypt hash and legacy plaintext fallback)
userSchema.methods.matchPassword = async function (enteredPassword) {
    if (this.password.startsWith("$2a$") || this.password.startsWith("$2b$")) {
        return await bcrypt.compare(enteredPassword, this.password);
    }
    // Backward compatibility for existing plaintext records
    return enteredPassword === this.password;
};

// Pre-save hook to hash password before saving if modified
userSchema.pre("save", async function () {
    if (!this.isModified("password")) {
        return;
    }
    // Only hash if not already hashed
    if (!this.password.startsWith("$2a$") && !this.password.startsWith("$2b$")) {
        const salt = await bcrypt.genSalt(10);
        this.password = await bcrypt.hash(this.password, salt);
    }
});

const User = mongoose.model("User", userSchema);

module.exports = User;