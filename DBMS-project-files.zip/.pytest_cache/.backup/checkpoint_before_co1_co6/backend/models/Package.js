const mongoose = require("mongoose");

const packageSchema = new mongoose.Schema(
    {
        name: {
            type: String,
            required: [true, "Package name is required"],
            trim: true
        },

        destination: {
            type: String,
            required: [true, "Destination is required"],
            trim: true
        },

        description: {
            type: String,
            required: [true, "Description is required"],
            trim: true
        },

        price: {
            type: Number,
            required: [true, "Price is required"],
            min: [0, "Price must be a positive number"]
        },

        duration: {
            type: Number,
            required: [true, "Duration is required"],
            min: [1, "Duration must be at least 1 day"]
        },

        availableSeats: {
            type: Number,
            required: [true, "Available seats are required"],
            min: [0, "Available seats cannot be negative"]
        },

        category: {
            type: String,
            enum: ["Beach", "Mountain", "Heritage", "Wildlife", "Adventure", "Holiday", "Spiritual"],
            default: "Holiday"
        },

        image: {
            type: String,
            default: "https://images.unsplash.com/photo-1469854523086-cc02fe5d8800?w=800&auto=format&fit=crop&q=60"
        },

        featured: {
            type: Boolean,
            default: false
        },

        isActive: {
            type: Boolean,
            default: true
        },

        highlights: {
            type: [String],
            default: []
        }
    },
    {
        timestamps: true
    }
);

// Indexes to demonstrate DBMS indexing concepts and boost query performance
packageSchema.index({ destination: 1, price: 1 });
packageSchema.index({ isActive: 1 });
packageSchema.index({ name: "text", destination: "text", description: "text" });

const Package = mongoose.model("Package", packageSchema);

module.exports = Package;