const mongoose = require("mongoose");

const paymentSchema = new mongoose.Schema(
    {
        booking: {
            type: mongoose.Schema.Types.ObjectId,
            ref: "Booking",
            required: [true, "Booking ID is required"]
        },

        user: {
            type: mongoose.Schema.Types.ObjectId,
            ref: "User",
            required: [true, "User ID is required"]
        },

        amount: {
            type: Number,
            required: [true, "Payment amount is required"],
            min: [0, "Amount must be positive"]
        },

        transactionId: {
            type: String,
            required: true,
            unique: true
        },

        paymentMethod: {
            type: String,
            enum: ["Card", "UPI", "NetBanking", "DemoWallet"],
            default: "Card"
        },

        paymentStatus: {
            type: String,
            enum: ["Success", "Failed", "Refunded"],
            default: "Success"
        },

        paymentNote: {
            type: String,
            default: "Demo payment — no real money is charged."
        }
    },
    {
        timestamps: true
    }
);

paymentSchema.index({ booking: 1 });
paymentSchema.index({ user: 1 });

const Payment = mongoose.model("Payment", paymentSchema);

module.exports = Payment;
