const mongoose = require("mongoose");

const adminLogSchema = new mongoose.Schema(
    {
        admin: {
            type: mongoose.Schema.Types.ObjectId,
            ref: "User",
            required: [true, "Admin user ID is required"]
        },

        action: {
            type: String,
            required: [true, "Action description is required"]
        },

        targetEntity: {
            type: String,
            enum: ["Package", "Booking", "User", "Payment", "System"],
            default: "Package"
        },

        targetId: {
            type: String
        },

        details: {
            type: String,
            required: true
        }
    },
    {
        timestamps: true
    }
);

adminLogSchema.index({ admin: 1 });
adminLogSchema.index({ createdAt: -1 });

const AdminLog = mongoose.model("AdminLog", adminLogSchema);

module.exports = AdminLog;
