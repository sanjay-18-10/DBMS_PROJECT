const mongoose = require("mongoose");

const bookingSchema = new mongoose.Schema(
    {
        bookingReference: {
            type: String,
            unique: true,
            trim: true
        },

        user: {
            type: mongoose.Schema.Types.ObjectId,
            ref: "User",
            required: [true, "User reference is required"]
        },

        package: {
            type: mongoose.Schema.Types.ObjectId,
            ref: "Package",
            required: [true, "Package reference is required"]
        },

        bookingDate: {
            type: Date,
            default: Date.now
        },

        travelDate: {
            type: Date
        },

        numberOfPeople: {
            type: Number,
            required: [true, "Number of people is required"],
            min: [1, "Must book for at least 1 person"]
        },

        totalPrice: {
            type: Number,
            required: [true, "Total price is required"],
            min: [0, "Total price cannot be negative"]
        },

        specialPreferences: {
            type: String,
            default: ""
        },

        addOns: [
            {
                name: { type: String, required: true },
                price: { type: Number, required: true, default: 0 }
            }
        ],

        paymentStatus: {
            type: String,
            enum: ["Unpaid", "Paid", "Refunded"],
            default: "Unpaid"
        },

        status: {
            type: String,
            enum: ["Pending", "Confirmed", "Cancelled"],
            default: "Pending"
        }
    },
    {
        timestamps: true
    }
);

// Generate unique booking reference prior to saving if not already provided
bookingSchema.pre("save", function () {
    if (!this.bookingReference) {
        const randomDigits = Math.floor(1000 + Math.random() * 9000);
        const timestamp = Date.now().toString().slice(-4);
        this.bookingReference = `PKG-${timestamp}-${randomDigits}`;
    }
});

// Indexes for query optimization
bookingSchema.index({ user: 1 });
bookingSchema.index({ package: 1 });
bookingSchema.index({ status: 1 });

const Booking = mongoose.model("Booking", bookingSchema);

module.exports = Booking;