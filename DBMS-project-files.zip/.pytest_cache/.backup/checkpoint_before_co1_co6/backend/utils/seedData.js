const mongoose = require("mongoose");
const dotenv = require("dotenv");
const path = require("path");

dotenv.config({ path: path.join(__dirname, "../.env") });

const User = require("../models/User");
const Package = require("../models/Package");
const Booking = require("../models/Booking");
const Payment = require("../models/Payment");
const AdminLog = require("../models/AdminLog");

const seedDatabase = async () => {
    try {
        console.log("Connecting to MongoDB for safe seeding...");
        await mongoose.connect(process.env.MONGO_URI || "mongodb://localhost:27017/travel_booking");
        console.log("Connected to MongoDB successfully.");

        // 1. Ensure Admin User exists (Non-destructive)
        let adminUser = await User.findOne({ email: "admin@travelportal.com" });
        if (!adminUser) {
            adminUser = await User.create({
                name: "System Administrator",
                email: "admin@travelportal.com",
                password: "admin123", // Will be hashed by pre-save hook
                phone: "9988776655",
                role: "admin"
            });
            console.log(" Created default Admin: admin@travelportal.com (Password: admin123)");
        } else {
            console.log(" Admin already exists: admin@travelportal.com");
        }

        // 2. Ensure Demo Traveler exists
        let demoUser = await User.findOne({ email: "ganesh@test.com" });
        if (!demoUser) {
            demoUser = await User.create({
                name: "Ganesh Sharma",
                email: "ganesh@test.com",
                password: "123456",
                phone: "9876543210",
                role: "user"
            });
            console.log(" Created demo traveler: ganesh@test.com (Password: 123456)");
        } else {
            if (!demoUser.role) {
                demoUser.role = "user";
                await demoUser.save();
            }
            console.log(" Preserved existing traveler: ganesh@test.com");
        }

        let priyaUser = await User.findOne({ email: "priya@travel.com" });
        if (!priyaUser) {
            priyaUser = await User.create({
                name: "Priya Patel",
                email: "priya@travel.com",
                password: "password123",
                phone: "9811223344",
                role: "user"
            });
            console.log(" Created second demo traveler: priya@travel.com (Password: password123)");
        }

        // 3. Indian Travel Packages (Non-destructive: only insert if not already present by name)
        const packagesToSeed = [
            {
                name: "Kerala Explorer Backwaters & Hills",
                destination: "Kerala",
                description: "Experience serene Alleppey houseboats, misty Munnar tea plantations, and spice gardens of Thekkady.",
                price: 15000,
                duration: 5,
                availableSeats: 18,
                category: "Holiday",
                featured: true,
                image: "https://images.unsplash.com/photo-1602216056096-3b40cc0c9944?w=800&auto=format&fit=crop&q=60",
                highlights: ["Houseboat Stay in Alleppey", "Munnar Tea Gardens", "Kathakali Cultural Show", "Periyar Boat Safari"]
            },
            {
                name: "Goa Sun, Sands & Heritage Getaway",
                destination: "Goa",
                description: "Relax on scenic Calangute & Palolem beaches, explore Portuguese churches, and enjoy thrilling watersports.",
                price: 12500,
                duration: 4,
                availableSeats: 25,
                category: "Beach",
                featured: true,
                image: "https://images.unsplash.com/photo-1512343879784-a960bf40e7f2?w=800&auto=format&fit=crop&q=60",
                highlights: ["Watersports at Calangute", "Old Goa Basilica Tour", "Sunset Mandovi River Cruise", "Beach Shack Dinner"]
            },
            {
                name: "Himachal Snow & Valley Expedition",
                destination: "Himachal Pradesh",
                description: "Witness majestic Himalayan peaks, Solang Valley snow sports, Rohtang Pass, and scenic pine forests.",
                price: 22000,
                duration: 6,
                availableSeats: 15,
                category: "Mountain",
                featured: true,
                image: "https://images.unsplash.com/photo-1626621341517-bbf3d9990a23?w=800&auto=format&fit=crop&q=60",
                highlights: ["Solang Valley Adventure", "Rohtang Snow Point", "Mall Road Walk", "Atal Tunnel Experience"]
            },
            {
                name: "Royal Rajasthan Heritage & Forts Trail",
                destination: "Rajasthan",
                description: "Marvel at Jaipur's Amer Fort, Udaipur's Lake Palace, and Thar Desert camel safari under starlit skies.",
                price: 28000,
                duration: 7,
                availableSeats: 16,
                category: "Heritage",
                featured: true,
                image: "https://images.unsplash.com/photo-1599661046289-e31897846e41?w=800&auto=format&fit=crop&q=60",
                highlights: ["Amer Fort Sound & Light Show", "Udaipur Lake Pichola Boat Ride", "Sam Dunes Camel Safari", "Rajasthani Folk Dance"]
            },
            {
                name: "Kashmir Paradise Valley Journey",
                destination: "Kashmir",
                description: "Stay in a romantic Shikara on Dal Lake, explore Gulmarg gondola rides and pristine meadows of Pahalgam.",
                price: 26500,
                duration: 6,
                availableSeats: 12,
                category: "Mountain",
                featured: false,
                image: "https://images.unsplash.com/photo-1598091383021-15ddea10925d?w=800&auto=format&fit=crop&q=60",
                highlights: ["Dal Lake Houseboat Stay", "Gulmarg Gondola Ride Phase 1 & 2", "Betaab Valley Excursion", "Mughal Gardens Tour"]
            },
            {
                name: "Tamil Nadu Temple & Heritage Circuit",
                destination: "Tamil Nadu",
                description: "Discover Dravidian architectural wonders in Madurai Meenakshi Amman Temple, Tanjore Big Temple, and Shore Temple.",
                price: 16500,
                duration: 5,
                availableSeats: 20,
                category: "Spiritual",
                featured: false,
                image: "https://images.unsplash.com/photo-1582510003544-4d00b7f74220?w=800&auto=format&fit=crop&q=60",
                highlights: ["Meenakshi Amman Temple Darshan", "Mahabalipuram Shore Temples", "Brihadeeswarar Temple UNESCO Tour", "Chettinad Cuisine Experience"]
            }
        ];

        for (const pkgData of packagesToSeed) {
            const existingPkg = await Package.findOne({ destination: pkgData.destination });
            if (!existingPkg) {
                await Package.create(pkgData);
                console.log(` Created package: ${pkgData.name}`);
            } else {
                // Update missing fields if needed without overwriting seats
                if (!existingPkg.category || !existingPkg.image) {
                    existingPkg.category = pkgData.category;
                    existingPkg.image = pkgData.image;
                    existingPkg.highlights = pkgData.highlights;
                    existingPkg.featured = pkgData.featured;
                    await existingPkg.save();
                }
                console.log(` Preserved existing package for: ${existingPkg.destination}`);
            }
        }

        // 4. Sample Booking & Payment verification (Non-destructive)
        const bookingsCount = await Booking.countDocuments();
        if (bookingsCount <= 1) {
            const goaPkg = await Package.findOne({ destination: "Goa" });
            if (goaPkg && priyaUser && goaPkg.availableSeats >= 2) {
                const sampleBooking = await Booking.create({
                    user: priyaUser._id,
                    package: goaPkg._id,
                    numberOfPeople: 2,
                    totalPrice: goaPkg.price * 2,
                    travelDate: new Date(Date.now() + 15 * 24 * 60 * 60 * 1000),
                    specialPreferences: "Vegetarian meals preferred",
                    addOns: [{ name: "Airport Pickup & Drop", price: 1200 }],
                    status: "Confirmed",
                    paymentStatus: "Paid"
                });

                goaPkg.availableSeats -= 2;
                await goaPkg.save();

                await Payment.create({
                    booking: sampleBooking._id,
                    user: priyaUser._id,
                    amount: sampleBooking.totalPrice + 1200,
                    transactionId: `TXN-INIT-${Date.now().toString().slice(-6)}`,
                    paymentMethod: "Card",
                    paymentStatus: "Success",
                    paymentNote: "Demo payment — no real money is charged."
                });

                console.log(" Created demo confirmed booking and payment for Priya Patel");
            }
        }

        // 5. Initial Admin Log
        await AdminLog.create({
            admin: adminUser._id,
            action: "SYSTEM_INIT",
            targetEntity: "System",
            details: "Safe database verification and seeding completed."
        }).catch(() => {});

        console.log("\n Safe Database Seeding Complete!");
        console.log("==================================================");
        console.log(" Admin Login: admin@travelportal.com | admin123");
        console.log(" Demo Traveler: ganesh@test.com       | 123456");
        console.log(" Demo Traveler: priya@travel.com       | password123");
        console.log("==================================================");

        process.exit(0);
    } catch (error) {
        console.error("Seeding error:", error);
        process.exit(1);
    }
};

seedDatabase();
