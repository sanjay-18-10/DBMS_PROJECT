# Backend Documentation: Travel Package Booking Portal

This directory contains the Express.js and MongoDB backend server for the Travel Package Booking Portal.

---

## 🛠️ Tech Stack & Dependencies

- **Runtime**: Node.js
- **Framework**: Express.js (v5)
- **Database**: MongoDB Server (v8.3) via Mongoose ODM (v9)
- **Security & Authentication**: `jsonwebtoken` (JWT), `bcryptjs`
- **Cross-Origin**: `cors`
- **Environment**: `dotenv`
- **Development Tooling**: `nodemon`

---

## 🚀 Available Scripts

```bash
# Start backend server in production mode
npm start

# Start backend server with automatic live reload on file changes
npm run dev

# Safely seed initial admin and Indian travel packages without wiping data
npm run seed
```

---

## ⚙️ Environment Variables (`.env`)

```ini
MONGO_URI=mongodb://localhost:27017/travel_booking
PORT=5000
JWT_SECRET=super_secret_travel_portal_jwt_key_2026
NODE_ENV=development
```

---

## 📡 REST API Testing with `test.http`

Install the **REST Client** extension in VS Code. Open `backend/test.http` and click **Send Request** above any HTTP block to test endpoints live.
