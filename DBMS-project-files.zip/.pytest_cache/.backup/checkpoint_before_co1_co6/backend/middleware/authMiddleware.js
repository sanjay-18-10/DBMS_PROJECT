const jwt = require("jsonwebtoken");
const User = require("../models/User");

// Middleware to verify JWT token and protect routes
const protect = async (req, res, next) => {
    let token;

    if (
        req.headers.authorization &&
        req.headers.authorization.startsWith("Bearer")
    ) {
        try {
            token = req.headers.authorization.split(" ")[1];
            const decoded = jwt.verify(
                token,
                process.env.JWT_SECRET || "travel_secret_jwt_key_2026_default"
            );

            // Attach user document (excluding password) to request object
            req.user = await User.findById(decoded.id).select("-password");

            if (!req.user) {
                return res.status(401).json({
                    message: "User not found. Authentication invalid."
                });
            }

            return next();
        } catch (error) {
            return res.status(401).json({
                message: "Not authorized, token invalid or expired",
                error: error.message
            });
        }
    }

    if (!token) {
        return res.status(401).json({
            message: "Not authorized, no token provided"
        });
    }
};

// Optional auth middleware: sets req.user if valid token provided, but doesn't block if not
const optionalProtect = async (req, res, next) => {
    if (
        req.headers.authorization &&
        req.headers.authorization.startsWith("Bearer")
    ) {
        try {
            const token = req.headers.authorization.split(" ")[1];
            const decoded = jwt.verify(
                token,
                process.env.JWT_SECRET || "travel_secret_jwt_key_2026_default"
            );
            req.user = await User.findById(decoded.id).select("-password");
        } catch (error) {
            // Ignore error and proceed as guest
        }
    }
    next();
};

// Middleware for Role-Based Access Control (RBAC): Admin only
const adminOnly = (req, res, next) => {
    if (req.user && req.user.role === "admin") {
        next();
    } else {
        res.status(403).json({
            message: "Access denied. Administrator privileges required."
        });
    }
};

module.exports = {
    protect,
    optionalProtect,
    adminOnly
};
