/**
 * ============================================================================
 * TRAVEL PACKAGE BOOKING PORTAL - MAIN CLIENT APPLICATION
 * ============================================================================
 */

// Global UI Helper Functions
function showToast(message, type = "info") {
  const container = document.getElementById("toast-container");
  if (!container) return;

  const toast = document.createElement("div");
  toast.className = `toast toast-${type}`;
  toast.innerHTML = `<span>${message}</span>`;
  container.appendChild(toast);

  setTimeout(() => {
    toast.style.opacity = "0";
    toast.style.transform = "translateX(100%)";
    toast.style.transition = "all 0.3s ease";
    setTimeout(() => toast.remove(), 300);
  }, 4000);
}

function openModal(modalId) {
  const modal = document.getElementById(modalId);
  if (modal) modal.classList.add("active");
}

function closeModal(modalId) {
  const modal = document.getElementById(modalId);
  if (modal) modal.classList.remove("active");
}

function showSection(sectionId) {
  document.querySelectorAll("section[data-section]").forEach(sec => {
    sec.style.display = "none";
  });
  const target = document.querySelector(`section[data-section="${sectionId}"]`);
  if (target) target.style.display = "block";

  document.querySelectorAll(".nav-link").forEach(link => {
    link.classList.remove("active");
    if (link.getAttribute("data-target") === sectionId) {
      link.classList.add("active");
    }
  });

  window.scrollTo({ top: 0, behavior: "smooth" });

  if (sectionId === "admin") {
    AdminApp.init();
  } else if (sectionId === "dashboard") {
    App.loadUserDashboard();
  }
}

// Main App Object
const App = {
  currentPackages: [],
  selectedPackage: null,
  activeBookingForPayment: null,

  async init() {
    App.updateAuthUI();
    await App.loadPackages();
    App.setupEventListeners();
  },

  // 1. Authentication UI State
  updateAuthUI() {
    const user = API.auth.getUser();
    const guestNav = document.getElementById("nav-guest-actions");
    const userNav = document.getElementById("nav-user-actions");
    const adminLink = document.getElementById("nav-admin-link");
    const userBadgeName = document.getElementById("user-display-name");
    const userRoleTag = document.getElementById("user-display-role");

    if (user) {
      if (guestNav) guestNav.style.display = "none";
      if (userNav) userNav.style.display = "flex";
      if (userBadgeName) userBadgeName.textContent = user.name;
      if (userRoleTag) userRoleTag.textContent = user.role.toUpperCase();

      if (adminLink) {
        adminLink.style.display = user.role === "admin" ? "block" : "none";
      }
    } else {
      if (guestNav) guestNav.style.display = "flex";
      if (userNav) userNav.style.display = "none";
      if (adminLink) adminLink.style.display = "none";
    }
  },

  // 2. Fetch and Render Packages
  async loadPackages(filters = {}) {
    try {
      const packages = await API.packages.getAll(filters);
      App.currentPackages = packages;
      App.renderPackages(packages);
      App.renderFeaturedPackages(packages);
    } catch (err) {
      showToast(err.message, "error");
    }
  },

  renderPackages(packages) {
    const grid = document.getElementById("packages-grid");
    if (!grid) return;

    if (!packages || packages.length === 0) {
      grid.innerHTML = `
        <div style="grid-column: 1 / -1; text-align:center; padding: 60px 20px;">
          <h3 style="color:#64748b; margin-bottom:8px;">No travel packages match your filters</h3>
          <p style="color:#94a3b8;">Try clearing some filters or searching for another destination.</p>
        </div>
      `;
      return;
    }

    grid.innerHTML = packages.map(pkg => `
      <div class="package-card">
        <div class="card-image-wrap">
          <img src="${pkg.image || 'https://images.unsplash.com/photo-1469854523086-cc02fe5d8800?w=800'}" alt="${pkg.name}" loading="lazy">
          <div class="card-badge-top">
            <span class="badge badge-${(pkg.category || 'holiday').toLowerCase()}">${pkg.category || 'Holiday'}</span>
            ${pkg.featured ? '<span class="badge badge-confirmed">Featured</span>' : ''}
          </div>
          <span class="seats-badge ${pkg.availableSeats < 5 ? 'low' : ''}">
            ${pkg.availableSeats > 0 ? `${pkg.availableSeats} seats left` : 'Sold Out'}
          </span>
        </div>
        <div class="card-body">
          <div class="card-meta">
            <span>📍 ${pkg.destination}</span>
            <span>⏱️ ${pkg.duration} Days</span>
          </div>
          <h3 class="card-title">${pkg.name}</h3>
          <p class="card-desc">${pkg.description}</p>
          <div class="card-footer">
            <div class="price-box">
              <span class="price-label">Price per person</span>
              <span class="price-val">₹${pkg.price.toLocaleString("en-IN")}</span>
            </div>
            <div style="display:flex; gap:8px;">
              <button class="btn btn-secondary btn-sm" onclick="App.openDetailsModal('${pkg._id}')">Details</button>
              <button class="btn btn-primary btn-sm" ${pkg.availableSeats < 1 ? 'disabled' : ''} onclick="App.openBookingModal('${pkg._id}')">
                ${pkg.availableSeats > 0 ? 'Book Now' : 'Sold Out'}
              </button>
            </div>
          </div>
        </div>
      </div>
    `).join("");
  },

  renderFeaturedPackages(packages) {
    const featuredGrid = document.getElementById("featured-grid");
    if (!featuredGrid) return;
    const featured = packages.filter(p => p.featured || p.availableSeats > 0).slice(0, 3);
    
    featuredGrid.innerHTML = featured.map(pkg => `
      <div class="package-card">
        <div class="card-image-wrap">
          <img src="${pkg.image || 'https://images.unsplash.com/photo-1469854523086-cc02fe5d8800?w=800'}" alt="${pkg.name}">
          <div class="card-badge-top">
            <span class="badge badge-${(pkg.category || 'holiday').toLowerCase()}">${pkg.category || 'Holiday'}</span>
          </div>
          <span class="seats-badge">${pkg.availableSeats} seats left</span>
        </div>
        <div class="card-body">
          <div class="card-meta">
            <span>📍 ${pkg.destination}</span>
            <span>⏱️ ${pkg.duration} Days</span>
          </div>
          <h3 class="card-title">${pkg.name}</h3>
          <div class="card-footer">
            <div class="price-box">
              <span class="price-label">From</span>
              <span class="price-val">₹${pkg.price.toLocaleString("en-IN")}</span>
            </div>
            <button class="btn btn-primary btn-sm" onclick="App.openBookingModal('${pkg._id}')">Book</button>
          </div>
        </div>
      </div>
    `).join("");
  },

  // 3. Package Details Modal
  openDetailsModal(pkgId) {
    const pkg = App.currentPackages.find(p => p._id === pkgId);
    if (!pkg) return;

    App.selectedPackage = pkg;
    document.getElementById("detail-modal-title").textContent = pkg.name;
    document.getElementById("detail-image").src = pkg.image || "https://images.unsplash.com/photo-1469854523086-cc02fe5d8800?w=800";
    document.getElementById("detail-destination").textContent = pkg.destination;
    document.getElementById("detail-duration").textContent = `${pkg.duration} Days / ${pkg.duration - 1} Nights`;
    document.getElementById("detail-category").textContent = pkg.category || "Holiday";
    document.getElementById("detail-seats").textContent = `${pkg.availableSeats} Available Seats`;
    document.getElementById("detail-price").textContent = `₹${pkg.price.toLocaleString("en-IN")}`;
    document.getElementById("detail-desc").textContent = pkg.description;

    const highlightsList = document.getElementById("detail-highlights");
    if (highlightsList) {
      highlightsList.innerHTML = (pkg.highlights && pkg.highlights.length > 0)
        ? pkg.highlights.map(h => `<li>✨ ${h}</li>`).join("")
        : "<li>✨ Certified Local Tour Guide</li><li>✨ Premium Accommodation & Breakfast</li>";
    }

    openModal("modal-package-details");
  },

  // 4. Booking Modal & Dynamic Price Calculation
  openBookingModal(pkgId) {
    closeModal("modal-package-details");

    const user = API.auth.getUser();
    if (!user) {
      showToast("Please log in to book travel packages", "info");
      openModal("modal-login");
      return;
    }

    const pkg = App.currentPackages.find(p => p._id === pkgId);
    if (!pkg) return;

    App.selectedPackage = pkg;
    document.getElementById("book-pkg-name").textContent = pkg.name;
    document.getElementById("book-pkg-destination").textContent = pkg.destination;
    document.getElementById("book-pkg-price").textContent = `₹${pkg.price.toLocaleString("en-IN")}`;
    document.getElementById("book-pkg-seats").textContent = `${pkg.availableSeats} Seats Available`;

    // Reset fields
    document.getElementById("book-people").value = 1;
    document.getElementById("book-people").max = pkg.availableSeats;
    
    // Set default travel date to 7 days from now
    const nextWeek = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString().split("T")[0];
    document.getElementById("book-date").value = nextWeek;
    document.getElementById("book-date").min = new Date().toISOString().split("T")[0];
    
    document.getElementById("book-preferences").value = "";
    document.querySelectorAll(".addon-checkbox").forEach(cb => cb.checked = false);

    App.recalculateBookingPrice();
    openModal("modal-booking");
  },

  recalculateBookingPrice() {
    if (!App.selectedPackage) return;

    const people = Math.max(1, Number(document.getElementById("book-people").value) || 1);
    const basePrice = App.selectedPackage.price * people;

    let addonTotal = 0;
    document.querySelectorAll(".addon-checkbox:checked").forEach(cb => {
      addonTotal += Number(cb.getAttribute("data-price")) || 0;
    });

    const finalTotal = basePrice + addonTotal;

    document.getElementById("calc-base-price").textContent = `₹${App.selectedPackage.price.toLocaleString("en-IN")} × ${people} = ₹${basePrice.toLocaleString("en-IN")}`;
    document.getElementById("calc-addon-price").textContent = `₹${addonTotal.toLocaleString("en-IN")}`;
    document.getElementById("calc-total-price").textContent = `₹${finalTotal.toLocaleString("en-IN")}`;
  },

  async handleBookingSubmit(e) {
    e.preventDefault();
    if (!App.selectedPackage) return;

    const people = Number(document.getElementById("book-people").value);
    const travelDate = document.getElementById("book-date").value;
    const specialPreferences = document.getElementById("book-preferences").value.trim();

    if (people > App.selectedPackage.availableSeats) {
      showToast(`Only ${App.selectedPackage.availableSeats} seats available!`, "error");
      return;
    }

    const addOns = [];
    document.querySelectorAll(".addon-checkbox:checked").forEach(cb => {
      addOns.push({
        name: cb.getAttribute("data-name"),
        price: Number(cb.getAttribute("data-price"))
      });
    });

    try {
      const res = await API.bookings.create({
        package: App.selectedPackage._id,
        numberOfPeople: people,
        travelDate,
        specialPreferences,
        addOns
      });

      showToast("Booking created successfully!", "success");
      closeModal("modal-booking");

      // Refresh packages to reflect updated seat count
      await App.loadPackages();

      // Open Payment Simulation Modal directly
      App.openPaymentModal(res.booking);

    } catch (err) {
      showToast(err.message, "error");
    }
  },

  // 5. Simulated Payment Gateway Modal
  openPaymentModal(booking) {
    App.activeBookingForPayment = booking;

    document.getElementById("pay-booking-ref").textContent = booking.bookingReference || booking._id;
    document.getElementById("pay-amount").textContent = `₹${booking.totalPrice.toLocaleString("en-IN")}`;
    document.getElementById("pay-travelers").textContent = `${booking.numberOfPeople} Traveler(s)`;
    document.getElementById("pay-package-name").textContent = booking.package?.name || App.selectedPackage?.name || "Travel Package";

    openModal("modal-payment");
  },

  fillDemoCard() {
    document.getElementById("card-number").value = "4532 •••• •••• 8921";
    document.getElementById("card-exp").value = "12/28";
    document.getElementById("card-cvv").value = "789";
    document.getElementById("card-holder").value = API.auth.getUser()?.name || "Ganesh Sharma";
  },

  async handlePaymentSubmit(e) {
    e.preventDefault();
    if (!App.activeBookingForPayment) return;

    const method = document.querySelector('input[name="payment_method"]:checked')?.value || "Card";

    try {
      const res = await API.payments.process(App.activeBookingForPayment._id, method);
      showToast("Payment Successful! Booking Confirmed.", "success");
      closeModal("modal-payment");

      // Show receipt modal
      App.showReceiptModal(res.payment, res.booking);
      App.loadUserDashboard();

    } catch (err) {
      showToast(err.message, "error");
    }
  },

  showReceiptModal(payment, booking) {
    document.getElementById("receipt-ref").textContent = booking.bookingReference;
    document.getElementById("receipt-txn").textContent = payment.transactionId;
    document.getElementById("receipt-amount").textContent = `₹${payment.amount.toLocaleString("en-IN")}`;
    document.getElementById("receipt-method").textContent = payment.paymentMethod;
    document.getElementById("receipt-date").textContent = new Date().toLocaleString();

    openModal("modal-receipt");
  },

  // 6. User Dashboard (Profile & Booking History)
  async loadUserDashboard() {
    const user = API.auth.getUser();
    if (!user) {
      showToast("Please log in to view dashboard", "info");
      showSection("packages");
      return;
    }

    document.getElementById("dash-user-name").textContent = user.name;
    document.getElementById("dash-user-email").textContent = user.email;
    document.getElementById("dash-user-phone").textContent = user.phone || "Not set";
    document.getElementById("dash-user-role").textContent = user.role.toUpperCase();

    try {
      const bookings = await API.bookings.getMyBookings();
      const tbody = document.getElementById("user-bookings-table-body");
      if (!tbody) return;

      if (!bookings || bookings.length === 0) {
        tbody.innerHTML = `<tr><td colspan="7" style="text-align:center; padding:30px;">You have no bookings yet. Explore packages and start your journey!</td></tr>`;
        return;
      }

      tbody.innerHTML = bookings.map(b => `
        <tr>
          <td><strong>${b.bookingReference || b._id.substring(0, 8)}</strong></td>
          <td>
            <strong>${b.package?.name || "Package"}</strong>
            <div style="font-size:0.8rem; color:#64748b;">${b.package?.destination || ""}</div>
          </td>
          <td>${b.travelDate ? new Date(b.travelDate).toLocaleDateString() : "Flexible"}</td>
          <td>${b.numberOfPeople} person(s)</td>
          <td><strong>₹${b.totalPrice.toLocaleString("en-IN")}</strong></td>
          <td>
            <span class="badge badge-${(b.paymentStatus || 'unpaid').toLowerCase()}">
              ${b.paymentStatus || 'Unpaid'}
            </span>
          </td>
          <td>
            <span class="badge badge-${(b.status || 'pending').toLowerCase()}">
              ${b.status}
            </span>
          </td>
          <td>
            <div style="display:flex; gap:6px;">
              ${b.paymentStatus === 'Unpaid' && b.status !== 'Cancelled' ? `
                <button class="btn btn-primary btn-sm" onclick='App.openPaymentModal(${JSON.stringify(b)})'>Pay</button>
              ` : ''}
              ${b.status !== 'Cancelled' ? `
                <button class="btn btn-danger btn-sm" onclick="App.cancelBooking('${b._id}')">Cancel</button>
              ` : '<span style="color:#94a3b8; font-size:0.8rem;">Seats Restored</span>'}
            </div>
          </td>
        </tr>
      `).join("");

    } catch (err) {
      showToast(err.message, "error");
    }
  },

  async cancelBooking(bookingId) {
    if (!confirm("Are you sure you want to cancel this booking? Your reserved seats will be automatically restored to the package.")) {
      return;
    }

    try {
      await API.bookings.cancel(bookingId);
      showToast("Booking cancelled successfully and seats restored!", "success");
      await App.loadUserDashboard();
      await App.loadPackages(); // Seat count updated
    } catch (err) {
      showToast(err.message, "error");
    }
  },

  // 7. Event Listeners Setup
  setupEventListeners() {
    // Navigation Links
    document.querySelectorAll(".nav-link").forEach(link => {
      link.addEventListener("click", (e) => {
        e.preventDefault();
        const target = link.getAttribute("data-target");
        showSection(target);
      });
    });

    // Hero / Header Search
    const searchForm = document.getElementById("hero-search-form");
    if (searchForm) {
      searchForm.addEventListener("submit", (e) => {
        e.preventDefault();
        const dest = document.getElementById("search-dest").value.trim();
        const category = document.getElementById("search-category").value;
        const maxPrice = document.getElementById("search-price").value;

        showSection("packages");
        App.loadPackages({
          destination: dest || undefined,
          category: category !== "All" ? category : undefined,
          maxPrice: maxPrice || undefined
        });
      });
    }

    // Filter bar inputs
    const filterKeyword = document.getElementById("filter-keyword");
    if (filterKeyword) {
      filterKeyword.addEventListener("input", (e) => {
        const val = e.target.value.toLowerCase();
        const filtered = App.currentPackages.filter(p =>
          p.name.toLowerCase().includes(val) ||
          p.destination.toLowerCase().includes(val) ||
          p.description.toLowerCase().includes(val)
        );
        App.renderPackages(filtered);
      });
    }

    const sortSelect = document.getElementById("filter-sort");
    if (sortSelect) {
      sortSelect.addEventListener("change", (e) => {
        App.loadPackages({ sortBy: e.target.value });
      });
    }

    // Category Filter Pills
    document.querySelectorAll(".filter-pill").forEach(pill => {
      pill.addEventListener("click", () => {
        document.querySelectorAll(".filter-pill").forEach(p => p.classList.remove("active"));
        pill.classList.add("active");
        const cat = pill.getAttribute("data-cat");
        App.loadPackages(cat === "All" ? {} : { category: cat });
      });
    });

    // Booking form dynamic price triggers
    const peopleInput = document.getElementById("book-people");
    if (peopleInput) {
      peopleInput.addEventListener("input", () => App.recalculateBookingPrice());
    }
    document.querySelectorAll(".addon-checkbox").forEach(cb => {
      cb.addEventListener("change", () => App.recalculateBookingPrice());
    });

    // Forms submission handlers
    const bookingForm = document.getElementById("booking-form");
    if (bookingForm) bookingForm.addEventListener("submit", App.handleBookingSubmit);

    const paymentForm = document.getElementById("payment-form");
    if (paymentForm) paymentForm.addEventListener("submit", App.handlePaymentSubmit);

    const packageAdminForm = document.getElementById("package-form");
    if (packageAdminForm) packageAdminForm.addEventListener("submit", AdminApp.handlePackageFormSubmit);

    // Login & Register Form submissions
    const loginForm = document.getElementById("login-form");
    if (loginForm) {
      loginForm.addEventListener("submit", async (e) => {
        e.preventDefault();
        try {
          const email = document.getElementById("login-email").value.trim();
          const pass = document.getElementById("login-pass").value;
          await API.auth.login(email, pass);
          showToast("Welcome back! Login successful.", "success");
          closeModal("modal-login");
          App.updateAuthUI();
        } catch (err) {
          showToast(err.message, "error");
        }
      });
    }

    const registerForm = document.getElementById("register-form");
    if (registerForm) {
      registerForm.addEventListener("submit", async (e) => {
        e.preventDefault();
        try {
          const name = document.getElementById("reg-name").value.trim();
          const email = document.getElementById("reg-email").value.trim();
          const password = document.getElementById("reg-pass").value;
          const phone = document.getElementById("reg-phone").value.trim();

          await API.auth.register({ name, email, password, phone, role: "user" });
          showToast("Account created successfully! You are now logged in.", "success");
          closeModal("modal-register");
          App.updateAuthUI();
        } catch (err) {
          showToast(err.message, "error");
        }
      });
    }
  },

  // Auth Modal Triggers & Demo Autofills
  fillTravelerLogin() {
    document.getElementById("login-email").value = "ganesh@test.com";
    document.getElementById("login-pass").value = "123456";
  },

  fillAdminLogin() {
    document.getElementById("login-email").value = "admin@travelportal.com";
    document.getElementById("login-pass").value = "admin123";
  },

  logout() {
    API.auth.clearSession();
    App.updateAuthUI();
    showToast("Logged out successfully", "info");
    showSection("home");
  }
};

// Initialize Application when DOM is ready
document.addEventListener("DOMContentLoaded", () => {
  App.init();
});
