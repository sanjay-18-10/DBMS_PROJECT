/**
 * ============================================================================
 * TRAVEL PACKAGE BOOKING PORTAL - ADMIN DASHBOARD CONTROLLER
 * ============================================================================
 */

const AdminApp = {
  currentEditPackageId: null,

  async init() {
    const user = API.auth.getUser();
    if (!user || user.role !== "admin") {
      showToast("Access Denied: Admin authorization required", "error");
      showSection("packages");
      return;
    }

    await AdminApp.loadAnalytics();
    await AdminApp.loadPackages();
    await AdminApp.loadBookings();
    await AdminApp.loadUsers();
    await AdminApp.loadLogs();
  },

  // 1. Load Analytics via MongoDB Aggregation Pipelines
  async loadAnalytics() {
    try {
      const data = await API.admin.getAnalytics();
      const ov = data.overview || {};

      document.getElementById("stat-users").textContent = ov.totalUsers || 0;
      document.getElementById("stat-packages").textContent = `${ov.activePackages || 0} / ${ov.totalPackages || 0}`;
      document.getElementById("stat-bookings").textContent = ov.totalBookings || 0;
      document.getElementById("stat-revenue").textContent = `₹${(ov.paidRevenue || 0).toLocaleString("en-IN")}`;

      // Destination Analytics List
      const destList = document.getElementById("analytics-destinations");
      if (destList && data.destinationStats) {
        destList.innerHTML = data.destinationStats.map(d => `
          <div style="display:flex; justify-content:space-between; padding:8px 0; border-bottom:1px solid #e2e8f0;">
            <strong>${d._id}</strong>
            <span>${d.bookingsCount} booking(s) | ₹${(d.revenue || 0).toLocaleString("en-IN")}</span>
          </div>
        `).join("") || "<p class='text-muted'>No destination data yet</p>";
      }

      // Popular Packages
      const popList = document.getElementById("analytics-popular");
      if (popList && data.popularPackages) {
        popList.innerHTML = data.popularPackages.map(p => `
          <div style="display:flex; justify-content:space-between; padding:8px 0; border-bottom:1px solid #e2e8f0;">
            <div>
              <strong>${p.name}</strong>
              <div style="font-size:0.8rem; color:#64748b;">${p.destination} • ₹${p.price.toLocaleString("en-IN")}</div>
            </div>
            <span class="badge badge-confirmed">${p.totalBookings} booked</span>
          </div>
        `).join("") || "<p class='text-muted'>No booking stats yet</p>";
      }

    } catch (err) {
      console.error("Failed to load admin analytics:", err);
    }
  },

  // 2. Packages Management (CRUD & Retiring)
  async loadPackages() {
    try {
      const packages = await API.packages.getAll({ includeInactive: "true" });
      const tbody = document.getElementById("admin-packages-table-body");
      if (!tbody) return;

      tbody.innerHTML = packages.map(pkg => `
        <tr>
          <td>
            <strong>${pkg.name}</strong>
            <div style="font-size:0.8rem; color:#64748b;">${pkg.destination} • ${pkg.duration} Days</div>
          </td>
          <td><span class="badge badge-${(pkg.category || 'holiday').toLowerCase()}">${pkg.category || 'Holiday'}</span></td>
          <td><strong>₹${pkg.price.toLocaleString("en-IN")}</strong></td>
          <td>
            <span style="font-weight:700; color:${pkg.availableSeats < 5 ? '#ef4444' : '#166534'};">
              ${pkg.availableSeats}
            </span>
          </td>
          <td>
            <span class="badge ${pkg.isActive !== false ? 'badge-active' : 'badge-retired'}">
              ${pkg.isActive !== false ? 'Active' : 'Retired'}
            </span>
          </td>
          <td>
            <div style="display:flex; gap:6px;">
              <button class="btn btn-secondary btn-sm" onclick="AdminApp.openEditPackageModal('${pkg._id}')">Edit</button>
              <button class="btn btn-outline btn-sm" onclick="AdminApp.togglePackageStatus('${pkg._id}')">
                ${pkg.isActive !== false ? 'Retire' : 'Activate'}
              </button>
              <button class="btn btn-danger btn-sm" onclick="AdminApp.deletePackage('${pkg._id}')">Delete</button>
            </div>
          </td>
        </tr>
      `).join("") || "<tr><td colspan='6' style='text-align:center;'>No packages found</td></tr>";
    } catch (err) {
      showToast(err.message, "error");
    }
  },

  async togglePackageStatus(id) {
    try {
      const res = await API.packages.toggleStatus(id);
      showToast(res.message, "success");
      await AdminApp.loadPackages();
      await AdminApp.loadAnalytics();
      App.loadPackages(); // refresh user catalog as well
    } catch (err) {
      showToast(err.message, "error");
    }
  },

  async deletePackage(id) {
    if (!confirm("Are you sure you want to delete this package? Packages with active bookings cannot be deleted (referential integrity).")) {
      return;
    }
    try {
      await API.packages.delete(id);
      showToast("Package deleted successfully", "success");
      await AdminApp.loadPackages();
      await AdminApp.loadAnalytics();
      App.loadPackages();
    } catch (err) {
      showToast(err.message, "error");
    }
  },

  openCreatePackageModal() {
    AdminApp.currentEditPackageId = null;
    document.getElementById("package-modal-title").textContent = "Create New Travel Package";
    document.getElementById("package-form").reset();
    openModal("modal-package-form");
  },

  async openEditPackageModal(id) {
    try {
      const pkg = await API.packages.getById(id);
      AdminApp.currentEditPackageId = id;
      document.getElementById("package-modal-title").textContent = "Edit Travel Package";
      
      document.getElementById("pkg-name").value = pkg.name;
      document.getElementById("pkg-destination").value = pkg.destination;
      document.getElementById("pkg-category").value = pkg.category || "Holiday";
      document.getElementById("pkg-price").value = pkg.price;
      document.getElementById("pkg-duration").value = pkg.duration;
      document.getElementById("pkg-seats").value = pkg.availableSeats;
      document.getElementById("pkg-image").value = pkg.image || "";
      document.getElementById("pkg-description").value = pkg.description;

      openModal("modal-package-form");
    } catch (err) {
      showToast(err.message, "error");
    }
  },

  async handlePackageFormSubmit(e) {
    e.preventDefault();
    const data = {
      name: document.getElementById("pkg-name").value.trim(),
      destination: document.getElementById("pkg-destination").value.trim(),
      category: document.getElementById("pkg-category").value,
      price: Number(document.getElementById("pkg-price").value),
      duration: Number(document.getElementById("pkg-duration").value),
      availableSeats: Number(document.getElementById("pkg-seats").value),
      image: document.getElementById("pkg-image").value.trim() || undefined,
      description: document.getElementById("pkg-description").value.trim()
    };

    try {
      if (AdminApp.currentEditPackageId) {
        await API.packages.update(AdminApp.currentEditPackageId, data);
        showToast("Package updated successfully", "success");
      } else {
        await API.packages.create(data);
        showToast("Travel package created successfully", "success");
      }
      closeModal("modal-package-form");
      await AdminApp.loadPackages();
      await AdminApp.loadAnalytics();
      App.loadPackages();
    } catch (err) {
      showToast(err.message, "error");
    }
  },

  // 3. Bookings Management
  async loadBookings(statusFilter = "") {
    try {
      const bookings = await API.bookings.getAll(statusFilter);
      const tbody = document.getElementById("admin-bookings-table-body");
      if (!tbody) return;

      tbody.innerHTML = bookings.map(b => `
        <tr>
          <td><strong>${b.bookingReference || b._id.substring(0, 8)}</strong></td>
          <td>
            <div>${b.user?.name || "Unknown"}</div>
            <div style="font-size:0.75rem; color:#64748b;">${b.user?.email || ""}</div>
          </td>
          <td>
            <div>${b.package?.name || "Deleted Package"}</div>
            <div style="font-size:0.75rem; color:#64748b;">${b.package?.destination || ""}</div>
          </td>
          <td>${b.numberOfPeople} traveler(s)</td>
          <td><strong>₹${b.totalPrice.toLocaleString("en-IN")}</strong></td>
          <td>
            <span class="badge badge-${(b.paymentStatus || 'unpaid').toLowerCase()}">
              ${b.paymentStatus || 'Unpaid'}
            </span>
          </td>
          <td>
            <span class="badge badge-${(b.status || 'pending').toLowerCase()}">
              ${b.status}
            </span>
          </td>
        </tr>
      `).join("") || "<tr><td colspan='7' style='text-align:center;'>No bookings found</td></tr>";
    } catch (err) {
      showToast(err.message, "error");
    }
  },

  // 4. Users Management
  async loadUsers() {
    try {
      const users = await API.auth.getAllUsers();
      const tbody = document.getElementById("admin-users-table-body");
      if (!tbody) return;

      tbody.innerHTML = users.map(u => `
        <tr>
          <td><strong>${u.name}</strong></td>
          <td>${u.email}</td>
          <td>${u.phone}</td>
          <td>
            <span class="badge ${u.role === 'admin' ? 'badge-heritage' : 'badge-holiday'}">
              ${u.role}
            </span>
          </td>
          <td>${new Date(u.createdAt).toLocaleDateString()}</td>
        </tr>
      `).join("") || "<tr><td colspan='5' style='text-align:center;'>No users found</td></tr>";
    } catch (err) {
      showToast(err.message, "error");
    }
  },

  // 5. Admin Audit Logs
  async loadLogs() {
    try {
      const logs = await API.admin.getLogs();
      const tbody = document.getElementById("admin-logs-table-body");
      if (!tbody) return;

      tbody.innerHTML = logs.map(l => `
        <tr>
          <td style="font-size:0.8rem; color:#64748b;">${new Date(l.createdAt).toLocaleString()}</td>
          <td><strong>${l.action}</strong></td>
          <td>${l.targetEntity}</td>
          <td>${l.details}</td>
          <td>${l.admin?.name || "Admin"}</td>
        </tr>
      `).join("") || "<tr><td colspan='5' style='text-align:center;'>No audit logs recorded</td></tr>";
    } catch (err) {
      showToast(err.message, "error");
    }
  }
};
