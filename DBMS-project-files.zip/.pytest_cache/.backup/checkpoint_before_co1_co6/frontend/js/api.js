/**
 * ============================================================================
 * TRAVEL PACKAGE BOOKING PORTAL - CLIENT API SERVICE
 * ============================================================================
 */

const API_BASE_URL = window.location.origin.includes("localhost") || window.location.origin.includes("127.0.0.1")
  ? `${window.location.origin}/api`
  : "http://localhost:5000/api";

const API = {
  // Generic fetch wrapper with automatic JWT authorization header injection
  async request(endpoint, options = {}) {
    const headers = {
      "Content-Type": "application/json",
      ...(options.headers || {})
    };

    const token = API.auth.getToken();
    if (token) {
      headers["Authorization"] = `Bearer ${token}`;
    }

    try {
      const response = await fetch(`${API_BASE_URL}${endpoint}`, {
        ...options,
        headers
      });

      const data = await response.json().catch(() => ({}));

      if (!response.ok) {
        throw new Error(data.message || `Request failed with HTTP ${response.status}`);
      }

      return data;
    } catch (error) {
      console.error(`API Error on [${options.method || "GET"} ${endpoint}]:`, error);
      throw error;
    }
  },

  // Authentication & Session Management
  auth: {
    getToken() {
      return localStorage.getItem("travel_token");
    },
    getUser() {
      try {
        const u = localStorage.getItem("travel_user");
        return u ? JSON.parse(u) : null;
      } catch (e) {
        return null;
      }
    },
    setSession(token, user) {
      localStorage.setItem("travel_token", token);
      localStorage.setItem("travel_user", JSON.stringify(user));
    },
    clearSession() {
      localStorage.removeItem("travel_token");
      localStorage.removeItem("travel_user");
    },
    async register(data) {
      const res = await API.request("/users/register", {
        method: "POST",
        body: JSON.stringify(data)
      });
      if (res.token && res.user) {
        API.auth.setSession(res.token, res.user);
      }
      return res;
    },
    async login(email, password) {
      const res = await API.request("/users/login", {
        method: "POST",
        body: JSON.stringify({ email, password })
      });
      if (res.token && res.user) {
        API.auth.setSession(res.token, res.user);
      }
      return res;
    },
    async getProfile() {
      return API.request("/users/profile");
    },
    async updateProfile(data) {
      const res = await API.request("/users/profile", {
        method: "PUT",
        body: JSON.stringify(data)
      });
      if (res.user) {
        const current = API.auth.getUser() || {};
        API.auth.setSession(API.auth.getToken(), { ...current, ...res.user });
      }
      return res;
    },
    async getAllUsers() {
      return API.request("/users");
    }
  },

  // Travel Packages Management
  packages: {
    async getAll(params = {}) {
      const queryString = new URLSearchParams(params).toString();
      const endpoint = queryString ? `/packages?${queryString}` : "/packages";
      return API.request(endpoint);
    },
    async getById(id) {
      return API.request(`/packages/${id}`);
    },
    async create(packageData) {
      return API.request("/packages", {
        method: "POST",
        body: JSON.stringify(packageData)
      });
    },
    async update(id, packageData) {
      return API.request(`/packages/${id}`, {
        method: "PUT",
        body: JSON.stringify(packageData)
      });
    },
    async toggleStatus(id) {
      return API.request(`/packages/${id}/status`, {
        method: "PATCH"
      });
    },
    async delete(id) {
      return API.request(`/packages/${id}`, {
        method: "DELETE"
      });
    }
  },

  // Bookings & Seat Allocation
  bookings: {
    async create(bookingData) {
      return API.request("/bookings", {
        method: "POST",
        body: JSON.stringify(bookingData)
      });
    },
    async getMyBookings() {
      return API.request("/bookings/mine");
    },
    async getAll(status = "") {
      const endpoint = status ? `/bookings?status=${status}` : "/bookings";
      return API.request(endpoint);
    },
    async getById(id) {
      return API.request(`/bookings/${id}`);
    },
    async cancel(id) {
      return API.request(`/bookings/${id}/cancel`, {
        method: "PUT"
      });
    }
  },

  // Payments Gateway Simulation
  payments: {
    async process(bookingId, paymentMethod = "Card") {
      return API.request("/payments/process", {
        method: "POST",
        body: JSON.stringify({ bookingId, paymentMethod })
      });
    },
    async getAll() {
      return API.request("/payments");
    },
    async getByBooking(bookingId) {
      return API.request(`/payments/booking/${bookingId}`);
    }
  },

  // Admin Analytics & Auditing
  admin: {
    async getAnalytics() {
      return API.request("/admin/analytics");
    },
    async getLogs() {
      return API.request("/admin/logs");
    }
  }
};
