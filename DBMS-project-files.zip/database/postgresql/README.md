# Explore India – PostgreSQL Relational Database Engineering (CO1 & CO2)

Contains complete relational database assets structured for **PostgreSQL 14+ / 17**.

## Files Included
1. **`schema.sql`**: Fully normalized schema (3NF/BCNF) featuring:
   - Primary Keys, Foreign Keys (`ON DELETE RESTRICT`, `ON DELETE CASCADE`)
   - Check constraints (`price >= 0`, `rating BETWEEN 1.0 AND 5.0`)
   - B-Tree compound indexes (`(destination, price)`, `(is_active, category_id)`)
   - Views (`view_active_package_catalog`, `view_user_booking_summary`)
   - Triggers for automatic `updated_at` modification
2. **`queries.sql`**: Joins (INNER, LEFT), aggregations, `GROUP BY`, `HAVING`.
3. **`advanced_queries.sql`**:
   - Window functions: `ROW_NUMBER()`, `RANK()`, `DENSE_RANK()`, `NTILE()`, `LAG()`, `LEAD()`
   - Common Table Expressions (CTEs)
   - Recursive CTE graph traversal for tour routes
   - Multi-dimensional aggregation: `ROLLUP`
4. **`transactions.sql`**:
   - ACID Stored Procedure `sp_create_booking_atomic` with row-level pessimistic locking (`FOR UPDATE`)
   - `SAVEPOINT` and rollback examples
