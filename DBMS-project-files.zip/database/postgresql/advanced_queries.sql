-- ============================================================================
-- Explore India – Advanced SQL & Analytical Queries (CO1 & CO2)
-- Window Functions, CTEs, Recursive CTEs, Grouping Sets, Subqueries
-- ============================================================================

-- 1. WINDOW FUNCTIONS: Ranking packages within each category by price
SELECT 
    p.package_id,
    c.category_name,
    p.name,
    p.price,
    ROW_NUMBER() OVER (PARTITION BY p.category_id ORDER BY p.price DESC) AS price_row_num,
    RANK() OVER (PARTITION BY p.category_id ORDER BY p.price DESC) AS price_rank,
    DENSE_RANK() OVER (PARTITION BY p.category_id ORDER BY p.price DESC) AS price_dense_rank,
    NTILE(4) OVER (ORDER BY p.price) AS price_quartile
FROM travel_packages p
JOIN categories c ON p.category_id = c.category_id;

-- 2. WINDOW FUNCTIONS: Comparing package price with category average and prior package
SELECT 
    p.name,
    c.category_name,
    p.price,
    ROUND(AVG(p.price) OVER (PARTITION BY p.category_id), 2) AS category_avg_price,
    p.price - ROUND(AVG(p.price) OVER (PARTITION BY p.category_id), 2) AS diff_from_avg,
    LAG(p.price, 1) OVER (PARTITION BY p.category_id ORDER BY p.price) AS prior_cheaper_package_price,
    LEAD(p.price, 1) OVER (PARTITION BY p.category_id ORDER BY p.price) AS next_expensive_package_price
FROM travel_packages p
JOIN categories c ON p.category_id = c.category_id;

-- 3. COMMON TABLE EXPRESSIONS (CTE): High-Value Travelers Identification
WITH TravelerSpending AS (
    SELECT 
        u.user_id,
        u.name AS traveler_name,
        u.email,
        COUNT(b.booking_id) AS total_trips,
        SUM(b.total_price) AS lifetime_value
    FROM users u
    JOIN bookings b ON u.user_id = b.user_id
    WHERE b.booking_status = 'confirmed'
    GROUP BY u.user_id, u.name, u.email
),
ThresholdCalculation AS (
    SELECT AVG(lifetime_value) AS avg_customer_value FROM TravelerSpending
)
SELECT 
    ts.traveler_name,
    ts.email,
    ts.total_trips,
    ts.lifetime_value,
    CASE 
        WHEN ts.lifetime_value >= (SELECT avg_customer_value * 1.5 FROM ThresholdCalculation) THEN 'Platinum Explorer'
        WHEN ts.lifetime_value >= (SELECT avg_customer_value FROM ThresholdCalculation) THEN 'Gold Traveler'
        ELSE 'Silver Traveler'
    END AS traveler_tier
FROM TravelerSpending ts
ORDER BY ts.lifetime_value DESC;

-- 4. RECURSIVE CTE: Multi-Day Route Itinerary Graph Traversal
-- Generates sequence of connected destinations in an India Golden Triangle Tour
WITH RECURSIVE TourRouteGraph AS (
    -- Anchor member: Start city
    SELECT 
        1 AS stop_number,
        'Delhi'::VARCHAR(50) AS current_city,
        'Agra'::VARCHAR(50) AS next_city,
        210 AS distance_km,
        ARRAY['Delhi']::TEXT[] AS visited_path
    UNION ALL
    -- Recursive member: Traverse next stop
    SELECT 
        trg.stop_number + 1,
        trg.next_city,
        CASE 
            WHEN trg.next_city = 'Agra' THEN 'Jaipur'::VARCHAR(50)
            WHEN trg.next_city = 'Jaipur' THEN 'Delhi'::VARCHAR(50)
            ELSE NULL::VARCHAR(50)
        END,
        CASE 
            WHEN trg.next_city = 'Agra' THEN 240
            WHEN trg.next_city = 'Jaipur' THEN 280
            ELSE 0
        END,
        trg.visited_path || trg.next_city::TEXT
    FROM TourRouteGraph trg
    WHERE trg.next_city IS NOT NULL AND trg.stop_number < 3
)
SELECT 
    stop_number,
    current_city,
    next_city,
    distance_km,
    visited_path
FROM TourRouteGraph;

-- 5. ADVANCED AGGREGATION: ROLLUP and CUBE (Multidimensional Reporting)
SELECT 
    c.category_name,
    p.destination,
    COUNT(b.booking_id) AS total_bookings,
    SUM(b.total_price) AS total_revenue
FROM categories c
JOIN travel_packages p ON c.category_id = p.category_id
LEFT JOIN bookings b ON p.package_id = b.package_id
GROUP BY ROLLUP (c.category_name, p.destination);
