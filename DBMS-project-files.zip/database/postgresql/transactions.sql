-- ============================================================================
-- Explore India – PostgreSQL ACID Transactions & Stored Procedures (CO1 & CO2)
-- Concurrency Control, Row Locking (FOR UPDATE), Savepoints, Rollbacks
-- ============================================================================

-- 1. STORED PROCEDURE: Atomic Booking Creation with Pessimistic Row Locking
CREATE OR REPLACE PROCEDURE sp_create_booking_atomic(
    p_user_id INT,
    p_package_id INT,
    p_travel_date DATE,
    p_travelers_count INT,
    p_payment_method VARCHAR(50),
    INOUT p_booking_ref VARCHAR(50) DEFAULT NULL,
    INOUT p_status_message VARCHAR(100) DEFAULT NULL
)
LANGUAGE plpgsql
AS $$
DECLARE
    v_available_seats INT;
    v_base_price NUMERIC(10, 2);
    v_total_price NUMERIC(10, 2);
    v_new_booking_id INT;
BEGIN
    -- STEP 1: Lock the package row with 'FOR UPDATE' to prevent race conditions
    SELECT available_seats, price 
    INTO v_available_seats, v_base_price
    FROM travel_packages
    WHERE package_id = p_package_id AND is_active = TRUE
    FOR UPDATE;

    IF NOT FOUND THEN
        p_status_message := 'ERROR: Travel package not found or inactive';
        RETURN;
    END IF;

    -- STEP 2: Verify seat availability
    IF v_available_seats < p_travelers_count THEN
        p_status_message := 'ERROR: Insufficient seats available';
        RETURN;
    END IF;

    -- Calculate total price
    v_total_price := v_base_price * p_travelers_count;
    p_booking_ref := 'PG-BKG-' || TO_CHAR(CURRENT_TIMESTAMP, 'YYYYMMDDHH24MISS') || '-' || FLOOR(RANDOM() * 9000 + 1000)::TEXT;

    -- STEP 3: Decrement seat count atomically
    UPDATE travel_packages
    SET available_seats = available_seats - p_travelers_count
    WHERE package_id = p_package_id;

    -- STEP 4: Insert the booking record
    INSERT INTO bookings (
        booking_ref, user_id, package_id, travel_date, travelers_count,
        package_base_price, addons_total, total_price, booking_status
    )
    VALUES (
        p_booking_ref, p_user_id, p_package_id, p_travel_date, p_travelers_count,
        v_base_price, 0.00, v_total_price, 'confirmed'
    )
    RETURNING booking_id INTO v_new_booking_id;

    -- STEP 5: Create simulated payment transaction record
    INSERT INTO payments (
        booking_id, transaction_id, amount, payment_method, payment_status
    )
    VALUES (
        v_new_booking_id,
        'TXN-PG-' || MD5(RANDOM()::TEXT || CLOCK_TIMESTAMP()::TEXT),
        v_total_price,
        p_payment_method,
        'completed'
    );

    p_status_message := 'SUCCESS: Booking and payment confirmed';
END;
$$;

-- 2. TRANSACTION WITH SAVEPOINTS AND EXPLICIT ROLLBACK DEMO
DO $$
DECLARE
    v_pkg_id INT := 1;
BEGIN
    -- Begin transaction
    RAISE NOTICE 'Starting Transaction Demo with SAVEPOINTS...';

    -- Savepoint 1
    SAVEPOINT sp_initial_check;

    -- Attempt seat deduction
    UPDATE travel_packages
    SET available_seats = available_seats - 1
    WHERE package_id = v_pkg_id;

    -- Check if seats dropped below zero
    IF (SELECT available_seats FROM travel_packages WHERE package_id = v_pkg_id) < 0 THEN
        RAISE NOTICE 'Inventory depleted. Rolling back to Savepoint sp_initial_check!';
        ROLLBACK TO SAVEPOINT sp_initial_check;
    ELSE
        RAISE NOTICE 'Seat reserved successfully. Committing transaction.';
    END IF;
END;
$$;
