-- ============================================================================
-- Explore India – PostgreSQL Basic & Intermediate DML Queries (CO1)
-- ============================================================================

-- 1. Insert seed data
INSERT INTO categories (category_name, description) VALUES
('Nature', 'Lush landscapes, hills, and waterways'),
('Heritage', 'Historic forts, palaces, and UNESCO monuments'),
('Beach', 'Coastal retreats, watersports, and relaxation'),
('Spiritual', 'Sacred temples, pilgrimages, and ghats');

INSERT INTO travel_packages (category_id, name, destination, description, price, duration_days, available_seats, rating) VALUES
(1, 'Kerala Backwaters Luxury Cruise', 'Kerala', 'Houseboat experience in Alleppey and spice hills of Thekkady', 15999.00, 5, 20, 4.8),
(2, 'Royal Rajasthan Heritage Circuit', 'Rajasthan', 'Jaipur Amer Fort, Udaipur Pichola Lake, Jodhpur Mehrangarh', 24999.00, 7, 15, 4.9),
(3, 'Goa Golden Sands & Coastal Getaway', 'Goa', 'Calangute, Baga beach watersports and Old Goa churches', 12499.00, 4, 25, 4.7),
(4, 'Varanasi & Sarnath Spiritual Trail', 'Uttar Pradesh', 'Ganga Aarti, Kashi Vishwanath temple, and Buddhist monuments', 10999.00, 3, 30, 4.6);

-- 2. Inner Join: Packages with their Category details
SELECT 
    p.name AS package_name,
    c.category_name,
    p.destination,
    p.price,
    p.available_seats
FROM travel_packages p
INNER JOIN categories c ON p.category_id = c.category_id
WHERE p.is_active = TRUE
ORDER BY p.price ASC;

-- 3. Left Join: Find all packages and any associated bookings (even if unbooked)
SELECT 
    p.package_id,
    p.name,
    COUNT(b.booking_id) AS total_bookings_placed,
    COALESCE(SUM(b.total_price), 0.00) AS total_revenue_generated
FROM travel_packages p
LEFT JOIN bookings b ON p.package_id = b.package_id AND b.booking_status = 'confirmed'
GROUP BY p.package_id, p.name
ORDER BY total_revenue_generated DESC;

-- 4. Aggregate queries: Average package price by category
SELECT 
    c.category_name,
    COUNT(p.package_id) AS package_count,
    ROUND(AVG(p.price), 2) AS average_price,
    MIN(p.price) AS lowest_price,
    MAX(p.price) AS highest_price
FROM categories c
JOIN travel_packages p ON c.category_id = p.category_id
GROUP BY c.category_name
HAVING COUNT(p.package_id) > 0;
