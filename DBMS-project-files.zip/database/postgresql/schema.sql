-- ============================================================================
-- Explore India – PostgreSQL Relational Database Schema (CO1 Demonstration)
-- Normalized to 3NF / BCNF
-- Compatible with PostgreSQL 14+ / 17
-- ============================================================================

-- Drop existing tables if re-running
DROP TABLE IF EXISTS audit_logs CASCADE;
DROP TABLE IF EXISTS payments CASCADE;
DROP TABLE IF EXISTS booking_addons CASCADE;
DROP TABLE IF EXISTS package_addons CASCADE;
DROP TABLE IF EXISTS package_reviews CASCADE;
DROP TABLE IF EXISTS bookings CASCADE;
DROP TABLE IF EXISTS package_itineraries CASCADE;
DROP TABLE IF EXISTS travel_packages CASCADE;
DROP TABLE IF EXISTS categories CASCADE;
DROP TABLE IF EXISTS users CASCADE;

-- 1. USERS TABLE
CREATE TABLE users (
    user_id SERIAL PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(150) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    phone VARCHAR(20) NOT NULL,
    role VARCHAR(20) DEFAULT 'user' CHECK (role IN ('user', 'admin')),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Index for authentication lookup
CREATE INDEX idx_users_email ON users(email);

-- 2. CATEGORIES TABLE
CREATE TABLE categories (
    category_id SERIAL PRIMARY KEY,
    category_name VARCHAR(50) NOT NULL UNIQUE,
    description TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- 3. TRAVEL PACKAGES TABLE
CREATE TABLE travel_packages (
    package_id SERIAL PRIMARY KEY,
    category_id INT REFERENCES categories(category_id) ON DELETE SET NULL,
    name VARCHAR(200) NOT NULL,
    destination VARCHAR(100) NOT NULL,
    description TEXT NOT NULL,
    price NUMERIC(10, 2) NOT NULL CHECK (price >= 0),
    duration_days INT NOT NULL CHECK (duration_days > 0),
    available_seats INT NOT NULL DEFAULT 20 CHECK (available_seats >= 0),
    featured BOOLEAN DEFAULT FALSE,
    is_active BOOLEAN DEFAULT TRUE,
    rating NUMERIC(2, 1) DEFAULT 4.5 CHECK (rating BETWEEN 1.0 AND 5.0),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Compound index for catalog searching & filtering
CREATE INDEX idx_packages_dest_price ON travel_packages(destination, price);
CREATE INDEX idx_packages_active_category ON travel_packages(is_active, category_id);

-- 4. PACKAGE ITINERARY (1-to-Many normalized relationship)
CREATE TABLE package_itineraries (
    itinerary_id SERIAL PRIMARY KEY,
    package_id INT NOT NULL REFERENCES travel_packages(package_id) ON DELETE CASCADE,
    day_number INT NOT NULL CHECK (day_number > 0),
    title VARCHAR(150) NOT NULL,
    activities TEXT NOT NULL,
    meals_included VARCHAR(50) DEFAULT 'Breakfast',
    CONSTRAINT unq_package_day UNIQUE (package_id, day_number)
);

-- 5. PACKAGE ADD-ONS (Optional items like insurance, airport pickup)
CREATE TABLE package_addons (
    addon_id SERIAL PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    price NUMERIC(8, 2) NOT NULL CHECK (price >= 0),
    description VARCHAR(255)
);

-- 6. BOOKINGS TABLE
CREATE TABLE bookings (
    booking_id SERIAL PRIMARY KEY,
    booking_ref VARCHAR(50) NOT NULL UNIQUE,
    user_id INT NOT NULL REFERENCES users(user_id) ON DELETE RESTRICT,
    package_id INT NOT NULL REFERENCES travel_packages(package_id) ON DELETE RESTRICT,
    travel_date DATE NOT NULL CHECK (travel_date >= CURRENT_DATE),
    travelers_count INT NOT NULL CHECK (travelers_count > 0),
    package_base_price NUMERIC(10, 2) NOT NULL,
    addons_total NUMERIC(10, 2) DEFAULT 0.00,
    total_price NUMERIC(10, 2) NOT NULL CHECK (total_price >= 0),
    booking_status VARCHAR(20) DEFAULT 'confirmed' CHECK (booking_status IN ('confirmed', 'cancelled', 'completed')),
    special_requests TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_bookings_user ON bookings(user_id);
CREATE INDEX idx_bookings_status ON bookings(booking_status);

-- 7. BOOKING ADDONS (Many-to-Many associative table)
CREATE TABLE booking_addons (
    booking_id INT NOT NULL REFERENCES bookings(booking_id) ON DELETE CASCADE,
    addon_id INT NOT NULL REFERENCES package_addons(addon_id) ON DELETE RESTRICT,
    price NUMERIC(8, 2) NOT NULL,
    PRIMARY KEY (booking_id, addon_id)
);

-- 8. PAYMENTS TABLE
CREATE TABLE payments (
    payment_id SERIAL PRIMARY KEY,
    booking_id INT NOT NULL REFERENCES bookings(booking_id) ON DELETE RESTRICT,
    transaction_id VARCHAR(100) NOT NULL UNIQUE,
    amount NUMERIC(10, 2) NOT NULL CHECK (amount > 0),
    payment_method VARCHAR(50) NOT NULL CHECK (payment_method IN ('upi', 'card', 'netbanking', 'wallet')),
    payment_status VARCHAR(20) DEFAULT 'completed' CHECK (payment_status IN ('pending', 'completed', 'refunded', 'failed')),
    gateway_response JSONB,
    paid_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- 9. AUDIT LOGS TABLE
CREATE TABLE audit_logs (
    log_id SERIAL PRIMARY KEY,
    action_type VARCHAR(50) NOT NULL,
    table_affected VARCHAR(50) NOT NULL,
    record_id INT,
    performed_by INT REFERENCES users(user_id) ON DELETE SET NULL,
    changes_json JSONB,
    performed_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- ============================================================================
-- VIEWS (CO1 Topic: Database Views & Materialized Views)
-- ============================================================================

-- View: Active Packages with Category Name and Itinerary Day Count
CREATE OR REPLACE VIEW view_active_package_catalog AS
SELECT 
    p.package_id,
    p.name AS package_name,
    p.destination,
    c.category_name,
    p.price,
    p.duration_days,
    p.available_seats,
    p.rating,
    COUNT(i.itinerary_id) AS total_itinerary_stops
FROM travel_packages p
LEFT JOIN categories c ON p.category_id = c.category_id
LEFT JOIN package_itineraries i ON p.package_id = i.package_id
WHERE p.is_active = TRUE
GROUP BY p.package_id, p.name, p.destination, c.category_name, p.price, p.duration_days, p.available_seats, p.rating;

-- View: User Booking Summary
CREATE OR REPLACE VIEW view_user_booking_summary AS
SELECT 
    b.booking_ref,
    u.name AS traveler_name,
    u.email AS traveler_email,
    p.name AS package_name,
    p.destination,
    b.travel_date,
    b.travelers_count,
    b.total_price,
    b.booking_status,
    pay.payment_status,
    pay.transaction_id
FROM bookings b
JOIN users u ON b.user_id = u.user_id
JOIN travel_packages p ON b.package_id = p.package_id
LEFT JOIN payments pay ON b.booking_id = pay.booking_id;

-- ============================================================================
-- TRIGGERS & PROCEDURES (CO1 Topic: Automated Consistency Rules)
-- ============================================================================

-- Trigger: Automatically update 'updated_at' column
CREATE OR REPLACE FUNCTION trigger_set_timestamp()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER set_timestamp_users
BEFORE UPDATE ON users
FOR EACH ROW EXECUTE FUNCTION trigger_set_timestamp();

CREATE TRIGGER set_timestamp_packages
BEFORE UPDATE ON travel_packages
FOR EACH ROW EXECUTE FUNCTION trigger_set_timestamp();

CREATE TRIGGER set_timestamp_bookings
BEFORE UPDATE ON bookings
FOR EACH ROW EXECUTE FUNCTION trigger_set_timestamp();
