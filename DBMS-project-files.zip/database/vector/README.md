# Explore India – Vector Search & Embeddings Demo (CO2)

Demonstrates **CO2: Next-Generation Database Engineering** concepts using vector embeddings and cosine similarity.

## Core Concepts
- **Dense Vector Representation**: Unstructured natural language descriptions are projected into high-dimensional geometric embedding vectors.
- **Cosine Similarity Metric**:
  $$\text{similarity}(u, v) = \frac{u \cdot v}{\|u\| \|v\|}$$
- **Semantic Retrieval**: Overcomes traditional keyword/lexical search limitations (e.g., matching "peaceful boat ride" to "houseboat backwaters" even when exact query terms differ).
- **RAG & Hybrid Search**: Vector similarity combined with SQL/NoSQL attribute filtering (price, destination, rating).

## Running the Demo
```powershell
cd database\vector
python vector_search_demo.py
```
