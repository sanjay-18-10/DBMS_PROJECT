"""
Explore India - Vector Database & Semantic Search Demonstration (CO2)
=====================================================================
Demonstrates vector embeddings, cosine distance / similarity search,
and RAG/hybrid search concepts for travel packages without requiring paid external APIs.

Run with: python vector_search_demo.py
"""
import math
import re
from typing import List, Dict, Tuple

# Pre-defined vocabulary dimensions for deterministic TF-IDF / Bag-of-Concepts embedding
DIMENSIONS = [
    "beach", "ocean", "sand", "watersports", "sun",
    "mountain", "snow", "himalayan", "adventure", "altitude",
    "heritage", "fort", "palace", "history", "culture",
    "backwaters", "houseboat", "nature", "canal", "ayurveda",
    "spiritual", "temple", "pilgrimage", "aarti", "sacred"
]

PACKAGES_CORPUS = [
    {
        "id": 1,
        "name": "Kerala Backwaters & Houseboat Sanctuary",
        "destination": "Kerala",
        "description": "Cruising serene emerald backwaters, lagoons, and palm canals in an authentic luxury houseboat with ayurvedic therapies."
    },
    {
        "id": 2,
        "name": "Royal Rajasthan Forts & Heritage Trail",
        "destination": "Rajasthan",
        "description": "Grand historic palaces, desert sand dunes, ancient Rajput hill forts, rich royal cultural history and music."
    },
    {
        "id": 3,
        "name": "Goa Coastal Sands & Watersports Fiesta",
        "destination": "Goa",
        "description": "Sunny tropical beaches, golden ocean sands, exciting scuba diving watersports, beach shacks, and coastal nightlife."
    },
    {
        "id": 4,
        "name": "Himachal Snow Summit & Mountain Expedition",
        "destination": "Himachal Pradesh",
        "description": "Snow clad high altitude Himalayan mountain peaks, thrilling adventure sports, pine valleys, and winter skiing."
    },
    {
        "id": 5,
        "name": "Varanasi Ghats & Sacred Spiritual Odyssey",
        "destination": "Uttar Pradesh",
        "description": "Evening Ganga Aarti rituals, ancient Kashi temple pilgrimage, holy river ghats, and profound spiritual enlightenment."
    }
]

def vectorize_text(text: str) -> List[float]:
    """Generates a normalized semantic embedding vector using domain concept density."""
    words = re.findall(r'\b\w+\b', text.lower())
    vec = [0.0] * len(DIMENSIONS)
    
    # Vocabulary weights & semantic synonyms
    for idx, dim in enumerate(DIMENSIONS):
        count = words.count(dim)
        # Apply semantic synonym expansion
        if dim == "ocean" and any(w in words for w in ["sea", "waves", "water"]): count += 1
        if dim == "beach" and any(w in words for w in ["coastal", "coast", "shore"]): count += 1
        if dim == "snow" and any(w in words for w in ["skiing", "cold", "snowy"]): count += 1
        if dim == "temple" and any(w in words for w in ["rituals", "holy", "ghats", "sacred"]): count += 1
        if dim == "houseboat" and any(w in words for w in ["cruising", "boat", "cruise"]): count += 1
        if dim == "canal" and any(w in words for w in ["canals", "waterways", "water"]): count += 1
        if dim == "heritage" and any(w in words for w in ["monuments", "ancient", "castles", "kings"]): count += 1
        if dim == "sand" and "desert" in words: count += 1
        if dim == "mountain" and any(w in words for w in ["hills", "peaks", "summit"]): count += 1
        vec[idx] = float(count)
    
    # Compute Euclidean norm (L2 normalization)
    magnitude = math.sqrt(sum(v * v for v in vec))
    if magnitude > 0:
        vec = [v / magnitude for v in vec]
    return vec

def cosine_similarity(v1: List[float], v2: List[float]) -> float:
    """Computes cosine similarity between two normalized vectors (-1.0 to 1.0)."""
    return sum(a * b for a, b in zip(v1, v2))

class VectorIndex:
    def __init__(self):
        self.documents = []
        self.vectors = []

    def add_document(self, doc: Dict):
        full_text = f"{doc['name']} {doc['destination']} {doc['description']}"
        vector = vectorize_text(full_text)
        self.documents.append(doc)
        self.vectors.append(vector)

    def similarity_search(self, query: str, top_k: int = 3) -> List[Tuple[Dict, float]]:
        query_vec = vectorize_text(query)
        scores = []
        for doc, doc_vec in zip(self.documents, self.vectors):
            score = cosine_similarity(query_vec, doc_vec)
            scores.append((doc, score))
        
        # Sort descending by cosine similarity score
        scores.sort(key=lambda x: x[1], reverse=True)
        return scores[:top_k]

def run_demo():
    print("=================================================================")
    print("[AI/Vector] Explore India - Vector Database Semantic Search Demo (CO2)")
    print("=================================================================")
    
    index = VectorIndex()
    for pkg in PACKAGES_CORPUS:
        index.add_document(pkg)
    
    print(f"Indexed {len(PACKAGES_CORPUS)} travel packages into {len(DIMENSIONS)}-dimensional vector space.\n")

    test_queries = [
        "I want a peaceful boat ride through green canals and water",
        "Looking for high cold snowy hills and skiing adventure",
        "Ancient castles, kings, and desert historical monuments",
        "Warm sunny sea waves with thrilling scuba diving"
    ]

    for q in test_queries:
        print(f"\n[Query]: \"{q}\"")
        results = index.similarity_search(q, top_k=2)
        for rank, (doc, score) in enumerate(results, 1):
            bar = "=" * int(score * 20)
            print(f"   #{rank} [{score:.4f}] {bar:<20} -> {doc['name']} ({doc['destination']})")

if __name__ == "__main__":
    run_demo()
