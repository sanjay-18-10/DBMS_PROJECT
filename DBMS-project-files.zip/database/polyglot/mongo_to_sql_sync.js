/**
 * Explore India - Polyglot Persistence Sync Demonstration (CO1 & CO2)
 * ===================================================================
 * Demonstrates how document data from MongoDB is mapped, transformed,
 * and synchronized to Relational (SQL) structures for analytical queries.
 *
 * Pattern: Outbox / Eventual Consistency Sync Bridge
 * Run with: node mongo_to_sql_sync.js
 */
let mongoose;
try {
  mongoose = require('mongoose');
} catch (e) {
  mongoose = require('../../backend/node_modules/mongoose');
}

const MONGO_URI = process.env.MONGO_URI || 'mongodb://localhost:27017/travel_booking';

async function runSyncSimulation() {
  console.log('===============================================================');
  console.log('🐘 🍃 Explore India - Polyglot Persistence Synchronization Demo');
  console.log('===============================================================');

  try {
    await mongoose.connect(MONGO_URI);
    console.log('✅ Connected to MongoDB source database');

    const packagesCol = mongoose.connection.db.collection('packages');
    const bookingsCol = mongoose.connection.db.collection('bookings');

    const packages = await packagesCol.find({}).toArray();
    const bookings = await bookingsCol.find({}).toArray();

    console.log(`\n📥 Read from MongoDB: ${packages.length} Packages, ${bookings.length} Bookings`);

    // Transform Document Schema -> Relational Tuples (3NF)
    console.log('\n🔄 Transforming Document Model -> Relational Tables:');

    const relationalPackages = packages.map((pkg, idx) => ({
      sql_table: 'travel_packages',
      package_id: idx + 1,
      mongo_source_id: pkg._id.toString(),
      name: pkg.name,
      destination: pkg.destination,
      price: pkg.price,
      duration_days: pkg.duration,
      available_seats: pkg.availableSeats,
      category: pkg.category || 'General',
    }));

    console.log(`\n--- [Table: travel_packages] Sample Relational Records ---`);
    console.table(relationalPackages.slice(0, 3), ['package_id', 'name', 'destination', 'price', 'category']);

    const relationalBookings = bookings.map((bkg, idx) => ({
      sql_table: 'bookings',
      booking_id: idx + 1,
      booking_ref: bkg.bookingReference || `BKG-SYNC-${idx + 1}`,
      package_id: bkg.package ? bkg.package.toString() : 'N/A',
      travelers_count: bkg.travelersCount || bkg.travelers || 1,
      total_price: bkg.totalPrice,
      status: bkg.bookingStatus || bkg.status || 'confirmed',
      payment_status: bkg.paymentStatus || 'completed',
    }));

    console.log(`\n--- [Table: bookings] Sample Relational Records ---`);
    if (relationalBookings.length > 0) {
      console.table(relationalBookings, ['booking_id', 'booking_ref', 'total_price', 'status', 'payment_status']);
    } else {
      console.log('No bookings to display currently.');
    }

    console.log('\n✅ Polyglot Synchronization Schema validated successfully.');
    console.log('💡 In production architecture, this pipeline operates via Change Data Capture (CDC) or RabbitMQ/Kafka topics.');

  } catch (err) {
    console.error('❌ Error during polyglot sync demo:', err.message);
  } finally {
    await mongoose.disconnect();
    console.log('\n🔒 Disconnected from MongoDB. Demo completed cleanly.');
  }
}

if (require.main === module) {
  runSyncSimulation();
}

module.exports = { runSyncSimulation };
