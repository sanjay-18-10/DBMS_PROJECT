# Explore India – Academic Project Guide Demonstration Walkthrough

Follow this step-by-step checklist during your academic DBMS & Full-Stack project review.

---

## Step 1: Show the Live Frontend & Core Backend
1. Open your browser and navigate to:
   **`http://localhost:5000`**
2. Show the **"Explore India"** brand name and responsive navigation.
3. Browse the travel packages catalog (loaded dynamically from MongoDB).
4. Demonstrate filtering by destination, price slider, and category tabs.
5. Log in with traveler credentials:
   - **Email**: `ganesh@test.com`
   - **Password**: `123456`
6. Book a package (e.g. Kerala or Goa), select dates, and proceed to the simulated checkout modal.
7. Show that upon booking confirmation:
   - Available seats are atomically reduced.
   - A unique booking reference (`PKG-xxxx-xxxx`) and transaction ID are generated.
   - The booking appears under the traveler's **"My Bookings"** dashboard.
8. Log out and log in with Admin credentials:
   - **Email**: `admin@travelportal.com`
   - **Password**: `admin123`
9. Open the **Admin Analytics Console** to demonstrate multi-stage MongoDB aggregation pipelines (`$group`, `$sort`, `$lookup`) computing total revenue and popular destinations.

---

## Step 2: Show MongoDB Collections & Schema Integrity
1. Open MongoDB Compass or run the query check:
   - Database: `travel_booking`
   - Collections: `users`, `packages`, `bookings`, `payments`, `adminlogs`
2. Point out indexes:
   - Compound index on `packages`: `{ destination: 1, price: 1 }`
   - Unique constraints on `User.email` and `Payment.transactionId`

---

## Step 3: Demonstrate CO1 Relational Database Engineering
1. Open `database/postgresql/schema.sql`:
   - Point out 3NF normalization, foreign keys (`ON DELETE RESTRICT`), and check constraints.
   - Show SQL Views (`view_active_package_catalog`, `view_user_booking_summary`).
2. Open `database/postgresql/advanced_queries.sql`:
   - Show Window Functions (`ROW_NUMBER()`, `RANK()`, `LAG()`, `LEAD()`).
   - Show Recursive CTE traversing multi-city itineraries.
3. Open `database/postgresql/transactions.sql`:
   - Explain the stored procedure `sp_create_booking_atomic` with row-level pessimistic locking (`SELECT ... FOR UPDATE`).
4. Run the Polyglot Sync demonstration in terminal:
   ```powershell
   node database/polyglot/mongo_to_sql_sync.js
   ```

---

## Step 4: Demonstrate CO2 Vector Search & AI Database Concept
1. Open `database/vector/vector_search_demo.py`.
2. Run the semantic search demo in terminal:
   ```powershell
   python database/vector/vector_search_demo.py
   ```
3. Show your guide how natural language queries (e.g., *"peaceful boat ride in water"*) compute cosine similarity against high-dimensional vectors to retrieve the Kerala Houseboat package.

---

## Step 5: Demonstrate CO3 FastAPI API Gateway & OpenAPI
1. Start the FastAPI gateway in a separate terminal:
   ```powershell
   cd fastapi-gateway
   uvicorn main:app --reload --port 8000
   ```
2. Open **`http://localhost:8000/docs`** to show the interactive Swagger UI.
3. Show the automated pytest test suite (7/7 passed):
   ```powershell
   python -m pytest test_gateway.py -v
   ```

---

## Step 6: Demonstrate CO4 Multi-Framework Backend Engineering
1. Open `framework-demos/FRAMEWORK_COMPARISON.md` to explain the comparative architecture matrix.
2. Run the Flask test suite:
   ```powershell
   cd framework-demos/flask-demo
   python -m pytest test_flask.py -v
   ```
3. Run the Django REST Framework test suite:
   ```powershell
   cd framework-demos/django-demo
   python manage.py test
   ```

---

## Step 7: Demonstrate CO5 Microservices & Saga Pattern
1. Show the microservices topology in `microservices/README.md`.
2. Demonstrate the **Distributed Saga Orchestrator & Compensating Transactions**:
   ```powershell
   cd microservices/saga-demo
   node saga_orchestrator.js
   ```
3. Highlight:
   - Case 1: All distributed steps succeed.
   - Case 2: Payment fails, orchestrator triggers reverse compensation to release inventory and restore consistency.

---

## Step 8: Demonstrate CO6 Deployment, Kubernetes & Observability
1. Show `docker-compose.yml` orchestrating all containers.
2. Show the Kubernetes manifests in `k8s/` (`00-namespace.yaml` through `05-ingress.yaml`).
3. Show the Prometheus metrics endpoint live on the backend:
   **`http://localhost:5000/api/metrics`**
4. Show the GitHub Actions CI pipeline configuration in `.github/workflows/ci.yml`.
