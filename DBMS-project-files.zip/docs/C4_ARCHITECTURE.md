# Explore India – C4 Architecture Models

This document presents the software architecture of the **Explore India – Travel Package Booking Portal** using the **C4 Model** (Context, Container, Component, Deployment).

---

## Level 1: System Context Diagram

Visualizes how human actors and external systems interact with the Explore India platform.

```mermaid
flowchart TD
    Traveler["Traveler (Web User)"]
    Admin["Admin (Operations Manager)"]
    
    subgraph ExploreIndiaSystem["Explore India Travel Portal"]
        SystemCore["Explore India Core Platform\n(Catalog, Booking, RBAC, Analytics)"]
    end
    
    PaymentGateway["Simulated Payment Gateway\n(Captures & Refunds)"]
    Observability["Prometheus & Monitoring\n(Telemetry Scraping)"]
    
    Traveler -->|"Searches packages, books trips, simulates payment"| SystemCore
    Admin -->|"Manages packages, views aggregation metrics, monitors logs"| SystemCore
    SystemCore -->|"Simulates card/UPI transactions"| PaymentGateway
    Observability -->|"Scrapes /api/metrics & /health"| SystemCore
```

---

## Level 2: Container Diagram

Describes the high-level technical building blocks, microservices, and databases.

```mermaid
flowchart TD
    Client["Browser / Single Page Application\n(HTML5, CSS3, Vanilla JS)"]
    
    Gateway["FastAPI API Gateway :8000\n(Python, Pydantic, Rate Limiter, OpenAPI)"]
    
    NodeBackend["Core Express Backend :5000\n(Node.js, Express, Mongoose, JWT)"]
    
    UserService["User Microservice :3001\n(Node.js, Express, Auth)"]
    ActivityService["Activity Microservice :3002\n(Node.js, Event Sourcing)"]
    FlaskService["Flask Catalog Demo :5001\n(Python, Flask, In-Memory)"]
    DjangoService["Django Relational Service :8001\n(Python, Django REST, SQLite)"]
    
    MongoDB[("MongoDB :27017\ntravel_booking database")]
    PostgreSQL[("PostgreSQL / Relational\n3NF Normalized Schema")]
    
    Client -->|"HTTP / REST"| NodeBackend
    Client -.->|"Alternative Gateway Access"| Gateway
    Gateway -->|"Async HTTP Forwarding"| NodeBackend
    
    NodeBackend -->|"Read / Write Operations"| MongoDB
    UserService -->|"User Partition"| MongoDB
    ActivityService -->|"Events Partition"| MongoDB
    DjangoService -->|"ORM Relational Models"| PostgreSQL
```

---

## Level 3: Component Diagram (Core Node.js Backend)

Decomposes the internal architectural components of the primary Node.js backend.

```mermaid
flowchart LR
    subgraph RoutingLayer["Routing Layer"]
        UserRouter["userRoutes.js"]
        PkgRouter["packageRoutes.js"]
        BkgRouter["bookingRoutes.js"]
        PayRouter["paymentRoutes.js"]
        AdminRouter["adminRoutes.js"]
    end

    subgraph MiddlewareLayer["Middleware Layer"]
        AuthMid["authMiddleware.js\n(JWT & RBAC)"]
        ErrorMid["errorMiddleware.js\n(Centralized Error Handler)"]
    end

    subgraph ControllerLayer["Controllers (Business Logic)"]
        UserCtrl["userController.js"]
        PkgCtrl["packageController.js"]
        BkgCtrl["bookingController.js\n(Atomic seat decrement)"]
        PayCtrl["paymentController.js"]
        AdminCtrl["adminController.js\n(MongoDB Aggregation Pipeline)"]
    end

    subgraph ModelLayer["Mongoose Domain Models"]
        UserModel["User.js"]
        PkgModel["Package.js"]
        BkgModel["Booking.js"]
        PayModel["Payment.js"]
        LogModel["AdminLog.js"]
    end

    RoutingLayer --> MiddlewareLayer
    MiddlewareLayer --> ControllerLayer
    ControllerLayer --> ModelLayer
```

---

## Level 4: Deployment Diagram (Kubernetes / Docker)

Illustrates how services are deployed into containers and managed.

```mermaid
flowchart TD
    subgraph K8sCluster["Kubernetes Cluster (Namespace: explore-india)"]
        Ingress["L7 Ingress Controller"]
        
        subgraph Pods["Replicated Pods"]
            BackendPod1["express-backend Pod 1"]
            BackendPod2["express-backend Pod 2"]
            GatewayPod["fastapi-gateway Pod"]
            MongoPod["mongodb-deployment Pod"]
        end
        
        ConfigMap["ConfigMap & Secrets"]
    end

    Ingress -->|"/"| BackendPod1
    Ingress -->|"/"| BackendPod2
    Ingress -->|"/api/gateway"| GatewayPod
    BackendPod1 --> MongoPod
    BackendPod2 --> MongoPod
    ConfigMap -.-> Pods
```
