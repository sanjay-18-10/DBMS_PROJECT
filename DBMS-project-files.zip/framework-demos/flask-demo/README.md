# Explore India – Flask Framework Demo (CO4)

This service demonstrates **CO4: Multi-Framework Backend Engineering** using Python Flask 3.x.

## Key Features
- **Lightweight WSGI Micro-framework**: Minimal footprint, ideal for small microservices or utility endpoints.
- **RESTful Endpoints**: Full CRUD operations for packages, bookings, search, and booking analytics.
- **In-Memory Concurrency Demonstration**: Contrasted with Node.js event-loop and FastAPI asynchronous coroutines.
- **Unit Testing**: Pytest suite for API verification.

## Running the Flask Demo
```powershell
cd framework-demos\flask-demo
python app.py
```
Server runs on: `http://localhost:5001`

## Running Tests
```powershell
python -m pytest test_flask.py -v
```
