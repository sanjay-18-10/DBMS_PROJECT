"""
Flask Demo Tests (CO4)
Run with: python -m pytest test_flask.py -v
"""
import pytest
import json
from app import app

@pytest.fixture
def client():
    app.config["TESTING"] = True
    with app.test_client() as c:
        yield c

def test_flask_root(client):
    r = client.get("/")
    assert r.status_code == 200
    data = json.loads(r.data)
    assert data["success"] is True
    assert "Explore India" in data["data"]["app"]

def test_flask_health(client):
    r = client.get("/health")
    assert r.status_code == 200
    assert json.loads(r.data)["data"]["status"] == "healthy"

def test_flask_packages_list(client):
    r = client.get("/api/packages")
    assert r.status_code == 200
    data = json.loads(r.data)["data"]
    assert data["count"] == 5

def test_flask_filter_category(client):
    r = client.get("/api/packages?category=beach")
    data = json.loads(r.data)["data"]
    assert len(data["packages"]) >= 1
    for p in data["packages"]:
        assert p["category"] == "beach"

def test_flask_search(client):
    r = client.get("/api/packages/search?q=kerala")
    data = json.loads(r.data)["data"]
    assert data["count"] >= 1

def test_flask_booking(client):
    r = client.post("/api/bookings",
        json={"packageId": 1, "travelers": 2, "name": "Rahul Verma"},
        content_type="application/json"
    )
    assert r.status_code == 201
    data = json.loads(r.data)["data"]
    assert data["travelers"] == 2
    assert "FLK-" in data["bookingRef"]

def test_flask_stats(client):
    r = client.get("/api/stats")
    assert r.status_code == 200
    data = json.loads(r.data)["data"]
    assert data["total_bookings"] >= 1
