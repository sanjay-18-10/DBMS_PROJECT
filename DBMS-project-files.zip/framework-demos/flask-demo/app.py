"""
Explore India - Flask Demo (CO4: Multi-Framework Backend Engineering)
=====================================================================
This is a self-contained Flask application demonstrating CO4 concepts.
It runs independently on port 5001.

Run:
  cd framework-demos/flask-demo
  python app.py

Access at: http://localhost:5001
"""

from flask import Flask, jsonify, request
from flask_cors import CORS
import datetime
import time

app = Flask(__name__)
CORS(app)

# In-Memory Demo Data
DEMO_PACKAGES = [
    {"id": 1, "name": "Kerala Backwaters", "destination": "Kerala", "price": 15999,
     "duration": 5, "category": "nature", "seats": 20, "rating": 4.8},
    {"id": 2, "name": "Rajasthan Royal Tour", "destination": "Rajasthan", "price": 22999,
     "duration": 7, "category": "heritage", "seats": 15, "rating": 4.9},
    {"id": 3, "name": "Goa Beach Holiday", "destination": "Goa", "price": 12999,
     "duration": 4, "category": "beach", "seats": 30, "rating": 4.7},
    {"id": 4, "name": "Himachal Snow Expedition", "destination": "Himachal Pradesh", "price": 18999,
     "duration": 6, "category": "adventure", "seats": 25, "rating": 4.6},
    {"id": 5, "name": "Varanasi Spiritual Tour", "destination": "Uttar Pradesh", "price": 10999,
     "duration": 3, "category": "spiritual", "seats": 40, "rating": 4.5},
]

DEMO_BOOKINGS = []
_next_booking_id = 1

def success(data, status=200):
    return jsonify({"success": True, "data": data}), status

def error(msg, status=400):
    return jsonify({"success": False, "error": msg}), status

def find_package(pkg_id):
    return next((p for p in DEMO_PACKAGES if p["id"] == pkg_id), None)

@app.route("/", methods=["GET"])
def index():
    return success({
        "app": "Explore India – Flask Demo",
        "framework": "Flask 3.x",
        "purpose": "CO4 Multi-Framework Backend Engineering demonstration",
        "port": 5001,
        "endpoints": [
            "GET  /health",
            "GET  /api/packages",
            "GET  /api/packages/<id>",
            "GET  /api/packages/search?q=<query>",
            "POST /api/bookings",
            "GET  /api/bookings",
            "GET  /api/stats",
            "GET  /api/docs",
        ]
    })

@app.route("/health", methods=["GET"])
def health():
    return success({
        "status": "healthy",
        "framework": "Flask",
        "timestamp": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "concurrency_model": "Synchronous request handling with WSGI worker model"
    })

@app.route("/api/packages", methods=["GET"])
def get_packages():
    pkgs = list(DEMO_PACKAGES)
    category = request.args.get("category")
    if category:
        pkgs = [p for p in pkgs if p["category"] == category.lower()]

    min_price = request.args.get("minPrice", type=float)
    max_price = request.args.get("maxPrice", type=float)
    if min_price is not None:
        pkgs = [p for p in pkgs if p["price"] >= min_price]
    if max_price is not None:
        pkgs = [p for p in pkgs if p["price"] <= max_price]

    sort_by = request.args.get("sortBy", "")
    if sort_by == "price_asc":
        pkgs.sort(key=lambda x: x["price"])
    elif sort_by == "price_desc":
        pkgs.sort(key=lambda x: x["price"], reverse=True)
    elif sort_by == "rating":
        pkgs.sort(key=lambda x: x["rating"], reverse=True)

    return success({"count": len(pkgs), "packages": pkgs})

@app.route("/api/packages/search", methods=["GET"])
def search_packages():
    q = request.args.get("q", "").lower()
    if not q:
        return error("Query parameter 'q' is required", 400)
    results = [
        p for p in DEMO_PACKAGES
        if q in p["name"].lower() or q in p["destination"].lower() or q in p["category"].lower()
    ]
    return success({"query": q, "count": len(results), "packages": results})

@app.route("/api/packages/<int:pkg_id>", methods=["GET"])
def get_package(pkg_id):
    pkg = find_package(pkg_id)
    if not pkg:
        return error(f"Package {pkg_id} not found", 404)
    return success(pkg)

@app.route("/api/bookings", methods=["POST"])
def create_booking():
    global _next_booking_id
    data = request.get_json(silent=True)
    if not data:
        return error("JSON body required", 400)

    pkg_id = data.get("packageId")
    travelers = data.get("travelers", 1)
    traveler_name = data.get("name", "Demo Traveler")

    if not pkg_id:
        return error("packageId is required", 400)
    if not isinstance(travelers, int) or travelers < 1:
        return error("travelers must be a positive integer", 400)

    pkg = find_package(pkg_id)
    if not pkg:
        return error(f"Package {pkg_id} not found", 404)
    if pkg["seats"] < travelers:
        return error(f"Only {pkg['seats']} seats available", 409)

    pkg["seats"] -= travelers
    total = pkg["price"] * travelers

    booking = {
        "id": _next_booking_id,
        "bookingRef": f"FLK-{int(time.time())}-{_next_booking_id:04d}",
        "packageId": pkg_id,
        "packageName": pkg["name"],
        "destination": pkg["destination"],
        "travelerName": traveler_name,
        "travelers": travelers,
        "totalPrice": total,
        "status": "confirmed",
        "createdAt": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    }
    DEMO_BOOKINGS.append(booking)
    _next_booking_id += 1

    return success(booking, 201)

@app.route("/api/bookings", methods=["GET"])
def get_bookings():
    return success({"count": len(DEMO_BOOKINGS), "bookings": DEMO_BOOKINGS})

@app.route("/api/stats", methods=["GET"])
def stats():
    total_revenue = sum(b["totalPrice"] for b in DEMO_BOOKINGS)
    by_destination = {}
    for b in DEMO_BOOKINGS:
        dest = b["destination"]
        by_destination[dest] = by_destination.get(dest, 0) + b["totalPrice"]
    return success({
        "total_bookings": len(DEMO_BOOKINGS),
        "total_revenue": total_revenue,
        "revenue_by_destination": by_destination,
        "total_packages": len(DEMO_PACKAGES),
        "total_seats_remaining": sum(p["seats"] for p in DEMO_PACKAGES),
    })

@app.route("/api/docs", methods=["GET"])
def docs():
    return jsonify({
        "title": "Explore India Flask API",
        "version": "1.0.0",
        "description": "CO4 demonstration: Flask vs FastAPI vs Django vs Node.js",
        "endpoints": {
            "GET /api/packages": "List packages (filter: category, minPrice, maxPrice, sortBy)",
            "GET /api/packages/search?q=": "Search packages",
            "GET /api/packages/<id>": "Single package",
            "POST /api/bookings": "Create booking {packageId, travelers, name}",
            "GET /api/bookings": "All bookings",
            "GET /api/stats": "Booking statistics",
        }
    })

if __name__ == "__main__":
    print("✅ Explore India – Flask Demo (CO4)")
    print("🐍 Running at http://localhost:5001")
    app.run(host="0.0.0.0", port=5001, debug=True)
