# CO4: Multi-Framework Backend Engineering Comparison

This technical document compares the backend architectures implemented in the **Explore India – Travel Package Booking Portal**.

---

## 1. Architectural Overview & Matrix

| Metric / Dimension | Node.js + Express (Primary) | FastAPI (API Gateway) | Flask (Demo) | Django REST Framework (Demo) |
|---|---|---|---|---|
| **Language & Runtime** | JavaScript / Node.js 24 | Python 3.14 (AsyncIO) | Python 3.14 (WSGI) | Python 3.14 (ASGI/WSGI) |
| **Primary Role** | Main Production Monolith | API Gateway & Routing | Lightweight Microservice | Enterprise Data-Backed Service |
| **I/O Concurrency Model** | Non-blocking Event Loop | Async / Await Coroutines | Multi-Threaded / Synchronous | Threaded synchronous ORM |
| **Validation Layer** | Custom Middleware & Schemas | Declarative Pydantic v2 | Manual request payload parsing | Serializers with validator hooks |
| **Database Integration** | MongoDB via Mongoose | HTTP Forwarding / Gateway | In-memory with atomic ops | Django ORM with SQLite/Postgres |
| **Documentation Standards** | Markdown / Postman | OpenAPI 3.0 (Swagger/ReDoc) | Custom JSON docs endpoint | Browsable REST API & OpenAPI |
| **Port** | `5000` | `8000` | `5001` | `8001` |

---

## 2. In-Depth Technical Analysis

### A. Node.js + Express (Port 5000)
- **Strengths**: High throughput for I/O bound web applications, fast JSON serialization, seamless static file serving for the SPA frontend.
- **Academic Demo Value**: Demonstrates MongoDB document aggregation pipelines (`$lookup`, `$group`, `$sort`), JWT verification middleware, and atomic seat counter reduction.

### B. FastAPI API Gateway (Port 8000)
- **Strengths**: Sub-millisecond routing overhead, type-safe data parsing through Pydantic, dependency injection system (`Depends`), automatic interactive documentation (`/docs`).
- **Academic Demo Value**: Demonstrates reverse-proxy request forwarding, gateway-level rate limiting, and HTTP client lifecycle management via async lifespan contexts.

### C. Flask Microservice (Port 5001)
- **Strengths**: Unopinionated micro-framework with zero boilerplate.
- **Academic Demo Value**: Demonstrates straightforward functional routing, lightweight service composition, and clean WSGI testing fixtures.

### D. Django REST Framework (Port 8001)
- **Strengths**: Robust batteries-included framework with migrations, object-relational mapping, and standard CRUD ViewSets.
- **Academic Demo Value**: Demonstrates relational schema migrations, serializer validation, and relational database operations (SQLite / PostgreSQL).
