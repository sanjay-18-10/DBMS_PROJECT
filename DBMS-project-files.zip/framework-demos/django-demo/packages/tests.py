"""
Django REST Framework Tests (CO4)
Run with: python manage.py test
"""
import os
import django

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'config.settings')
django.setup()

from django.test import TestCase
from rest_framework.test import APIClient
from packages.models import TravelPackage, Booking

class ExploreIndiaDjangoTests(TestCase):
    def setUp(self):
        self.client = APIClient()
        self.pkg = TravelPackage.objects.create(
            name="Kerala Backwaters Luxury",
            destination="Kerala",
            description="Alleppey houseboat tour",
            price=15000.00,
            duration_days=5,
            category="nature",
            available_seats=20,
            rating=4.8
        )

    def test_root_endpoint(self):
        res = self.client.get('/')
        self.assertEqual(res.status_code, 200)
        self.assertIn('Explore India', res.data['app'])

    def test_health_endpoint(self):
        res = self.client.get('/api/health/')
        self.assertEqual(res.status_code, 200)
        self.assertEqual(res.data['status'], 'healthy')

    def test_packages_list(self):
        res = self.client.get('/api/packages/')
        self.assertEqual(res.status_code, 200)
        self.assertEqual(len(res.data['results']), 1)

    def test_create_booking_atomic_seat_decrement(self):
        res = self.client.post('/api/bookings/', {
            'package': self.pkg.id,
            'traveler_name': 'Amit Shah',
            'traveler_email': 'amit@example.com',
            'travelers': 2
        })
        self.assertEqual(res.status_code, 201)
        self.pkg.refresh_from_db()
        self.assertEqual(self.pkg.available_seats, 18)
        self.assertEqual(float(res.data['total_price']), 30000.0)

    def test_stats_endpoint(self):
        res = self.client.get('/api/stats/')
        self.assertEqual(res.status_code, 200)
        self.assertIn('total_bookings', res.data)
