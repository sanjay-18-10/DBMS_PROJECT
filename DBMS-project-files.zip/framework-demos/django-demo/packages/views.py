"""DRF ViewSets for Explore India Django Demo."""
from rest_framework import viewsets, status
from rest_framework.decorators import api_view, action
from rest_framework.response import Response
from django.db.models import Sum, Count, Avg, Q
from django.utils import timezone

from .models import TravelPackage, Booking
from .serializers import (
    TravelPackageSerializer,
    BookingCreateSerializer,
    BookingSerializer
)

class TravelPackageViewSet(viewsets.ModelViewSet):
    queryset = TravelPackage.objects.filter(is_active=True)
    serializer_class = TravelPackageSerializer

    def get_queryset(self):
        qs = TravelPackage.objects.filter(is_active=True)
        category = self.request.query_params.get('category')
        if category:
            qs = qs.filter(category=category)

        min_price = self.request.query_params.get('minPrice')
        if min_price:
            qs = qs.filter(price__gte=min_price)

        max_price = self.request.query_params.get('maxPrice')
        if max_price:
            qs = qs.filter(price__lte=max_price)

        q = self.request.query_params.get('search')
        if q:
            qs = qs.filter(
                Q(name__icontains=q) | Q(destination__icontains=q) | Q(description__icontains=q)
            )

        return qs

class BookingViewSet(viewsets.ModelViewSet):
    queryset = Booking.objects.all()
    serializer_class = BookingSerializer

    def get_serializer_class(self):
        if self.action == 'create':
            return BookingCreateSerializer
        return BookingSerializer

@api_view(['GET'])
def stats_view(request):
    total_bookings = Booking.objects.count()
    revenue = Booking.objects.filter(status='confirmed').aggregate(
        total=Sum('total_price')
    )['total'] or 0

    return Response({
        'total_bookings': total_bookings,
        'total_revenue': float(revenue),
        'packages_count': TravelPackage.objects.filter(is_active=True).count(),
        'orm_demo': 'Django ORM aggregation with Sum() and Count()'
    })

@api_view(['GET'])
def health_view(request):
    return Response({
        'status': 'healthy',
        'framework': 'Django 5.x + DRF',
        'database': 'SQLite relational engine',
        'timestamp': timezone.now().isoformat(),
    })
