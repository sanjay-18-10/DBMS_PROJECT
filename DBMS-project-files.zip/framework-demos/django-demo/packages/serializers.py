"""DRF Serializers for Explore India Django Demo."""
from rest_framework import serializers
from .models import TravelPackage, Booking
import time
import random

class TravelPackageSerializer(serializers.ModelSerializer):
    class Meta:
        model = TravelPackage
        fields = '__all__'

class BookingCreateSerializer(serializers.ModelSerializer):
    class Meta:
        model = Booking
        fields = ['id', 'package', 'traveler_name', 'traveler_email', 'travelers', 'total_price', 'booking_ref', 'status', 'created_at']
        read_only_fields = ['id', 'total_price', 'booking_ref', 'status', 'created_at']

    def validate(self, attrs):
        pkg = attrs['package']
        travelers = attrs.get('travelers', 1)
        if not pkg.is_active:
            raise serializers.ValidationError("Package is inactive.")
        if pkg.available_seats < travelers:
            raise serializers.ValidationError(
                f"Only {pkg.available_seats} seats available, requested {travelers}."
            )
        return attrs

    def create(self, validated_data):
        pkg = validated_data['package']
        travelers = validated_data.get('travelers', 1)
        total = pkg.price * travelers
        ref = f"DJG-{int(time.time())}-{random.randint(1000, 9999)}"

        # Decrement available seats
        pkg.available_seats -= travelers
        pkg.save(update_fields=['available_seats'])

        return Booking.objects.create(
            **validated_data,
            total_price=total,
            booking_ref=ref,
        )

class BookingSerializer(serializers.ModelSerializer):
    package_name = serializers.CharField(source='package.name', read_only=True)
    destination = serializers.CharField(source='package.destination', read_only=True)

    class Meta:
        model = Booking
        fields = '__all__'
