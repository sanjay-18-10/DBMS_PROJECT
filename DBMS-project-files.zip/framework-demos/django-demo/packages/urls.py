"""URL patterns for packages app."""
from django.urls import path, include
from rest_framework.routers import DefaultRouter
from . import views

router = DefaultRouter()
router.register(r'packages', views.TravelPackageViewSet, basename='package')
router.register(r'bookings', views.BookingViewSet, basename='booking')

urlpatterns = [
    path('', include(router.urls)),
    path('stats/', views.stats_view, name='stats'),
    path('health/', views.health_view, name='health'),
]
