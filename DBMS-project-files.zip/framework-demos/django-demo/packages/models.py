"""Django ORM models for Explore India travel packages."""
from django.db import models

class TravelPackage(models.Model):
    name = models.CharField(max_length=200)
    destination = models.CharField(max_length=100)
    description = models.TextField(blank=True)
    price = models.DecimalField(max_digits=10, decimal_places=2)
    duration_days = models.PositiveIntegerField(default=3)
    category = models.CharField(max_length=50, default='nature')
    available_seats = models.PositiveIntegerField(default=20)
    is_active = models.BooleanField(default=True)
    rating = models.DecimalField(max_digits=3, decimal_places=1, default=4.5)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-created_at']

    def __str__(self):
        return f"{self.name} - {self.destination}"


class Booking(models.Model):
    package = models.ForeignKey(TravelPackage, on_delete=models.CASCADE, related_name='bookings')
    traveler_name = models.CharField(max_length=200)
    traveler_email = models.EmailField()
    travelers = models.PositiveIntegerField(default=1)
    total_price = models.DecimalField(max_digits=12, decimal_places=2)
    status = models.CharField(max_length=20, default='confirmed')
    booking_ref = models.CharField(max_length=40, unique=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-created_at']

    def __str__(self):
        return f"{self.booking_ref} - {self.traveler_name}"
