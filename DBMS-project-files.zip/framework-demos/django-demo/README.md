# Explore India – Django REST Framework Demo (CO4)

Demonstrates **CO4: Multi-Framework Backend Engineering** using Django and Django REST Framework (DRF).

## Key Concepts
- **Django ORM**: Object-Relational Mapping with SQLite database, declarative models, and schema migrations.
- **ModelViewSets & Routers**: Automated RESTful endpoints with paging and query parameter filtering.
- **Serializers**: Data sanitization, input validation, and object representation.
- **Atomic Operations**: Automatic seat decrementation during booking creation.

## Running the Server
```powershell
cd framework-demos\django-demo
python manage.py makemigrations
python manage.py migrate
python manage.py runserver 8001
```
Browsable DRF API: `http://localhost:8001/`

## Running Tests
```powershell
cd framework-demos\django-demo
python manage.py test
```
