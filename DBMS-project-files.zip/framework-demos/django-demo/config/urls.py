"""URL configuration for Explore India Django Demo."""
from django.urls import path, include
from rest_framework.decorators import api_view
from rest_framework.response import Response

@api_view(['GET'])
def api_root(request):
    return Response({
        'app': 'Explore India – Django REST Framework Demo',
        'framework': 'Django 5.x + Django REST Framework',
        'purpose': 'CO4 Multi-Framework Backend Engineering demonstration',
        'port': 8001,
        'endpoints': {
            'packages': '/api/packages/',
            'bookings': '/api/bookings/',
            'stats': '/api/stats/',
            'health': '/api/health/',
        },
        'architecture_features': [
            'Model-View-Set abstraction with Django ORM',
            'Declarative Serializers with field-level and cross-field validation',
            'Automatic SQLite relational persistence',
            'Composable ViewSets with built-in pagination and filtering'
        ]
    })

urlpatterns = [
    path('', api_root),
    path('api/', include('packages.urls')),
]
